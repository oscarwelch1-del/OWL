import {repairDemoPositions} from './demo-repair';
import {repairReportedDeletion} from './balance-repair';
import { database,type DatabaseEnv } from './database';
import {seedTracking,recordAccount,recordDeletion} from './tracking-records';
import {trackingApi} from './tracking';
import { validateAccount,editableHoldingDetails,allocate,units,decimal,ownedValue,blankAccountDetails,blankHoldingDetails,type Account,type Holding } from '../lib/finance/model';
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
type AccountRow={id:string;name:string;category:Account['category'];kind:string;provider:string;value_pence:number;ownership_bps:number;valuation_date:string;mode:Account['mode'];remainder:Account['remainder'];notes:string;version:number;updated_at:number;details_json:string};
type HoldingRow={id:string;account_id:string;name:string;type:Holding['type'];ticker:string;isin:string;amount:string;value_pence:number;instrument_id:string|null;exchange:string|null;asset_class:''|'stock'|'etf'|null;source:string|null;details_json:string};

async function list(env:DatabaseEnv,userId:string) {
 const db=database(env);
 // One D1 batch reads accounts and children from a consistent snapshot.
 const results=await db.batch([
  ...seedTracking(env,userId),
  db.prepare('SELECT id,name,category,kind,provider,value_pence,ownership_bps,valuation_date,mode,remainder,notes,version,updated_at,details_json FROM accounts WHERE user_id=? ORDER BY updated_at DESC,id').bind(userId),
  db.prepare('SELECT h.* FROM holdings h JOIN accounts a ON a.id=h.account_id WHERE a.user_id=? ORDER BY h.position').bind(userId),
 ]);
 const rows=results.at(-2)!.results as unknown as AccountRow[];
 const children=results.at(-1)!.results as unknown as HoldingRow[];
 const accounts=rows.map((r):Account=>({id:r.id,name:r.name,category:r.category,kind:r.category==='property'?'property':r.kind,provider:r.provider,value:decimal(r.value_pence),valuePence:r.value_pence,ownership:decimal(r.ownership_bps),ownershipBps:r.ownership_bps,valuationDate:r.valuation_date,mode:r.mode,remainder:r.remainder,notes:r.notes,details:{...blankAccountDetails(),...parseJson(r.details_json,{})},version:r.version,updatedAt:r.updated_at,holdings:children.filter(h=>h.account_id===r.id).map(h=>({id:h.id,name:h.name,type:h.type,ticker:h.ticker,isin:h.isin,amount:h.amount,valuePence:h.value_pence,instrumentId:h.instrument_id||'',exchange:h.exchange||'',assetClass:h.asset_class||'',source:h.source||'',details:editableHoldingDetails(parseJson(h.details_json,{}))}))}));
 const assets=accounts.filter(a=>a.category!=='debt'&&a.category!=='income').reduce((sum,a)=>sum+ownedValue(a),0);
 const debt=accounts.filter(a=>a.category==='debt').reduce((sum,a)=>sum+ownedValue(a),0);
 const snapshotDate=new Date().toISOString().slice(0,10);
 await db.prepare('INSERT INTO portfolio_snapshots (id,user_id,snapshot_date,assets_pence,debt_pence,net_pence,created_at) VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET assets_pence=excluded.assets_pence,debt_pence=excluded.debt_pence,net_pence=excluded.net_pence,created_at=excluded.created_at').bind(userId+':'+snapshotDate,userId,snapshotDate,assets,debt,assets-debt,Date.now()).run();
 const snapshotRows=await db.prepare('SELECT snapshot_date,assets_pence,debt_pence,net_pence FROM portfolio_snapshots WHERE user_id=? ORDER BY snapshot_date DESC LIMIT 90').bind(userId).all<{snapshot_date:string;assets_pence:number;debt_pence:number;net_pence:number}>();
 return {accounts,snapshots:snapshotRows.results.map(s=>({date:s.snapshot_date,assetsPence:s.assets_pence,debtPence:s.debt_pence,netPence:s.net_pence}))};
}
function parseJson<T>(value:string,fallback:T):T {try{return JSON.parse(value) as T;}catch{return fallback;}}
async function payload(request:Request) {
 if(!(request.headers.get('content-type')||'').toLowerCase().startsWith('application/json'))throw new Error('Use a JSON request.');
 const reader=request.body?.getReader();if(!reader)throw new Error('Missing request.');
 let bytes=0;let text='';const decoder=new TextDecoder();
 while(true){const chunk=await reader.read();if(chunk.done)break;bytes+=chunk.value.length;if(bytes>262144){await reader.cancel();throw new Error('This account is too large. Use no more than 100 holdings.');}text+=decoder.decode(chunk.value,{stream:true});}
 return JSON.parse(text+decoder.decode());
}
export async function financeApi(request:Request,env:DatabaseEnv,userId:string) {
 const path=new URL(request.url).pathname;
 if(path==='/api/finance/tracker')return trackingApi(request,env,userId);
 if(path!=='/api/finance/accounts')return json({error:'Not found.'},404);
 try {
  if(request.method==='GET'){await repairDemoPositions(env,userId);await repairReportedDeletion(env,userId);return json(await list(env,userId));}
  if(!['PUT','DELETE'].includes(request.method))return json({error:'Method not allowed.'},405);
  let input:unknown;
  try {input=await payload(request);}catch{return json({error:'Invalid account data. Check the entries and try again.'},400);}
  const db=database(env);
  if(request.method==='DELETE'){
   const {id,version}=input as {id?:unknown;version?:unknown} || {};
   if(typeof id!=='string'||typeof version!=='number'||!Number.isSafeInteger(version)||version<1)return json({error:'Invalid account reference.'},400);
   const deleted=await db.batch([...seedTracking(env,userId),recordDeletion(env,userId,id,version,Date.now()),db.prepare('DELETE FROM accounts WHERE id=? AND user_id=? AND version=? RETURNING id').bind(id,userId,version)]);
   if(!deleted.at(-1)!.results.length)return json({error:'This entry changed or is no longer available. Refresh before trying again.'},409);
   return json({ok:true});
  }
  let a;
  try {a=validateAccount(input);}catch(error){return json({error:error instanceof Error?error.message:'Invalid account.'},400);}
  const holdingIds=JSON.stringify(a.holdings.map(h=>h.id));
  const collision=await db.prepare('SELECT 1 AS found FROM holdings WHERE id IN (SELECT value FROM json_each(?)) AND account_id<>? LIMIT 1').bind(holdingIds,a.id).first();
  if(collision)return json({error:'A holding reference is invalid. Reload the account and try again.'},400);
  const token=crypto.randomUUID();const timestamp=Date.now();const calculated=allocate(a);
  const values=[a.name,a.category,a.kind,a.provider,units(a.value),units(a.ownership),a.valuationDate,a.mode,a.remainder,a.notes,a.version+1,token,timestamp,JSON.stringify(a.details)];
  const writes:D1PreparedStatement[]=[...seedTracking(env,userId,timestamp)];
  const accountWriteIndex=writes.length;
  if(a.version===0){
   const count=await db.prepare('SELECT COUNT(*) AS count FROM accounts WHERE user_id=?').bind(userId).first<{count:number}>();
   if(count&&count.count>=200)return json({error:'You can save up to 200 accounts and assets.'},400);
   writes.push(db.prepare('INSERT INTO accounts (id,user_id,name,category,kind,provider,value_pence,ownership_bps,valuation_date,mode,remainder,notes,version,write_token,updated_at,details_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING').bind(a.id,userId,...values));
  }else{
   writes.push(db.prepare('UPDATE accounts SET name=?,category=?,kind=?,provider=?,value_pence=?,ownership_bps=?,valuation_date=?,mode=?,remainder=?,notes=?,version=?,write_token=?,updated_at=?,details_json=? WHERE id=? AND user_id=? AND version=?').bind(...values,a.id,userId,a.version));
  }
  // The fresh write token gates every child mutation inside this atomic batch.
  // A stale version or another user's account cannot change any holdings.
  writes.push(db.prepare('DELETE FROM holdings WHERE account_id=? AND id NOT IN (SELECT value FROM json_each(?)) AND EXISTS (SELECT 1 FROM accounts WHERE id=? AND user_id=? AND write_token=?)').bind(a.id,holdingIds,a.id,userId,token));
  for(let i=0;i<a.holdings.length;i++){
   const h=a.holdings[i];
   // Keep a confirmed pricing listing through quantity/value updates. A changed
   // instrument identity invalidates that listing within the same atomic write.
   writes.push(db.prepare('DELETE FROM market_listings WHERE holding_id=? AND EXISTS (SELECT 1 FROM holdings h JOIN accounts a ON a.id=h.account_id WHERE h.id=? AND a.id=? AND a.user_id=? AND a.write_token=? AND (h.ticker<>? OR h.isin<>? OR COALESCE(h.exchange,\'\')<>? OR h.type<>?))').bind(h.id,h.id,a.id,userId,token,h.ticker,h.isin,h.exchange,h.type));
   writes.push(db.prepare('INSERT INTO holdings (id,account_id,name,type,ticker,isin,amount,value_pence,position,instrument_id,exchange,asset_class,source,details_json) SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,? WHERE EXISTS (SELECT 1 FROM accounts WHERE id=? AND user_id=? AND write_token=?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,type=excluded.type,ticker=excluded.ticker,isin=excluded.isin,amount=excluded.amount,value_pence=excluded.value_pence,position=excluded.position,instrument_id=excluded.instrument_id,exchange=excluded.exchange,asset_class=excluded.asset_class,source=excluded.source,details_json=excluded.details_json WHERE holdings.account_id=excluded.account_id').bind(h.id,a.id,h.name,h.type,h.ticker,h.isin,h.amount,calculated.values[i],i,h.instrumentId||null,h.exchange||null,h.assetClass||null,h.source||null,JSON.stringify(h.details),a.id,userId,token));
  }
  writes.push(recordAccount(env,userId,a.id,timestamp,token));
  const saved=await db.batch(writes);
  if(Number(saved[accountWriteIndex].meta.changes)!==1)return json({error:'This entry changed in another session. Close the editor and refresh before saving again.'},409);
  return json({account:(await list(env,userId)).accounts.find(row=>row.id===a.id)});
 }catch{
  console.error('Financial record operation unavailable');
  return json({error:'Unable to access your financial records. Your entries have been kept in the editor; please try again.'},503);
 }
}
