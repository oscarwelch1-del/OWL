import {comparisonApi} from './comparison';
import { database, type DatabaseEnv } from './database';
import {seedTracking,recordAccount} from './tracking-records';
import { chartRanges, type ChartRange, type Listing, type MarketDetail, type MarketQuote } from '../lib/finance/market';
import { MarketError, providerGet, findListings, normalizeDaily, normalizeQuote, normalizeStats, history, rangeStart, object, string, number } from './market-provider';
import {FUNDAMENTAL_FILTER,normalizeConstituents,topHoldings,savedConstituents,unavailableConstituents} from './constituents';
import {exposureRefresh,savedClassifications,savedExposureIssues} from './exposure-metadata';
import {inferredListing,type TrackedHolding} from '../lib/finance/tracker';

const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
const encode=(bytes:Uint8Array)=>btoa(String.fromCharCode(...bytes));
const decode=(value:string)=>Uint8Array.from(atob(value),c=>c.charCodeAt(0));
async function encryptionKey(env:DatabaseEnv){
 try{
  const bytes=decode(env.MARKET_DATA_ENCRYPTION_KEY||'');
  if(bytes.length!==32)throw new Error();
  return await crypto.subtle.importKey('raw',bytes,'AES-GCM',false,['encrypt','decrypt']);
 }catch{throw new MarketError('Secure key storage is unavailable. Please try again later.');}
}
export async function encryptToken(token:string,userId:string,env:DatabaseEnv){
 const iv=crypto.getRandomValues(new Uint8Array(12));
 const encrypted=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:new TextEncoder().encode('market-data:'+userId)},await encryptionKey(env),new TextEncoder().encode(token));
 return ['v1',encode(iv),encode(new Uint8Array(encrypted))].join(':');
}
export async function decryptToken(value:string,userId:string,env:DatabaseEnv){
 try{
  const [version,iv,ciphertext,...extra]=value.split(':');
  if(version!=='v1'||extra.length)throw new Error();
  const plaintext=await crypto.subtle.decrypt({name:'AES-GCM',iv:decode(iv),additionalData:new TextEncoder().encode('market-data:'+userId)},await encryptionKey(env),decode(ciphertext));
  return new TextDecoder().decode(plaintext);
 }catch{throw new MarketError('Your saved data connection could not be opened. Reconnect your API key.');}
}
export async function credential(env:DatabaseEnv,userId:string){
 if(env.EODHD_API_TOKEN)return env.EODHD_API_TOKEN;
 const row=await database(env).prepare('SELECT encrypted_token FROM market_connections WHERE user_id=?').bind(userId).first<{encrypted_token:string}>();
 return row?decryptToken(row.encrypted_token,userId,env):null;
}
async function payload(request:Request){
 if(!request.headers.get('content-type')?.toLowerCase().startsWith('application/json'))throw new MarketError('Use a JSON request.',415);
 const reader=request.body?.getReader();if(!reader)throw new MarketError('Missing request.',400);
 let raw='';let size=0;const decoder=new TextDecoder();
 while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>2048){await reader.cancel();throw new MarketError('Request is too large.',413);}raw+=decoder.decode(value,{stream:true});}
 try{return object(JSON.parse(raw+decoder.decode()));}catch{throw new MarketError('Invalid request.',400);}
}
async function connection(request:Request,env:DatabaseEnv,userId:string){
 const db=database(env);
 if(request.method==='GET'){
  const saved=await db.prepare('SELECT updated_at FROM market_connections WHERE user_id=?').bind(userId).first();
  return json({configured:!!(env.EODHD_API_TOKEN||saved),managed:!!env.EODHD_API_TOKEN,canConfigure:!!env.MARKET_DATA_ENCRYPTION_KEY});
 }
 if(env.EODHD_API_TOKEN)throw new MarketError('This connection is managed in the site settings.',409);
 if(request.method==='DELETE'){
  await db.prepare('DELETE FROM market_connections WHERE user_id=?').bind(userId).run();return json({ok:true});
 }
 if(request.method!=='PUT')return json({error:'Method not allowed.'},405);
 const token=string((await payload(request)).token);
 if(!/^[\x21-\x7e]{8,256}$/.test(token)||token.toLowerCase()==='demo')throw new MarketError('Enter your own EODHD API key.',400);
 const encrypted=await encryptToken(token,userId,env);
 const now=Date.now();
 const limit=await db.prepare('INSERT INTO login_limits (bucket,attempts,reset_at) VALUES (?,1,?) ON CONFLICT(bucket) DO UPDATE SET attempts=CASE WHEN reset_at<=? THEN 1 ELSE attempts+1 END,reset_at=CASE WHEN reset_at<=? THEN excluded.reset_at ELSE reset_at END RETURNING attempts').bind('market-connect:'+userId,now+60000,now,now).first<{attempts:number}>();
 if(!limit||limit.attempts>5)throw new MarketError('Please wait a minute before trying another key.',429);
 const info=object(await providerGet('user',token,{},0));
 if(number(info.dailyRateLimit)===null&&!string(info.email))throw new MarketError('EODHD could not verify this API key.',400);
 await db.prepare('INSERT INTO market_connections (user_id,encrypted_token,updated_at) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET encrypted_token=excluded.encrypted_token,updated_at=excluded.updated_at').bind(userId,encrypted,now).run();
 return json({ok:true});
}
type HoldingRow={id:string;account_id:string;name:string;ticker:string;isin:string;exchange:string|null;type:string;asset_class:string|null;listing_json:string|null};
async function ownedHolding(env:DatabaseEnv,userId:string,id:string){
 const holding=await database(env).prepare('SELECT h.id,h.account_id,h.name,h.ticker,h.isin,h.exchange,h.type,h.asset_class,m.listing_json FROM holdings h JOIN accounts a ON a.id=h.account_id LEFT JOIN market_listings m ON m.holding_id=h.id WHERE h.id=? AND a.user_id=?').bind(id,userId).first<HoldingRow>();
 if(!holding)throw new MarketError('This holding is no longer available.',404);
 return holding;
}
const supported=(holding:HoldingRow)=>['share','etf','fund','investment_trust'].includes(holding.type)||['stock','etf'].includes(holding.asset_class||'');
// A broker-provided ticker and venue can identify one exact EODHD listing.
// Use it immediately for fund reports without requiring an extra UI choice.
// Ambiguous or ISIN-only holdings still ask the owner to select a listing.
export function exactRecordedListing(holding:Pick<HoldingRow,'id'|'name'|'type'|'ticker'|'isin'|'exchange'>,candidates:Listing[]):Listing|null{
 const recorded:TrackedHolding={id:holding.id,name:holding.name,type:holding.type,ticker:holding.ticker,isin:holding.isin,exchange:holding.exchange||'',valuePence:0,quantity:'',quantityDate:'',listing:null};
 const inferred=inferredListing(recorded);
 if(!inferred)return null;
 const matching=candidates.filter(candidate=>candidate.symbol===inferred.symbol&&(!holding.isin||candidate.isin.toUpperCase()===holding.isin.toUpperCase()));
 return matching.length===1?matching[0]:null;
}
const currencyUnit=(currency:string)=>['GBX','GBp'].includes(currency)?'GBP':currency;
export async function detail(listing:Listing,range:ChartRange,token:string|null,holdingType=listing.type):Promise<MarketDetail>{
 const from=new Date();from.setUTCDate(from.getUTCDate()-400);
 const symbol=encodeURIComponent(listing.symbol);
 const get=(path:string,params:Record<string,string>={},ttl=60000)=>token?providerGet(path,token,params,ttl):Promise.reject(new MarketError('Optional data connection is not configured.'));
 const dailyPromise=get('eod/'+symbol,{period:'d',order:'a',from:from.toISOString().slice(0,10)},3600000).then(normalizeDaily);
 const historical=range==='1D'||range==='5Y'||range==='MAX'?(token?history(listing,range,token):Promise.reject(new MarketError('Connect EODHD to load price history.'))):dailyPromise.then(rows=>({points:rows.filter(r=>r.date>=rangeStart(range)!).map(r=>({time:r.date,close:r.close,volume:r.volume})),interval:'Daily',note:'Closing prices, unadjusted for splits and dividends. History may be limited by the instrument or your data plan.'}));
 const [dailyResult,quoteResult,fundResult,chartResult]=await Promise.allSettled([
  dailyPromise,
  get('real-time/'+symbol).then(data=>normalizeQuote(data,listing.symbol)),
  get('v1.1/fundamentals/'+symbol,FUNDAMENTAL_FILTER,21600000),
  historical,
 ]);
 const warnings=new Set<string>();

 const daily=dailyResult.status==='fulfilled'?dailyResult.value:[];

 let quote:MarketQuote|null=quoteResult.status==='fulfilled'?quoteResult.value:null;

 if(daily.length&&(!quote||quote.time.slice(0,10)<daily[daily.length-1].date)){
  const last=daily[daily.length-1];quote={price:last.close,open:last.open,previousClose:daily.at(-2)?.close??null,high:last.high,low:last.low,volume:last.volume,time:last.date,kind:'end-of-day'};
  warnings.add('A current delayed quote is unavailable. Showing the latest available closing price.');
 }
 let fundamentals:unknown={};
 if(fundResult.status==='fulfilled'){
  const general=object(object(fundResult.value).General);const etf=object(object(fundResult.value).ETF_Data);
  const isin=string(general.ISIN)||string(etf.ISIN);const code=string(general.Code);const currency=string(general.CurrencyCode);
  if((code&&code.toUpperCase()!==listing.ticker.toUpperCase())||(isin&&listing.isin&&isin.toUpperCase()!==listing.isin)||(currency&&currencyUnit(currency)!==currencyUnit(listing.currency))){
   warnings.add('Fundamentals did not match this listing. Those figures have been withheld.');
  }else if(code){fundamentals=fundResult.value;}
 }else warnings.add('Some optional fund statistics are unavailable from your current data connection.');
 const chart=chartResult.status==='fulfilled'?chartResult.value:null;
 if(dailyResult.status==='rejected')warnings.add('EODHD closing prices are unavailable for this listing.');
 if(!quote)warnings.add('No verified current price is available.');
 if(!chart?.points.length)warnings.add('Price history is currently unavailable.');
 const constituents=fundResult.status==='rejected'?unavailableConstituents(listing,fundResult.reason instanceof MarketError?fundResult.reason.message:'EODHD fundamentals could not be reached.'):normalizeConstituents(fundResult.value,listing,holdingType);

 return {status:'ready',listing,quote,priceSource:'EODHD',chartSource:'EODHD',range,points:chart?.points||[],interval:chart?.interval,chartNote:chart?.note,stats:normalizeStats(fundamentals,listing,daily),constituents,warnings:[...warnings],fetchedAt:new Date().toISOString()};
}
export async function marketApi(request:Request,env:DatabaseEnv,userId:string){
 try{
  const url=new URL(request.url);
  if(url.pathname==='/api/market/connection')return await connection(request,env,userId);
  if(url.pathname==='/api/market/comparison')return await comparisonApi(request,env,userId);
  if(url.pathname==='/api/market/exposure'){
   if(!['GET','POST'].includes(request.method))return json({error:'Method not allowed.'},405);
   const now=Date.now();let refreshAfter=Number(url.searchParams.get('after')||0);
   if(refreshAfter&&(!Number.isSafeInteger(refreshAfter)||refreshAfter>now||refreshAfter<now-15*60000))throw new MarketError('Restart the coverage refresh.',400);
   if(url.searchParams.get('refresh')==='1')refreshAfter=now;
   const status=request.method==='POST'?{...await exposureRefresh(env,userId,await credential(env,userId),refreshAfter),refreshAfter}:null;
   const owned=await database(env).prepare('SELECT h.id,h.name,h.type,h.ticker,h.isin,h.exchange,m.listing_json FROM holdings h JOIN accounts a ON a.id=h.account_id LEFT JOIN market_listings m ON m.holding_id=h.id WHERE a.user_id=?').bind(userId).all<{id:string;name:string;type:string;ticker:string;isin:string;exchange:string|null;listing_json:string|null}>();
   const snapshots:Record<string,Awaited<ReturnType<typeof savedConstituents>>>={};
   const pending=new Map<string,ReturnType<typeof savedConstituents>>();
   for(const row of owned.results){
    const fallback:TrackedHolding={id:row.id,name:row.name,type:row.type,ticker:row.ticker,isin:row.isin,exchange:row.exchange||'',valuePence:0,quantity:'',quantityDate:'',listing:null};
    const listing=row.listing_json?JSON.parse(row.listing_json) as Listing:inferredListing(fallback);
    if(!listing){snapshots[row.id]=null;continue;}
    const listingKey=JSON.stringify([listing.symbol,listing.isin,listing.currency]);
    let value=pending.get(listingKey);
    if(!value){value=savedConstituents(env,userId,listing);pending.set(listingKey,value);}
    snapshots[row.id]=await value;
   }
   return json({snapshots,classifications:await savedClassifications(env,userId),issues:await savedExposureIssues(env,userId),readAt:new Date().toISOString(),...status});
  }
  const match=/^\/api\/market\/holdings\/([A-Za-z0-9_-]{1,100})(\/(?:listing|constituents))?$/.exec(url.pathname);
  if(!match)return json({error:'Not found.'},404);
  const holding=await ownedHolding(env,userId,match[1]);
  if(match[2]==='/constituents'){
   if(request.method!=='GET')return json({error:'Method not allowed.'},405);
   const requested=Number(new URL(request.url).searchParams.get('limit')||'10');
   if(!Number.isInteger(requested)||requested<1||requested>1000)throw new MarketError('Choose a holdings limit between 1 and 1000.',400);
   const token=await credential(env,userId);
   let listing=holding.listing_json?JSON.parse(holding.listing_json) as Listing:null;
   if(!listing&&token)listing=exactRecordedListing(holding,await findListings(holding,token));
   if(!listing)return json({status:'select_listing',warnings:['Confirm the trading listing in holding details first.']});
   const force=new URL(request.url).searchParams.get('refresh')==='1';
   return json(await topHoldings(env,userId,listing,holding.type,token,Date.now(),undefined,requested,force));
  }
  if(match[2]==='/listing'){
   if(request.method==='DELETE'){
    await database(env).batch([...seedTracking(env,userId),database(env).prepare('DELETE FROM market_listings WHERE holding_id=? AND EXISTS (SELECT 1 FROM holdings h JOIN accounts a ON a.id=h.account_id WHERE h.id=? AND a.user_id=?)').bind(holding.id,holding.id,userId),recordAccount(env,userId,holding.account_id,Date.now())]);return json({ok:true});
   }
   if(request.method!=='PUT')return json({error:'Method not allowed.'},405);
   if(!supported(holding))throw new MarketError('Market data is currently available for shares and ETFs.',400);
   const symbol=string((await payload(request)).symbol);const token=await credential(env,userId);
   if(!token)throw new MarketError('Connect your market-data key first.',409);
   const listing=(await findListings(holding,token)).find(row=>row.symbol===symbol);
   if(!listing)throw new MarketError('This listing does not match the saved holding. Search again.',400);
   await database(env).batch([...seedTracking(env,userId),database(env).prepare('INSERT INTO market_listings (holding_id,listing_json,selected_at) SELECT ?,?,? WHERE EXISTS (SELECT 1 FROM holdings h JOIN accounts a ON a.id=h.account_id WHERE h.id=? AND a.user_id=? AND h.ticker=? AND h.isin=?) ON CONFLICT(holding_id) DO UPDATE SET listing_json=excluded.listing_json,selected_at=excluded.selected_at').bind(holding.id,JSON.stringify(listing),Date.now(),holding.id,userId,holding.ticker,holding.isin),recordAccount(env,userId,holding.account_id,Date.now())]);
   return json({ok:true});
  }
  if(request.method!=='GET')return json({error:'Method not allowed.'},405);
  const range=url.searchParams.get('range')||'1Y';
  if(!chartRanges.includes(range as ChartRange))throw new MarketError('Choose a supported chart period.',400);
  const requestedLimit=Number(url.searchParams.get('limit')||'10');
  if(!Number.isInteger(requestedLimit)||requestedLimit<1||requestedLimit>1000)throw new MarketError('Choose a holdings limit between 1 and 1000.',400);
  if(!supported(holding)||(!holding.ticker&&!holding.isin))return json({status:'unmatched',warnings:['Add a matched stock or ETF ticker to this holding to see market data.']});
  const token=await credential(env,userId);
  if(!holding.listing_json&&!token)return json({status:'setup_required'});
  let listing=holding.listing_json?JSON.parse(holding.listing_json) as Listing:null;
  if(!listing){const candidates=await findListings(holding,token!);listing=exactRecordedListing(holding,candidates);
   if(!listing)return json({status:candidates.length?'select_listing':'unmatched',candidates,warnings:candidates.length?[]:['No verified listing matched this holding. Check its ticker and ISIN in the account editor.']});
  }
  const result=await detail(listing,range as ChartRange,token,holding.type);
  if(result.constituents){
   try{result.constituents=await topHoldings(env,userId,listing,holding.type,token,Date.now(),result.constituents,requestedLimit,false);}
   catch{result.warnings=[...(result.warnings||[]),'The holdings snapshot could not be loaded.'];}
  }
  return json(result);
 }catch(error){
  return json({error:error instanceof MarketError?error.message:'Market data is temporarily unavailable. Please try again.'},error instanceof MarketError?error.status:503);
 }
}
