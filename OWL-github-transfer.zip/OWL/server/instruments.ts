import {normalizeExchange} from '../lib/finance/aj-bell';
import {credential} from './market';
import {MarketError,normalizeListings,object,providerGet,string} from './market-provider';
import type {DatabaseEnv} from './database';
import type {InstrumentSearchResult} from '../lib/finance/model';

export type {InstrumentSearchResult};
const isinPattern=/^[A-Z]{2}[A-Z0-9]{9}\d$/;
const tickerPattern=/^[A-Z0-9][A-Z0-9.\-]{0,29}$/;
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'private, max-age=60'}});

function instrumentType(type:string):InstrumentSearchResult['type']|null{
 if(/^(Common Stock|Preferred Stock)$/i.test(type))return 'share';
 if(/^ETF$/i.test(type))return 'etf';
 if(/^(Investment Trust|Closed-end Fund)$/i.test(type))return 'investment_trust';
 if(/^Fund$/i.test(type))return 'fund';
 return null;
}

export function normalizeEodInstruments(payload:unknown,query:string,exchange=''):InstrumentSearchResult[]{
 const holding=isinPattern.test(query)?{ticker:'',isin:query}:{ticker:query,isin:''};
 return normalizeListings(payload,holding)
  .filter(row=>!exchange||normalizeExchange(row.exchange)===exchange)
  .flatMap(row=>{
   const type=instrumentType(row.type);
   return type?[{id:row.symbol,name:row.name,ticker:row.ticker,exchange:row.exchange,isin:row.isin,type,assetClass:type==='share'?'stock':'etf',source:'eodhd' as const}]:[];
  });
}

async function exactFundamentals(ticker:string,exchange:string,isin:string,token:string):Promise<InstrumentSearchResult[]>{
 const providerExchange=exchange==='LN'?'LSE':exchange;
 try{
  const data=object(await providerGet('fundamentals/'+encodeURIComponent(ticker+'.'+providerExchange),token,{filter:'General,ETF_Data::ISIN'},3600000));
  const general=object(data.General),etf=object(data.ETF_Data);
  const code=string(general.Code).toUpperCase(),venue=string(general.Exchange).toUpperCase();
  const returnedIsin=(string(etf.ISIN)||string(general.ISIN)).toUpperCase();
  const type=instrumentType(string(general.Type));
  if(code!==ticker||normalizeExchange(venue)!==exchange||!type||!string(general.Name)||isin&&returnedIsin!==isin)return [];
  return [{id:code+'.'+venue,name:string(general.Name),ticker:code,exchange:venue,isin:returnedIsin,type,assetClass:type==='share'?'stock':'etf',source:'eodhd'}];
 }catch{return [];}
}

export async function instrumentSearchApi(request:Request,env:DatabaseEnv,userId:string){
 const url=new URL(request.url);if(url.pathname!=='/api/instruments/search')return json({error:'Not found.'},404);
 if(request.method!=='GET')return json({error:'Method not allowed.'},405);
 const query=(url.searchParams.get('q')||'').trim().toUpperCase();
 if(!isinPattern.test(query)&&!tickerPattern.test(query))return json({error:'Enter an exact ticker or 12-character ISIN.'},400);
 const exchange=normalizeExchange(url.searchParams.get('exchange')||'');
 if(exchange&&!/^[A-Z0-9]{1,10}$/.test(exchange))return json({error:'Enter a valid exchange code.'},400);
 try{
  const token=await credential(env,userId);
  if(!token)return json({error:'Connect EODHD before searching for instruments.'},409);
  const payload=await providerGet('search/'+encodeURIComponent(query),token,{limit:'100',...(exchange?{exchange:exchange==='LN'?'LSE':exchange}:{})},3600000);
  let results=normalizeEodInstruments(payload,query,exchange);
  if(!results.length&&exchange&&!isinPattern.test(query))results=await exactFundamentals(query,exchange,'',token);
  return json({query,results,supported:['stock','etf','fund']});
 }catch(error){
  return json({error:error instanceof MarketError?error.message:'Instrument lookup is temporarily unavailable. You can still enter the holding manually.'},error instanceof MarketError?error.status:503);
 }
}
