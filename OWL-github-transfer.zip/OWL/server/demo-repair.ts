import {database,type DatabaseEnv} from './database';
import {quoteCurrency,type Series} from '../lib/finance/tracker';

// Explicitly requested repair of this synthetic demo, not a valuation rule.
// Never rescale real imported quantities to force agreement with a statement.
const accountId='ad4f9568-ba45-4203-8f91-e41c0bfe3183';
export const demoAllocations:Record<string,number>={VWRL:2400000,SWDA:2000000,IITU:1600000,VFEM:1400000,IEUX:1100000,CSUK:900000,INRG:600000};
export function demoPosition(valuePence:number,series:Series){
 const close=series.prices.find(p=>p.date==='2026-09-23');
 if(series.source!=='eodhd'||series.splitAdjusted||!close||close.close<=0||!['GBP','GBX','GBp'].includes(series.quoteCurrency||''))return null;
 const price=close.close*quoteCurrency(series.quoteCurrency!).scale;
 return {quantity:(valuePence/100/price).toFixed(8),unitPrice:price.toFixed(8),priceCurrency:'GBP',priceDate:close.date};
}
export async function repairDemoPositions(env:DatabaseEnv,userId:string){
 const db=database(env);
 const account=await db.prepare("SELECT id FROM accounts WHERE id=? AND user_id=? AND name='DEMO' AND version=1 AND value_pence=10000000 AND valuation_date='2026-09-23'").bind(accountId,userId).first();
 if(!account)return;
 const result=await db.batch([
  db.prepare('SELECT id,ticker,value_pence,details_json FROM holdings WHERE account_id=?').bind(accountId),
  db.prepare('SELECT symbol,data_json FROM tracking_series WHERE user_id=?').bind(userId),
 ]);
 const rows=result[0].results as unknown as {id:string;ticker:string;value_pence:number;details_json:string}[];
 const series=new Map(result[1].results.map((r:any)=>[r.symbol,JSON.parse(r.data_json) as Series]));
 if(rows.length!==7||new Set(rows.map(r=>r.ticker)).size!==7)return;
 const corrected=[];
 for(const row of rows){
  const details=JSON.parse(row.details_json);
  if(demoAllocations[row.ticker]!==row.value_pence||details.quantity!=='100'||Number(details.unitPrice)!==row.value_pence/10000||details.priceCurrency!=='GBP'||details.priceDate!=='2026-09-23')return;
  const data=series.get(row.ticker+'.LSE');const position=data&&demoPosition(row.value_pence,data);if(!position)return;
  corrected.push({...row,details:JSON.stringify({...details,...position})});
 }
 const token='demo-repair-20260926-running',done='demo-repair-20260926-complete',now=Date.now();
 const gate="EXISTS (SELECT 1 FROM accounts WHERE id=? AND user_id=? AND write_token=?)";
 await db.batch([
  db.prepare("UPDATE accounts SET version=version+1,write_token=?,updated_at=? WHERE id=? AND user_id=? AND version=1 AND name='DEMO' AND value_pence=10000000 AND (SELECT COUNT(*) FROM accounts WHERE user_id=?)=1").bind(token,now,accountId,userId,userId),
  ...corrected.map(row=>db.prepare(`UPDATE holdings SET details_json=? WHERE id=? AND account_id=? AND ${gate}`).bind(row.details,row.id,accountId,accountId,userId,token)),
  db.prepare(`DELETE FROM tracking_days WHERE user_id=? AND ${gate}`).bind(userId,accountId,userId,token),
  db.prepare(`DELETE FROM tracking_revisions WHERE user_id=? AND ${gate}`).bind(userId,accountId,userId,token),
  // Preserve request budgets and verified market data; cancel old in-flight work.
  db.prepare(`UPDATE tracking_runs SET started_at=?,lease_until=0,lease_token='' WHERE user_id=? AND ${gate}`).bind(now,userId,accountId,userId,token),
  db.prepare('UPDATE accounts SET write_token=? WHERE id=? AND user_id=? AND write_token=?').bind(done,accountId,userId,token),
 ]);
}
