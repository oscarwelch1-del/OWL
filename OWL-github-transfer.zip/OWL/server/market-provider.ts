import type { ChartRange, Listing, MarketQuote, MarketStats, PricePoint } from '../lib/finance/market';

export class MarketError extends Error {
 constructor(message:string,public status=503){super(message);}
}
export const object=(value:unknown):Record<string,unknown>=>value&&typeof value==='object'&&!Array.isArray(value)?value as Record<string,unknown>:{};
// EODHD unwraps a single filtered section; multi-section responses retain it.
export function generalSection(value:unknown){const root=object(value);return root.General&&typeof root.General==='object'?object(root.General):root;}
export const string=(value:unknown)=>typeof value==='string'?value.trim():'';
export function number(value:unknown):number|null {
 if(typeof value!=='number'&&(typeof value!=='string'||!value.trim()))return null;
 const result=Number(value);return Number.isFinite(result)?result:null;
}
const positive=(value:unknown)=>{const n=number(value);return n!==null&&n>0?n:null;};
const nonnegative=(value:unknown)=>{const n=number(value);return n!==null&&n>=0?n:null;};
export function dateOnly(value:unknown):string|null {
 const s=string(value);if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return null;
 const d=new Date(s+'T00:00:00Z');return Number.isFinite(d.getTime())&&d.toISOString().slice(0,10)===s?s:null;
}

// Bounded cache of successful responses. Credentials are hashed, never logged.
const cache=new Map<string,{expires:number;json:string}>();let cacheBytes=0;
async function cacheKey(token:string,path:string,params:Record<string,string>){
 const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token));
 return Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('')+path+JSON.stringify(params);
}
const pending=new Map<string,Promise<unknown>>();
export async function providerGet(path:string,token:string,params:Record<string,string>={},ttl=60000):Promise<unknown>{
 if(!ttl)return requestProvider(path,token,params,ttl);
 const key=await cacheKey(token,path,params);const existing=pending.get(key);if(existing)return existing;
 const work=requestProvider(path,token,params,ttl);pending.set(key,work);
 try{return await work;}finally{pending.delete(key);}
}
async function requestProvider(path:string,token:string,params:Record<string,string>,ttl:number):Promise<unknown>{
 const key=await cacheKey(token,path,params);const cached=cache.get(key);
 if(ttl&&cached&&cached.expires>Date.now())return JSON.parse(cached.json);
 const url=new URL('https://eodhd.com/api/'+path);
 url.search=new URLSearchParams({...params,api_token:token,fmt:'json'}).toString();
 const timer=new AbortController();const timeout=setTimeout(()=>timer.abort(),10000);
 try{
  // Workers support manual redirects. A 3xx response is rejected below, so the
  // API token can never be forwarded to a redirect destination.
  const response=await fetch(url,{signal:timer.signal,headers:{Accept:'application/json'},redirect:'manual'});
  if(!response.ok){
   if(response.status===401)throw new MarketError('EODHD rejected the API key. Check your data connection.',401);
   if(response.status===403)throw new MarketError('This dataset or instrument is not included in your EODHD access.',403);
   if(response.status===429)throw new MarketError('The EODHD request limit has been reached. Please try later.',429);
   throw new MarketError('The market-data provider is unavailable. Please try again.');
  }
  const reader=response.body?.getReader();if(!reader)throw new MarketError('The provider returned no data.');
  let size=0;let raw='';const decoder=new TextDecoder();
  while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>4_000_000){await reader.cancel();throw new MarketError('The provider response was too large. Select a shorter period.');}raw+=decoder.decode(value,{stream:true});}
  raw+=decoder.decode();let data:unknown;try{data=JSON.parse(raw);}catch{throw new MarketError('The provider returned an invalid response.');}
  const row=object(data);if(row.error||row.errors||row.message)throw new MarketError('The requested dataset is not available from EODHD.');
  if(ttl){
   if(cached){cacheBytes-=cached.json.length;cache.delete(key);}
   while(cache.size&&(cacheBytes+raw.length>3_000_000||cache.size>=60)){
    const first=cache.keys().next().value!;cacheBytes-=cache.get(first)!.json.length;cache.delete(first);
   }
   if(raw.length<=3_000_000){cache.set(key,{expires:Date.now()+ttl,json:raw});cacheBytes+=raw.length;}
  }
  return data;
 }catch(error){if(error instanceof MarketError)throw error;throw new MarketError('Market data could not be reached. Please retry shortly.');}
 finally{clearTimeout(timeout);}
}

export function normalizeListings(data:unknown,holding:{ticker:string;isin:string}):Listing[]{
 if(!Array.isArray(data))throw new MarketError('The provider returned invalid search results.');
 const result=new Map<string,Listing>();
 for(const value of data){
  const row=object(value);const ticker=string(row.Code).toUpperCase();const exchange=string(row.Exchange).toUpperCase();
  const isin=string(row.ISIN).toUpperCase();const name=string(row.Name);const type=string(row.Type);
  const currency=string(row.Currency);const symbol=ticker+'.'+exchange;
  if(!ticker||!exchange||!/^[A-Z0-9][A-Z0-9._-]{0,49}$/.test(symbol)||!name)continue;
  if(!/^(Common Stock|Preferred Stock|ETF|Fund|Investment Trust|Closed-end Fund)$/i.test(type))continue;
  // An ISIN is stronger than ticker text; a conflicting or missing ISIN never matches it.
  if(holding.isin?isin!==holding.isin.toUpperCase():ticker!==holding.ticker.toUpperCase())continue;
  result.set(symbol,{symbol,name,ticker,exchange,currency,isin,type});
 }
 return [...result.values()].sort((a,b)=>a.exchange.localeCompare(b.exchange));
}
export async function findListings(holding:{ticker:string;isin:string},token:string){
 const query=holding.isin||holding.ticker;if(!query)return [];
 return normalizeListings(await providerGet('search/'+encodeURIComponent(query),token,{limit:'100'},3600000),holding);
}

export function normalizeQuote(data:unknown,symbol:string,now=Date.now()):MarketQuote|null {
 const row=object(data);if(string(row.code).toUpperCase()!==symbol.toUpperCase())return null;
 const price=positive(row.close);const time=number(row.timestamp);
 if(price===null||time===null||time<=0||time*1000>now+300000)return null;
 return {price,open:positive(row.open),previousClose:positive(row.previousClose),high:positive(row.high),low:positive(row.low),volume:nonnegative(row.volume),time:new Date(time*1000).toISOString(),kind:'delayed'};
}
export type DailyBar={date:string;open:number|null;high:number|null;low:number|null;close:number;volume:number|null};
export function normalizeDaily(data:unknown):DailyBar[]{
 if(!Array.isArray(data))throw new MarketError('Historical prices are unavailable.');
 const map=new Map<string,DailyBar>();
 for(const value of data){const r=object(value);const date=dateOnly(r.date);const close=positive(r.close);
  if(!date||close===null||date>new Date().toISOString().slice(0,10))continue;
  map.set(date,{date,open:positive(r.open),high:positive(r.high),low:positive(r.low),close,volume:nonnegative(r.volume)});
 }
 return [...map.values()].sort((a,b)=>a.date.localeCompare(b.date));
}
export function rangeStart(range:ChartRange,now=new Date()):string|undefined {
 const date=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()));
 if(range==='MAX')return undefined;
 if(range==='YTD')date.setUTCMonth(0,1);
 else if(range==='1D')date.setUTCDate(date.getUTCDate()-14);
 else if(range==='1W')date.setUTCDate(date.getUTCDate()-7);
 else if(range==='1M'||range==='3M'){
  const day=date.getUTCDate();date.setUTCDate(1);date.setUTCMonth(date.getUTCMonth()-(range==='1M'?1:3));
  const last=new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth()+1,0)).getUTCDate();date.setUTCDate(Math.min(day,last));
 }else {const month=date.getUTCMonth();date.setUTCFullYear(date.getUTCFullYear()-(range==='5Y'?5:1));if(date.getUTCMonth()!==month)date.setUTCDate(0);}
 return date.toISOString().slice(0,10);
}
export function normalizeIntraday(data:unknown,exchange:string):PricePoint[]{
 if(!Array.isArray(data))throw new MarketError('Intraday history is unavailable.');
 const zone=({US:'America/New_York',LSE:'Europe/London'} as Record<string,string>)[exchange]||'UTC';
 const dateFormatter=new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit'});
 const map=new Map<number,PricePoint>();
 for(const v of data){const r=object(v);const close=positive(r.close);const t=number(r.timestamp);
  if(close===null||t===null||t<=0||t*1000>Date.now()+300000)continue;
  map.set(t,{time:new Date(t*1000).toISOString(),close,volume:nonnegative(r.volume)});
 }
 const rows=[...map.entries()].sort(([a],[b])=>a-b).map(([,v])=>v);
 const last=rows.at(-1);if(!last)return [];
 const session=dateFormatter.format(new Date(last.time));return rows.filter(p=>dateFormatter.format(new Date(p.time))===session);
}
export async function history(listing:Listing,range:ChartRange,token:string){
 const from=rangeStart(range);const symbol=encodeURIComponent(listing.symbol);
 if(range==='1D'){
  const data=await providerGet('intraday/'+symbol,token,{interval:'5m',from:String(Date.parse(from!)/1000),to:String(Math.floor(Date.now()/1000))},900000);
  return {points:normalizeIntraday(data,listing.exchange),interval:'5-minute',note:'Latest available session. Intraday history is finalised after the session; this is not a live chart.'};
 }
 const period=range==='MAX'?'m':range==='5Y'?'w':'d';
 const rows=normalizeDaily(await providerGet('eod/'+symbol,token,{period,order:'a',...(from?{from}:{})},3600000));
 return {points:rows.map(r=>({time:r.date,close:r.close,volume:r.volume})),interval:period==='m'?'Monthly':period==='w'?'Weekly':'Daily',note:'Closing prices, unadjusted for splits and dividends. History may be limited by the instrument or your data plan.'};
}
export function normalizeStats(data:unknown,listing:Listing,daily:DailyBar[]):MarketStats {
 const root=object(data);const general=object(root.General);const highlights=object(root.Highlights);const etf=object(root.ETF_Data);
 const updated=dateOnly(general.UpdatedAt);const yearStart=rangeStart('1Y')!;const rows=daily.filter(r=>r.date>=yearStart);
 // Calculate only with roughly a full year's daily observations, never claim a partial window is 52 weeks.
 const enough=rows.length>=200&&!!daily[0]&&daily[0].date<=yearStart;
 const highs=rows.map(r=>r.high).filter((v):v is number=>v!==null);const lows=rows.map(r=>r.low).filter((v):v is number=>v!==null);
 const volumes=daily.slice(-30).map(r=>r.volume);const avg=volumes.length===30&&volumes.every(v=>v!==null)?volumes.reduce<number>((a,v)=>a+v!,0)/30:null;
 const ratio=number(etf.NetExpenseRatio);const yieldValue=number(listing.type==='ETF'?etf.Yield:highlights.DividendYield);
 // Market capitalisation is in the fundamentals currency, which may differ from quote units (GBX).
 const capCurrency=string(general.CurrencyCode)||null;
 return {high52:enough&&highs.length===rows.length?Math.max(...highs):null,low52:enough&&lows.length===rows.length?Math.min(...lows):null,averageVolume:avg,marketCap:capCurrency?nonnegative(highlights.MarketCapitalization):null,marketCapCurrency:capCurrency,dividendYield:yieldValue!==null&&yieldValue>=0?yieldValue*(listing.type==='ETF'?1:100):null,expenseRatio:ratio!==null&&ratio>=0?ratio*100:null,updatedAt:updated};
}
