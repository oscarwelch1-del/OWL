import {database,type DatabaseEnv} from './database';
import {object,string,number,dateOnly,MarketError,providerGet,generalSection,findListings} from './market-provider';
import {quoteCurrency} from '../lib/finance/tracker';
import type {Listing} from '../lib/finance/market';
import type {Constituent,Constituents} from '../lib/finance/constituents';

export const FUNDAMENTAL_FILTER={filter:'General,Highlights,ETF_Data,MutualFund_Data'};
const clean=(v:unknown)=>{const s=string(v);return !s||/^(?:n\/a|na|null|unknown|-|--)$/i.test(s)?null:s;};
const symbolPattern=/^[A-Z0-9][A-Z0-9._-]{0,39}\.[A-Z0-9_-]{1,10}$/;
const digest=async(s:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))),n=>n.toString(16).padStart(2,'0')).join('');
const fund=(type:string)=>/^(ETF|Fund|Investment Trust|Closed-end Fund|etf|investment_trust|fund)$/i.test(type);
const unit=(s:string)=>quoteCurrency(s).currency;
const sorted=(rows:Constituent[])=>rows.map((h,i)=>({h,i})).sort((a,b)=>b.h.weightPercent-a.h.weightPercent||(a.h.symbol||a.h.name).localeCompare(b.h.symbol||b.h.name)||a.i-b.i).map(v=>v.h);
const slice=(value:Constituents,limit=10):Constituents=>{
 if(value.status!=='ready')return value;
 const rows=(value.allHoldings?.length?value.allHoldings:value.holdings).slice(0,limit);
 const coverage=Number(rows.reduce((n,h)=>n+h.weightPercent,0).toFixed(8));
 return {...value,holdings:rows,coveragePercent:coverage,otherPercent:Number((100-coverage).toFixed(8))};
};

export function unavailableConstituents(listing:Listing,message:string,now=Date.now()):Constituents{
 return {status:'unavailable',symbol:listing.symbol,source:'EODHD',holdings:[],coveragePercent:null,otherPercent:null,holdingsAsOf:null,providerUpdatedAt:null,retrievedAt:new Date(now).toISOString(),cached:false,stale:false,warnings:[message]};
}

export function normalizeConstituents(payload:unknown,listing:Listing,holdingType=listing.type,now=Date.now()):Constituents{
 const unavailable=(message:string)=>unavailableConstituents(listing,message,now);
 const root=object(payload),general=object(root.General),etf=object(root.ETF_Data),mutual=object(root.MutualFund_Data);
 const code=string(general.Code).toUpperCase(),currency=string(general.CurrencyCode);
 const isin=string(general.ISIN)||string(etf.ISIN);
 // The requested CODE.EXCHANGE plus the returned code and available ISIN
 // identify the instrument. General.Exchange can be a venue name (NYSE ARCA)
 // rather than EODHD's composite exchange code (US).
 if(!code||code!==listing.ticker.toUpperCase()||(listing.isin?(!isin||isin.toUpperCase()!==listing.isin.toUpperCase()):(!currency||unit(currency)!==unit(listing.currency))))return unavailable('EODHD’s fund identity could not be verified against this listing.');
 const isFund=fund(holdingType)||fund(string(general.Type))||fund(listing.type);
 if(!isFund)return {...unavailable('Underlying fund holdings do not apply to this company.'),status:'not_applicable'};
 const top=etf.Top_10_Holdings||mutual.Top_Holdings;
 const full=etf.Holdings;
 const raw=full&&typeof full==='object'&&Object.keys(full).length?full:top;
 if(!raw||typeof raw!=='object'||Object.keys(raw).length===0){
  return unavailable(`EODHD returned a ${string(general.Type)||'fund'} record for ${listing.symbol}, but no ETF or mutual-fund holdings list.${holdingType==='investment_trust'?' This investment trust’s shareholders are not its underlying investments.':''}`);
 }
 try{
  const entries=Array.isArray(raw)?raw.map((value,index)=>[String(index),value] as [string,unknown]):Object.entries(raw);
  if(entries.length>5000)throw new Error('Unexpected holdings count');
  const holdings:Constituent[]=[];const seen=new Set<string>();
  for(const [key,value] of entries){
   const r=object(value);const name=clean(r.Name);const rawWeight=r['Assets_%']??r.Weight;
   const weight=number(typeof rawWeight==='string'?rawWeight.replace(/%\s*$/,''):rawWeight);
   if(!name||name.length>240||weight===null||weight<0||weight>100)throw new Error('Invalid name or weight');
   const code=string(r.Code).toUpperCase(),exchange=string(r.Exchange).toUpperCase();
   const keyed=key.toUpperCase();const keyIsSymbol=symbolPattern.test(keyed);
   let symbol=code&&exchange?code+'.'+exchange:keyIsSymbol?keyed:null;
   if(symbol&&!symbolPattern.test(symbol))throw new Error('Invalid identifier');
   if(keyIsSymbol&&((symbol&&symbol!==keyed)||(code&&keyed.slice(0,keyed.lastIndexOf('.'))!==code)||(exchange&&keyed.slice(keyed.lastIndexOf('.')+1)!==exchange)))throw new Error('Conflicting identifier');
   // Preserve an explicitly named holding with no ticker (e.g. private stock).
   // No ticker, sector or country is inferred from its name.
   const identity=symbol||name.toLowerCase();if(seen.has(identity))throw new Error('Duplicate holding');seen.add(identity);
   holdings.push({symbol,name,weightPercent:weight,sector:clean(r.Sector),industry:clean(r.Industry),country:clean(r.Country),region:clean(r.Region),isin:clean(r.ISIN),countryBasis:clean(r.Country)?'EODHD reported country':undefined,classificationSource:'EODHD'});
  }
  const allHoldings=sorted(holdings);const topTen=allHoldings.slice(0,10);
  const fullCoverage=Number(allHoldings.reduce((n,h)=>n+h.weightPercent,0).toFixed(8));
  const coverage=Number(topTen.reduce((n,h)=>n+h.weightPercent,0).toFixed(8));
  if(fullCoverage>100||coverage>100)throw new Error('Weights exceed 100%');
  const updated=dateOnly(general.UpdatedAt);const today=new Date(now).toISOString().slice(0,10);
  const warnings=['EODHD does not supply a separate holdings date in this dataset. The provider update date is not a holdings valuation date.'];
  if(topTen.length<10)warnings.push(`EODHD supplied ${topTen.length} holdings; the remaining positions are unavailable.`);
  if(allHoldings.length>topTen.length)warnings.push(`EODHD supplied ${allHoldings.length} holdings; the page is showing the top ten.`);
  if(topTen.some(h=>!h.symbol))warnings.push('Some holdings have no verified market identifier.');
  const reported=number(etf.Holdings_Count);
  return {status:'ready',symbol:listing.symbol,source:'EODHD',holdings:topTen,allHoldings:allHoldings.length>topTen.length?allHoldings:undefined,reportedCount:reported,coveragePercent:coverage,otherPercent:Number((100-coverage).toFixed(8)),holdingsAsOf:null,providerUpdatedAt:updated&&updated<=today?updated:null,retrievedAt:new Date(now).toISOString(),cached:false,stale:false,warnings};
 }catch{
  // A defective full list must not hide an independently valid provider top list.
  // Keep original weights; never scale a partial list to 100%.
  if(raw===full&&top&&Object.keys(object(top)).length){
   const partial=normalizeConstituents({...root,ETF_Data:{...etf,Holdings:null}},listing,holdingType,now);
   if(partial.status==='ready')return {...partial,warnings:[...partial.warnings,'The complete holdings list failed validation. Showing the separately verified provider top holdings only.']};
  }
  return unavailable('EODHD’s holdings contain missing, duplicate or inconsistent values. The list has been withheld.');
 }
}

async function listingKey(listing:Listing){return digest(JSON.stringify([listing.symbol,listing.isin,listing.currency]));}
export async function rememberConstituents(env:DatabaseEnv,userId:string,listing:Listing,value:Constituents){
 if(value.status!=='ready')return value;
 const key=await listingKey(listing);
 // Retrieval time is excluded so an unchanged response reuses its observation.
 const content={...value,retrievedAt:'',cached:false,stale:false};
 const hash=await digest(JSON.stringify(content));
 const db=database(env);
 const previous=await db.prepare('SELECT data_hash,data_json FROM fund_constituent_snapshots WHERE user_id=? AND listing_key=? ORDER BY retrieved_at DESC LIMIT 1').bind(userId,key).first<{data_hash:string;data_json:string}>();
 if(previous?.data_hash===hash)return {...JSON.parse(previous.data_json),cached:true} as Constituents;
 const id=await digest(userId+'|'+key+'|'+hash+'|'+value.retrievedAt);
 await db.prepare(`INSERT INTO fund_constituent_snapshots (id,user_id,listing_key,symbol,data_hash,data_json,retrieved_at)
  SELECT ?,?,?,?,?,?,? WHERE COALESCE((SELECT data_hash FROM fund_constituent_snapshots WHERE user_id=? AND listing_key=? ORDER BY retrieved_at DESC LIMIT 1),'')<>? ON CONFLICT(id) DO NOTHING`).bind(id,userId,key,listing.symbol,hash,JSON.stringify(value),Date.parse(value.retrievedAt),userId,key,hash).run();
 const saved=await db.prepare('SELECT data_json FROM fund_constituent_snapshots WHERE user_id=? AND listing_key=? ORDER BY retrieved_at DESC LIMIT 1').bind(userId,key).first<{data_json:string}>();
 return saved?JSON.parse(saved.data_json) as Constituents:value;
}
export async function savedConstituents(env:DatabaseEnv,userId:string,listing:Listing):Promise<Constituents|null>{
 const row=await database(env).prepare('SELECT data_json FROM fund_constituent_snapshots WHERE user_id=? AND listing_key=? ORDER BY retrieved_at DESC LIMIT 1').bind(userId,await listingKey(listing)).first<{data_json:string}>();
 if(!row)return null;
 const saved=JSON.parse(row.data_json) as Constituents;
 if(saved.status!=='ready'||(saved.symbol&&saved.symbol!==listing.symbol)||!Array.isArray(saved.holdings)||!saved.holdings.length)return null;
 return {...saved,cached:true,stale:saved.source!=='EODHD'||saved.stale,warnings:saved.source==='EODHD'?saved.warnings:[...saved.warnings,'This is a saved report from the named source, not EODHD. Check its holdings date before relying on it.']};
}

export async function enrichConstituents(snapshot:Constituents,token:string):Promise<Constituents>{
 if(snapshot.status!=='ready')return snapshot;
 const all=snapshot.allHoldings?.length?snapshot.allHoldings:snapshot.holdings;
 const candidates=all.filter(h=>h.symbol&&(!h.sector||!h.industry||!h.country)).slice(0,6);
 const profiles=new Map<string,Record<string,unknown>>();
 for(let i=0;i<candidates.length;i+=3)await Promise.all(candidates.slice(i,i+3).map(async holding=>{
  try{
   const general=object(await providerGet('v1.1/fundamentals/'+encodeURIComponent(holding.symbol!),token,{filter:'General'},86400000));
   const profile=generalSection(general);
   const code=string(profile.Code).toUpperCase();
   if(code!==holding.symbol!.slice(0,holding.symbol!.lastIndexOf('.')).toUpperCase())return;
   if(holding.isin&&string(profile.ISIN)&&holding.isin.toUpperCase()!==string(profile.ISIN).toUpperCase())return;
   profiles.set(holding.symbol!,profile);
  }catch{/* Unverified fields remain unclassified. */}
 }));
 const enriched=all.map(h=>{const profile=h.symbol?profiles.get(h.symbol):undefined;if(!profile)return h;
  const country=clean(profile.CountryName)||h.country;
  return {...h,sector:h.sector||clean(profile.Sector),industry:h.industry||clean(profile.Industry),country,countryBasis:country&&clean(profile.CountryName)?'EODHD company registration':h.countryBasis,classificationSource:'EODHD'};
 });
 return {...snapshot,holdings:enriched.slice(0,10),allHoldings:snapshot.allHoldings?.length?enriched:undefined};
}

export async function topHoldings(env:DatabaseEnv,userId:string,listing:Listing,holdingType:string,token:string|null,now=Date.now(),primary?:Constituents,limit=10,force=false):Promise<Constituents>{
 if(!fund(holdingType)&&!fund(listing.type))return {...unavailableConstituents(listing,'Underlying holdings do not apply to this company.',now),status:'not_applicable'};
 const saved=await savedConstituents(env,userId,listing);
 if(saved?.source==='EODHD'&&!force&&now-Date.parse(saved.retrievedAt)<86400000)return slice(saved,limit);
 let result=primary;
 if(!result&&token){try{result=normalizeConstituents(await providerGet('v1.1/fundamentals/'+encodeURIComponent(listing.symbol),token,FUNDAMENTAL_FILTER,force?0:21600000),listing,holdingType,now);}catch(error){result=unavailableConstituents(listing,error instanceof MarketError?error.message:'EODHD could not supply holdings for this instrument.',now);}}
 if(!result)result=unavailableConstituents(listing,token?'EODHD did not provide underlying holdings for this instrument.':'Connect EODHD to load fund holdings.',now);
 // Fund composition belongs to the ISIN. Another trading currency/listing of
 // that exact security may carry the report; prices always stay on the original.
 if(result.status==='unavailable'&&token&&listing.isin&&holdingType!=='investment_trust'){
  try{
   const alternatives=(await findListings({ticker:listing.ticker,isin:listing.isin},token)).filter(candidate=>candidate.symbol!==listing.symbol&&candidate.isin.toUpperCase()===listing.isin.toUpperCase()&&/^(ETF|Fund)$/i.test(candidate.type)).slice(0,3);
   for(const candidate of alternatives){
    try{
     const payload=await providerGet('v1.1/fundamentals/'+encodeURIComponent(candidate.symbol),token,FUNDAMENTAL_FILTER,force?0:21600000);
     const verified=normalizeConstituents(payload,candidate,holdingType,now);
     if(verified.status==='ready'){result={...verified,symbol:listing.symbol,sourceSymbol:candidate.symbol,warnings:[...verified.warnings,`Holdings supplied under ${candidate.symbol}, verified against the same ISIN ${listing.isin}. Pricing remains on ${listing.symbol}.`]};break;}
    }catch{/* A failed alternate must not replace a saved verified report. */}
   }
  }catch{/* Keep the original provider error when identity search fails. */}
 }
 if(result.status==='ready'){
  if(token)result=await enrichConstituents(result,token);
  if(saved?.source==='EODHD'&&saved.holdingsAsOf&&(!result.holdingsAsOf||result.holdingsAsOf<saved.holdingsAsOf))return slice({...saved,stale:true,warnings:[...saved.warnings,'The available source is older than this saved report. Keeping the newer holdings.']},limit);
  return slice(await rememberConstituents(env,userId,listing,result),limit);
 }
 return saved?slice({...saved,stale:true,warnings:[...saved.warnings,saved.source==='EODHD'?'The latest refresh was unsuccessful. Showing the last verified snapshot.':'EODHD did not supply underlying holdings. Showing a previously saved report from the named source; its holdings may have changed.']},limit):slice(result,limit);
}
