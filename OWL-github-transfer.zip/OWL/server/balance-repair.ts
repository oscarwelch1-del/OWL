import {database,type DatabaseEnv} from './database';

// One-time repair of the deletion reported on 15 September. This is NOT a
// general rule that leftover balances are wrong. Every observed field and
// remaining holding total must still match, otherwise leave the account alone.
// The original revision remains in the audit trail; a new revision corrects
// its effective day. The version/token guards make retries safe and reject
// stale editors. Can be removed after the affected account has been repaired.
export async function repairReportedDeletion(env:DatabaseEnv,userId:string){
 const db=database(env),id='3ab41062-7fe8-49a4-9201-a21fa82498aa';
 const at=1789510707676,token='repair-20260915-removed-tsla-balance';
 await db.batch([
  db.prepare(`UPDATE accounts SET value_pence=6391033,version=version+1,write_token=?
   WHERE id=? AND user_id=? AND version=6 AND updated_at=? AND value_pence=7391033
   AND mode='value' AND remainder='unassigned'
   AND (SELECT COUNT(*) FROM holdings WHERE account_id=accounts.id)=12
   AND (SELECT SUM(value_pence) FROM holdings WHERE account_id=accounts.id)=6391033
   AND NOT EXISTS (SELECT 1 FROM holdings WHERE account_id=accounts.id AND upper(ticker)='TSLA')
   AND EXISTS (SELECT 1 FROM tracking_revisions WHERE account_id=accounts.id AND user_id=? AND recorded_at=? AND json_extract(state_json,'$.valuePence')=7391033)
   AND NOT EXISTS (SELECT 1 FROM tracking_revisions WHERE account_id=accounts.id AND user_id=? AND recorded_at>?)`).bind(token,id,userId,at,userId,at,userId,at),
  // Idempotent insertion: require the repair token and no matching correction.
  db.prepare(`INSERT INTO tracking_revisions(user_id,account_id,recorded_at,state_json)
   SELECT r.user_id,r.account_id,r.recorded_at,json_set(r.state_json,'$.valuePence',6391033)
   FROM tracking_revisions r JOIN accounts a ON a.id=r.account_id AND a.user_id=r.user_id
   WHERE a.id=? AND a.user_id=? AND a.write_token=? AND r.recorded_at=?
   AND json_extract(r.state_json,'$.valuePence')=7391033
   AND NOT EXISTS (SELECT 1 FROM tracking_revisions c WHERE c.account_id=a.id AND c.user_id=a.user_id AND c.recorded_at=? AND json_extract(c.state_json,'$.valuePence')=6391033)
   ORDER BY r.seq DESC LIMIT 1`).bind(id,userId,token,at,at),
 ]);
}
