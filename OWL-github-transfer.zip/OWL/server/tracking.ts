import {repairDemoPositions} from './demo-repair';
import {correctedHoldingHistory} from '../lib/finance/history-corrections';
import {repairReportedDeletion} from './balance-repair';
import {database,type DatabaseEnv} from './database';
import {credential} from './market';
import {providerGet,normalizeListings,MarketError} from './market-provider';
import {seedTracking} from './tracking-records';
import {dayOf,shiftDay,statesOn,valueDay,completedThrough,validQuoteCurrency,VALUATION_VERSION,ANOMALY_THRESHOLD_PERCENT,applyAnomalyCheck,adjustmentLabels,reconcileAccounts,marketHolding,investmentAccount,validListing,inferredListing,validDay,quoteCurrency,fxSymbol,normalizeCloses,normalizeSplits,type Series,type Revision,type DailyPoint,type TrackingResponse,type TrackedAccount} from '../lib/finance/tracker';
import {mergeSeries} from '../lib/finance/tracker';

const DAILY_CALL_LIMIT=200; // A bounded guard against accidental request loops; EODHD still enforces the plan limit.
const REQUEST_CALL_LIMIT=6;
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
type Run={started_at:number;lease_until:number;lease_token:string;budget_date:string;budget_used:number;last_refresh:number|null};
type StoredSeries={symbol:string;data_json:string;attempted_day:string;error:string};
type Need={symbol:string;from:string;splitsFrom:string;fx:boolean;currency:string;active?:boolean};
const emptySeries=(symbol:string):Series=>({symbol,prices:[],splits:[],from:'',through:'',splitsFrom:'',splitsThrough:'',source:'eodhd',splitAdjusted:false});
const hash=async(value:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))),v=>v.toString(16).padStart(2,'0')).join('');

export {completedThrough} from '../lib/finance/tracker';

async function read(env:DatabaseEnv,userId:string){
 const db=database(env);
 const result=await db.batch([
  db.prepare('SELECT seq,account_id,recorded_at,state_json FROM tracking_revisions WHERE user_id=? ORDER BY recorded_at,seq').bind(userId),
  db.prepare('SELECT symbol,data_json,attempted_day,error FROM tracking_series WHERE user_id=?').bind(userId),
  db.prepare('SELECT * FROM tracking_runs WHERE user_id=?').bind(userId),
  db.prepare('SELECT snapshot_json FROM tracking_days WHERE user_id=? ORDER BY day').bind(userId),
 ]);
 const revisions:Revision[]=result[0].results.map((r:any)=>({seq:r.seq,accountId:r.account_id,recordedAt:r.recorded_at,state:r.state_json?JSON.parse(r.state_json):null}));
 const stored=result[1].results as unknown as StoredSeries[];
 const series=new Map<string,Series>(stored.map(r=>{const parsed=JSON.parse(r.data_json) as Partial<Series>;return [r.symbol,{...emptySeries(r.symbol),...parsed,source:parsed.source||'eodhd',splitAdjusted:parsed.splitAdjusted??false} as Series]}));
 const run=result[2].results[0] as unknown as Run;
 const points:DailyPoint[]=result[3].results.map((r:any)=>JSON.parse(r.snapshot_json));
 const corrected=correctedHoldingHistory(revisions);
 return {revisions:corrected.revisions,correctionFrom:corrected.from,stored,series,run,points};
}

function requirements(revisions:Revision[],from:string,to:string,series:Map<string,Series>){
 const needs=new Map<string,Need>();
 const active=new Set(statesOn(revisions,to).flatMap(a=>a.holdings.map(h=>(h.listing||inferredListing(h))?.symbol)));
 const add=(need:Need)=>{const old=needs.get(need.symbol);needs.set(need.symbol,old?{...need,from:old.from<need.from?old.from:need.from,splitsFrom:old.splitsFrom<need.splitsFrom?old.splitsFrom:need.splitsFrom}:need);};
 const states:TrackedAccount[]=[...statesOn(revisions,from),...revisions.filter(r=>dayOf(r.recordedAt)>=from&&dayOf(r.recordedAt)<=to).flatMap(r=>r.state?[r.state]:[])];
 for(const a of states){
  if(!investmentAccount(a))continue;
  for(const h of a.holdings){
   const listing=validListing(h.listing)?h.listing:inferredListing(h);
   if(!marketHolding(h)||!listing||!h.quantity||Number(h.quantity)<=0||!validDay(h.quantityDate))continue;
   add({symbol:listing.symbol,from:shiftDay(from,-7),splitsFrom:h.quantityDate,fx:false,currency:listing.currency,active:active.has(listing.symbol)});
   const currency=quoteCurrency(series.get(listing.symbol)?.quoteCurrency|| (validListing(h.listing)?h.listing.currency:'GBP')).currency;
   if(currency!=='GBP')add({symbol:fxSymbol(currency),from:shiftDay(from,-7),splitsFrom:'',fx:true,currency:'GBP'});
  }
 }
 return [...needs.values()].sort((a,b)=>Number(b.active)-Number(a.active)||Number(b.fx)-Number(a.fx)||a.symbol.localeCompare(b.symbol));
}

function catchupStart(points:DailyPoint[],startedAt:number){
 // Recheck a week for late publication/corrections without rewriting earlier
 // stored days. Account revisions always retain their original effective day.
 const start=dayOf(startedAt),last=points.at(-1)?.date;
 return last&&shiftDay(last,-7)>start?shiftDay(last,-7):start;
}

export function needsFetch(need:Need,stored:StoredSeries|undefined,series:Series|undefined,today:string,target:string,now=Date.now()){
 // A morning check must not suppress the evening close. Old date-only markers
 // intentionally expire on upgrade; each symbol then has its own 15-minute cooldown.
 const attempted=/^v[23]:/.test(stored?.attempted_day||'')?Date.parse(stored!.attempted_day.slice(3)):NaN;
 if(Number.isFinite(attempted)&&now-attempted<900000)return false;
 return !series||(!need.fx&&!validQuoteCurrency(series.quoteCurrency))||series.source!=='eodhd'||!series.from||series.from>need.from||series.through<target||(!need.fx&&(!series.splitsFrom||series.splitsFrom>need.splitsFrom||series.splitsThrough<target));
}

export async function providerQuoteCurrency(symbol:string,token:string):Promise<string>{
 const dot=symbol.lastIndexOf('.'),ticker=symbol.slice(0,dot),exchange=symbol.slice(dot+1);
 const rows=normalizeListings(await providerGet('search/'+encodeURIComponent(ticker),token,{exchange,limit:'100'},3600000),{ticker,isin:''});
 const exact=rows.filter(r=>r.symbol===symbol&&validQuoteCurrency(r.currency));
 if(exact.length!==1)throw new MarketError('The provider quote currency could not be verified for '+symbol+'. Recorded value retained.');
 return exact[0].currency;
}

async function refreshPrices(env:DatabaseEnv,userId:string,token:string|null,lease:string,data:Awaited<ReturnType<typeof read>>,today:string,target:string){
 if(!token)return;
 const db=database(env);let calls=0;
 const needs=requirements(data.revisions,catchupStart(data.points,data.run.started_at),today,data.series);
 const stored=new Map(data.stored.map(r=>[r.symbol,r]));
 for(const need of needs){
  const completed=completedThrough(need.symbol);
  const old=data.series.get(need.symbol)||emptySeries(need.symbol);
  if(!needsFetch(need,stored.get(need.symbol),data.series.get(need.symbol),today,completed))continue;
  const needsCurrency=!need.fx&&!validQuoteCurrency(old.quoteCurrency);
  const cost=need.fx?1:needsCurrency?3:2;
  if(calls+cost>REQUEST_CALL_LIMIT)break;
  const renewed=await db.prepare('UPDATE tracking_runs SET lease_until=? WHERE user_id=? AND lease_token=? AND lease_until>? RETURNING user_id').bind(Date.now()+120000,userId,lease,Date.now()).first();
  if(!renewed)break;
  calls+=cost;
  // Replace legacy Yahoo observations with an EODHD history covering the
  // original start date. A failed refresh leaves saved history intact.
  const incrementalFrom=old.from&&old.from<=need.from&&old.through>=need.from?shiftDay(old.through,-7):need.from;
  const eodhdFrom=old.source==='yahoo'&&old.from?old.from:incrementalFrom;
  let selected:Series|null=null;let error='';
  const allowed=await db.prepare(`UPDATE tracking_runs SET budget_used=CASE WHEN budget_date=? THEN budget_used+? ELSE ? END,budget_date=?
    WHERE user_id=? AND lease_token=? AND lease_until>? AND (budget_date<>? OR budget_used+?<=?) RETURNING budget_used`).bind(today,cost,cost,today,userId,lease,Date.now(),today,cost,DAILY_CALL_LIMIT).first();
  if(allowed){
    try{
     const quoteUnit=need.fx?'GBP':needsCurrency?await providerQuoteCurrency(need.symbol,token):old.quoteCurrency!;
     const prices=await providerGet('eod/'+encodeURIComponent(need.symbol),token,{from:eodhdFrom,to:completed,period:'d',order:'a'},0).then(raw=>normalizeCloses(raw,eodhdFrom,completed));
     const splitsFrom=old.source==='yahoo'&&old.splitsFrom&&old.splitsFrom<need.splitsFrom?old.splitsFrom:need.splitsFrom;
     const splits=need.fx||splitsFrom>completed?[]:await providerGet('splits/'+encodeURIComponent(need.symbol),token,{from:splitsFrom,to:completed},0).then(raw=>normalizeSplits(raw,splitsFrom,completed));
     if(!prices.length)throw new Error('empty');
     if(old.source==='yahoo'&&old.prices.length&&prices[0].date>shiftDay(old.prices[0].date,7))throw new Error('EODHD cannot yet replace the complete saved history');
     selected={symbol:need.symbol,prices,splits,from:eodhdFrom,through:prices.at(-1)!.date,splitsFrom:need.fx?'':splitsFrom,splitsThrough:need.fx?'':completed,source:'eodhd',splitAdjusted:false,quoteCurrency:quoteUnit,currencyVerifiedAt:old.currencyVerifiedAt||new Date().toISOString()};
    }catch(cause){error=cause instanceof MarketError?cause.message:'Closing prices could not be refreshed. Recorded values or dated saved closes are retained.';}
  }
  if(!selected&&!error)error='The refresh allowance is exhausted. Recorded values or dated saved closes are retained.';
  let next=old;
  if(selected){
   next=old.source==='yahoo'?selected:mergeSeries(old,selected);error=next.through<completed?`Latest returned close is ${next.through}; awaiting a newer close.`:'';
  }
  await db.prepare('INSERT INTO tracking_series (id,user_id,symbol,data_json,attempted_day,error) VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET data_json=excluded.data_json,attempted_day=excluded.attempted_day,error=excluded.error').bind(userId+':'+need.symbol,userId,need.symbol,JSON.stringify(next),'v3:'+new Date().toISOString(),error).run();
  data.series.set(need.symbol,next);
 }
}
async function saveDays(env:DatabaseEnv,userId:string,data:Awaited<ReturnType<typeof read>>,target:string){
 const repair=data.points.some(p=>p.valuationVersion!==VALUATION_VERSION);
 const usualStart=repair?dayOf(data.run.started_at):catchupStart(data.points,data.run.started_at);
 const start=data.correctionFrom&&data.correctionFrom<usualStart?data.correctionFrom:usualStart;
 const stop=data.correctionFrom||repair?target:(shiftDay(start,61)<target?shiftDay(start,61):target);
 if(start>stop)return;
 let previous=data.points.find(p=>p.date===shiftDay(start,-1));
 const writes:D1PreparedStatement[]=[];
 const revisionSeq=Math.max(0,...data.revisions.map(r=>r.seq));
 for(let day=start;day<=stop;day=shiftDay(day,1)){
  const {point}=valueDay(statesOn(data.revisions,day),day,data.series);
  point.provisional=day===dayOf(Date.now());
  point.stateKey=await hash(point.stateKey);
  point.adjustments=day===dayOf(data.run.started_at)?[]:adjustmentLabels(statesOn(data.revisions,shiftDay(day,-1)),statesOn(data.revisions,day));
  point.accountChanges=!!point.adjustments.length;
  point.changePence=previous?point.portfolioPence-previous.portfolioPence:null;
  point.marketChangePence=previous&&!point.accountChanges&&!point.unavailableCount&&!previous.unavailableCount&&!point.stale&&!previous.stale?point.marketPence-previous.marketPence:null;
  applyAnomalyCheck(point,previous);
  if(JSON.stringify(data.points.find(p=>p.date===day))!==JSON.stringify(point))writes.push(database(env).prepare('INSERT INTO tracking_days (id,user_id,day,snapshot_json,updated_at) SELECT ?,?,?,?,? WHERE (SELECT COALESCE(MAX(seq),0) FROM tracking_revisions WHERE user_id=?)=? ON CONFLICT(id) DO UPDATE SET snapshot_json=excluded.snapshot_json,updated_at=excluded.updated_at').bind(userId+':'+day,userId,day,JSON.stringify(point),Date.now(),userId,revisionSeq));
  previous=point;
 }
 // Corrections can affect more than the normal one-week refresh window.
 // Write bounded batches, skipping identical snapshots to avoid repeat work.
 // Writes themselves retain the revision guard against concurrent edits.
 for(let i=0;i<writes.length;i+=60)await database(env).batch(writes.slice(i,i+60));
}

async function responseData(env:DatabaseEnv,userId:string,now:number):Promise<TrackingResponse>{
 const data=await read(env,userId);const today=dayOf(now);const target=today;
 const savedStates=statesOn(data.revisions,today);
 const current=valueDay(savedStates,today,data.series);const holdings=current.holdings;
 const recorded=valueDay(savedStates,today,new Map()).point.portfolioPence;
 const connection=!!(env.EODHD_API_TOKEN||await database(env).prepare('SELECT user_id FROM market_connections WHERE user_id=?').bind(userId).first());
 const budgetUsed=data.run.budget_date===today?data.run.budget_used:0;
 const needs=requirements(data.revisions,catchupStart(data.points,data.run.started_at),today,data.series);
 // Saved history remains available when the EODHD allowance is full.
 const pendingPrices=!!connection&&needs.some(n=>needsFetch(n,data.stored.find(s=>s.symbol===n.symbol),data.series.get(n.symbol),today,completedThrough(n.symbol,new Date(now)),now));
 const dayTarget=today;
 const pendingDays=dayOf(data.run.started_at)<=dayTarget&&(!data.points.length||data.points.at(-1)!.date<dayTarget);
 const messages=[...new Set(data.stored.filter(s=>s.error&&needs.some(n=>n.symbol===s.symbol)).map(s=>s.error))];
 if(!connection)messages.push('Connect EODHD to update closing prices. Saved history remains available.');
 if(connection&&budgetUsed>=DAILY_CALL_LIMIT)messages.push('The tracker’s EODHD request guard has been reached. New price requests resume tomorrow.');
 const priceDates=holdings.map(h=>h.priceDate).filter((d):d is string=>!!d).sort();
 if(priceDates.length&&priceDates.at(-1)!<today)messages.push(`Latest available market close: ${priceDates.at(-1)}. Prices advance after each exchange closes; weekends and market holidays use the previous close.`);
 if(priceDates.at(-1)===today&&holdings.some(h=>h.priceDate&&h.priceDate<today))messages.push('Some exchanges are still using an earlier close. Their individual price dates are shown under Pricing coverage.');
 const activeIds=new Set(savedStates.flatMap(a=>a.holdings.map(h=>h.id)));
 const accounts=reconcileAccounts(savedStates,today,data.series);
 if(holdings.some(h=>h.stale))messages.push('Prices are older than the latest expected weekday close. These are carried-forward valuations, not new daily prices. Market holidays can also delay a close.');
 if(data.run.last_refresh)messages.push('Last completed refresh check: '+new Date(data.run.last_refresh).toISOString()+'. Refreshes run while OWL is open; there is no overnight scheduled job.');
 return {accounts,oldestPriceDate:priceDates[0]||null,newestPriceDate:priceDates.at(-1)||null,anomalyThresholdPercent:ANOMALY_THRESHOLD_PERCENT,startedAt:new Date(data.run.started_at).toISOString(),through:data.points.at(-1)?.date||'',points:data.points.map(({stateKey,...point})=>point),holdings:holdings.filter(h=>activeIds.has(h.id)),recordedPortfolioPence:recorded,currentPortfolioPence:current.point.portfolioPence,connection,refreshing:data.run.lease_until>now,pending:pendingPrices||pendingDays,budgetUsed,budgetLimit:DAILY_CALL_LIMIT,lastRefresh:data.run.last_refresh?new Date(data.run.last_refresh).toISOString():null,messages,mode:'catch-up'};
}

export async function trackingApi(request:Request,env:DatabaseEnv,userId:string){
 if(!['GET','POST'].includes(request.method))return json({error:'Method not allowed.'},405);
 try{
  const now=Date.now(),today=dayOf(now),db=database(env);
  await repairDemoPositions(env,userId);
  await repairReportedDeletion(env,userId);
  await db.batch(seedTracking(env,userId,now));
  // Revalue saved entries immediately using cached prices, even before today's
  // close and while another request owns the external-price refresh lease.
  await saveDays(env,userId,await read(env,userId),today);
  if(request.method==='POST'){
   const lease=crypto.randomUUID();
   const acquired=await db.prepare('UPDATE tracking_runs SET lease_token=?,lease_until=? WHERE user_id=? AND lease_until<=? RETURNING user_id').bind(lease,now+120000,userId,now).first();
   if(acquired){
    try{
     const data=await read(env,userId);const token=await credential(env,userId).catch(()=>null);
     await refreshPrices(env,userId,token,lease,data,today,today);
     // Include today's valuation as soon as a verified completed session is
     // present. Other exchanges retain their latest closes with their dates.
     await saveDays(env,userId,await read(env,userId),today);
     await db.prepare('UPDATE tracking_runs SET last_refresh=? WHERE user_id=? AND lease_token=?').bind(Date.now(),userId,lease).run();
    }finally{await db.prepare('UPDATE tracking_runs SET lease_until=0 WHERE user_id=? AND lease_token=?').bind(userId,lease).run();}
   }
  }
  return json(await responseData(env,userId,Date.now()));
 }catch{
  console.error('Portfolio tracking unavailable');
  return json({error:'Unable to update portfolio tracking. Your saved accounts and history have been kept. Please try again.'},503);
 }
}
