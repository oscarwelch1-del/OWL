import {database,type DatabaseEnv} from './database';
import {FUNDAMENTAL_FILTER,savedConstituents,topHoldings} from './constituents';
import {dateOnly,object,generalSection,providerGet,string,MarketError} from './market-provider';
import {inferredListing,quoteCurrency,type TrackedHolding} from '../lib/finance/tracker';
import type {Listing} from '../lib/finance/market';
import type {DirectClassification} from '../lib/finance/exposure';

type HoldingRow={id:string;name:string;type:string;ticker:string;isin:string;exchange:string|null;asset_class:string|null;listing_json:string|null};
type CheckRow={id:string;symbol:string;kind:string;data_json:string|null;checked_at:number;retry_after:number};
type Target={kind:'share'|'fund';listing:Listing;type:string};
const DAY=86400000;
const key=(kind:string,symbol:string)=>kind+':'+symbol;
export function exposureKind(type:string,assetClass:string|null):Target['kind']|null{
 if(['etf','fund','investment_trust'].includes(type))return 'fund';
 if(type==='share'||assetClass==='stock')return 'share';
 return null;
}

function listingFor(row:HoldingRow):Listing|null{
 if(row.listing_json){try{const value=JSON.parse(row.listing_json) as Listing;if(value?.symbol&&value.currency)return value;}catch{/* Fall through to the recorded ticker. */}}
 const holding:TrackedHolding={id:row.id,name:row.name,type:row.type,ticker:row.ticker,isin:row.isin,exchange:row.exchange||'',valuePence:0,quantity:'',quantityDate:'',listing:null};
 return inferredListing(holding);
}
function targets(rows:HoldingRow[]):Target[]{
 const unique=new Map<string,Target>();
 for(const row of rows){
  // An investment trust trades as a stock, but its look-through data is a
  // fund report. The saved instrument type takes priority over asset_class.
  const kind=exposureKind(row.type,row.asset_class);
  const listing=listingFor(row);if(!kind||!listing)continue;
  unique.set(key(kind,listing.symbol),{kind,listing,type:row.type});
 }
 return [...unique.values()].sort((a,b)=>a.kind.localeCompare(b.kind)||a.listing.symbol.localeCompare(b.listing.symbol));
}
export function normalizeClassification(payload:unknown,listing:Listing,now=Date.now()):DirectClassification|null{
 const general=generalSection(payload);
 if(string(general.Code).toUpperCase()!==listing.ticker.toUpperCase())return null;
 const type=string(general.Type);
 if(type&&!/^(Common Stock|Preferred Stock)$/i.test(type))return null;
 const currency=string(general.CurrencyCode);
 if(currency&&quoteCurrency(currency).currency!==quoteCurrency(listing.currency).currency)return null;
 const isin=string(general.ISIN);
 if(listing.isin&&isin&&listing.isin.toUpperCase()!==isin.toUpperCase())return null;
 const sector=string(general.Sector)||null,industry=string(general.Industry)||null,country=string(general.CountryName)||null;
 if(!sector&&!industry&&!country)return null;
 const updated=dateOnly(general.UpdatedAt);
 return {symbol:listing.symbol,sector,industry,country,asOf:updated&&updated<=new Date(now).toISOString().slice(0,10)?updated:null,retrievedAt:new Date(now).toISOString(),source:'EODHD'};
}
async function sourceRows(env:DatabaseEnv,userId:string){
 const db=database(env);
 const [holdings,checks]=await db.batch([
  db.prepare("SELECT h.id,h.name,h.type,h.ticker,h.isin,h.exchange,h.asset_class,m.listing_json FROM holdings h JOIN accounts a ON a.id=h.account_id LEFT JOIN market_listings m ON m.holding_id=h.id WHERE a.user_id=? AND (a.category='investment' OR (a.category='pension' AND a.kind<>'defined_benefit'))").bind(userId),
  db.prepare('SELECT id,symbol,kind,data_json,checked_at,retry_after FROM exposure_metadata WHERE user_id=?').bind(userId),
 ]);
 return {targets:targets(holdings.results as unknown as HoldingRow[]),checks:new Map((checks.results as unknown as CheckRow[]).map(row=>[key(row.kind,row.symbol),row]))};
}
export async function savedClassifications(env:DatabaseEnv,userId:string):Promise<Record<string,DirectClassification>>{
 const rows=await database(env).prepare("SELECT symbol,data_json FROM exposure_metadata WHERE user_id=? AND kind='share' AND data_json IS NOT NULL").bind(userId).all<{symbol:string;data_json:string}>();
 const result:Record<string,DirectClassification>={};
 for(const row of rows.results){try{const value=JSON.parse(row.data_json) as DirectClassification;if(value.symbol===row.symbol&&value.source==='EODHD')result[row.symbol]=value;}catch{/* An invalid old row remains unclassified. */}}
 return result;
}

async function due(env:DatabaseEnv,userId:string,values:Target[],checks:Map<string,CheckRow>,now:number,refreshAfter=0){
 const needed:Target[]=[];
 for(const target of values){
  const check=checks.get(key(target.kind,target.listing.symbol));
  if(refreshAfter){if(!check||check.checked_at<refreshAfter)needed.push(target);continue;}
  if(check&&check.retry_after>now)continue;
  if(target.kind==='fund'){
   const saved=await savedConstituents(env,userId,target.listing);
   if(saved&&!saved.stale&&now-Date.parse(saved.retrievedAt)<DAY)continue;
  }else if(check?.data_json&&now-check.checked_at<30*DAY)continue;
  needed.push(target);
 }
 return needed;
}

export async function exposureRefresh(env:DatabaseEnv,userId:string,token:string|null,refreshAfter=0){
 const now=Date.now(),db=database(env);
 const {targets:values,checks}=await sourceRows(env,userId);
 if(!token)return {remaining:values.length,refreshed:0,message:'Connect EODHD to load holdings, sectors and geography.'};
 const pending=await due(env,userId,values,checks,now,refreshAfter);
 let refreshed=0;
 // Two symbols per request bound worker time even when EODHD must classify
 // several constituent companies. A follow-up request picks up the rest.
 for(const target of pending.slice(0,2)){
  const symbol=target.listing.symbol,old=checks.get(key(target.kind,symbol));let dataJson:string|null=null,success=false;
  try{
   if(target.kind==='fund'){
    const result=await topHoldings(env,userId,target.listing,target.type,token,now,undefined,10,true);
    dataJson=JSON.stringify({status:result.status,stale:result.stale,holdingsCount:result.allHoldings?.length||result.holdings.length,warnings:result.warnings,checkedAt:new Date(now).toISOString()});
    if(result.status!=='ready'||result.stale)throw new Error('No new verified fund holdings');
   }else{
    const raw=await providerGet('v1.1/fundamentals/'+encodeURIComponent(symbol),token,{filter:'General'},refreshAfter?0:86400000);
    const value=normalizeClassification(raw,target.listing,now);
    if(!value)throw new Error('No verified company classification');
    dataJson=JSON.stringify(value);
   }
   refreshed++;success=true;
  }catch(error){if(target.kind==='fund'&&!dataJson)dataJson=JSON.stringify({status:'unavailable',warnings:[error instanceof MarketError?error.message:'The fund report could not be loaded.'],checkedAt:new Date(now).toISOString()});}
  const retryAfter=now+(success?DAY:60*60000);
  await db.prepare('INSERT INTO exposure_metadata (id,user_id,symbol,kind,data_json,checked_at,retry_after) VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET data_json=COALESCE(excluded.data_json,exposure_metadata.data_json),checked_at=excluded.checked_at,retry_after=excluded.retry_after').bind(userId+':'+key(target.kind,symbol),userId,symbol,target.kind,dataJson,now,retryAfter).run();
  checks.set(key(target.kind,symbol),{id:userId+':'+key(target.kind,symbol),symbol,kind:target.kind,data_json:dataJson||old?.data_json||null,checked_at:now,retry_after:retryAfter});
 }
 return {remaining:(await due(env,userId,values,checks,Date.now(),refreshAfter)).length,refreshed};
}

export async function savedExposureIssues(env:DatabaseEnv,userId:string){
 const {targets:values,checks}=await sourceRows(env,userId);
 return values.flatMap(target=>{const check=checks.get(key(target.kind,target.listing.symbol));if(target.kind!=='fund'||!check?.data_json)return [];
  try{const value=JSON.parse(check.data_json);return value.status==='unavailable'||value.stale?[{symbol:target.listing.symbol,message:Array.isArray(value.warnings)?value.warnings.join(' '):'Holdings unavailable',checkedAt:new Date(check.checked_at).toISOString()}]:[];}catch{return [];}
 });
}
