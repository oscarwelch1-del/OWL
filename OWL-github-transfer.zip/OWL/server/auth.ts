import { database, type DatabaseEnv } from './database';
import { validHash, verifyPassword, hex } from './password';
import { financeApi } from './finance';
import { instrumentSearchApi } from './instruments';
import { marketApi } from './market';

export const SESSION_COOKIE = '__Host-oscar_session';
export const SESSION_SECONDS = 8*60*60;
const RATE_SECONDS = 15*60;
const MAX_ATTEMPTS = 10;
const ACCOUNT_ID = 'owner';
const encoder = new TextEncoder();
const now = () => Math.floor(Date.now()/1000);
const digest = async (text:string) => hex(new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(text))));

export function cookieToken(request:Request) {
  const values = (request.headers.get('cookie') || '').split(';').map(v=>v.trim()).filter(v=>v.startsWith(`${SESSION_COOKIE}=`));
  if(values.length!==1) return null;
  const token=values[0].slice(SESSION_COOKIE.length+1);
  return /^[a-f0-9]{64}$/.test(token) ? token:null;
}
function setCookie(token:string, maxAge=SESSION_SECONDS) {
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
}
const json=(value:unknown,status=200,headers:Record<string,string>={}) => Response.json(value,{status,headers:{'Cache-Control':'no-store',...headers}});

async function ensureOwner(env:DatabaseEnv) {
  const db=database(env);
  const existing=await db.prepare('SELECT id FROM users WHERE id = ?').bind(ACCOUNT_ID).first();
  if(existing) return;
  if(!env.BOOTSTRAP_PASSWORD_HASH || !validHash(env.BOOTSTRAP_PASSWORD_HASH)) throw new Error('Account is not provisioned');
  // A deployment secret contains only a precomputed salted hash. No default
  // plaintext credential or public registration endpoint exists in source.
  // Idempotent initial provisioning never overwrites a saved password.
  await db.prepare('INSERT INTO users (id,username,display_name,password_hash,created_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO NOTHING').bind(ACCOUNT_ID,'oscar','Oscar',env.BOOTSTRAP_PASSWORD_HASH,now()).run();
}

export async function getSession(request:Request,env:DatabaseEnv) {
  const actor=request.headers.get('oai-authenticated-user-id');
  const token=cookieToken(request);
  if(!actor || !token) return null;
  return await database(env).prepare('SELECT u.id,u.username,u.display_name FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.platform_user_id=? AND s.expires_at>?').bind(await digest(token),actor,now()).first<{id:string;username:string;display_name:string}>();
}

function validOrigin(request:Request,env:DatabaseEnv) {
  if(!env.APP_ORIGIN) return false;
  const origin=request.headers.get('origin');
  const fetchSite=request.headers.get('sec-fetch-site');
  return origin===env.APP_ORIGIN && (!fetchSite || fetchSite==='same-origin');
}

async function readPayload(request:Request):Promise<unknown> {
  const reader=request.body?.getReader();
  if(!reader) throw new Error('Missing body');
  let length=0; const chunks:Uint8Array[]=[];
  while(true) {const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>2048){await reader.cancel();throw new Error('Body too large');}chunks.push(value);}
  const bytes=new Uint8Array(length);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}
  return JSON.parse(new TextDecoder().decode(bytes));
}

async function login(request:Request,env:DatabaseEnv) {
  if(!(request.headers.get('content-type')||'').toLowerCase().startsWith('application/json')) return json({error:'Use a JSON request.'},415);
  let payload:unknown;
  try {payload=await readPayload(request);}catch{return json({error:'Invalid sign-in request.'},400);}
  if(!payload || typeof payload!=='object')return json({error:'Invalid sign-in request.'},400);
  const {username,password}=payload as Record<string,unknown>;
  if(typeof username!=='string'||typeof password!=='string'||username.length<1||username.length>64||password.length<1||password.length>128)return json({error:'Enter your username and password.'},400);
  const actor=request.headers.get('oai-authenticated-user-id')!;
  const timestamp=now();
  const db=database(env);
  // One fixed account bucket also limits guesses across multiple identities.
  const limit=await db.prepare('INSERT INTO login_limits (bucket,attempts,reset_at) VALUES (?,1,?) ON CONFLICT(bucket) DO UPDATE SET attempts=CASE WHEN reset_at<=? THEN 1 ELSE attempts+1 END,reset_at=CASE WHEN reset_at<=? THEN excluded.reset_at ELSE reset_at END RETURNING attempts,reset_at').bind('owner-login',timestamp+RATE_SECONDS,timestamp,timestamp).first<{attempts:number;reset_at:number}>();
  if(!limit || limit.attempts>MAX_ATTEMPTS) return json({error:'Too many sign-in attempts. Please try again in 15 minutes.'},429,{'Retry-After':String(Math.max(1,(limit?.reset_at || timestamp+RATE_SECONDS)-timestamp))});
  await ensureOwner(env);
  const user=await db.prepare('SELECT id,password_hash FROM users WHERE username=?').bind(username.trim().toLowerCase()).first<{id:string;password_hash:string}>();
  // An unknown username performs the same password work and returns the same error.
  const ownerHash=user?.password_hash || (await db.prepare('SELECT password_hash FROM users WHERE id=?').bind(ACCOUNT_ID).first<{password_hash:string}>())!.password_hash;
  const matches=await verifyPassword(password,ownerHash);
  if(!user||!matches)return json({error:'Incorrect username or password.'},401);
  const token=hex(crypto.getRandomValues(new Uint8Array(32)));
  const oldToken=cookieToken(request);
  const writes=[db.prepare('DELETE FROM sessions WHERE expires_at<=?').bind(timestamp)];
  if(oldToken) writes.push(db.prepare('DELETE FROM sessions WHERE token_hash=? AND platform_user_id=?').bind(await digest(oldToken),actor));
  writes.push(db.prepare('INSERT INTO sessions (token_hash,user_id,platform_user_id,created_at,expires_at) VALUES (?,?,?,?,?)').bind(await digest(token),user.id,actor,timestamp,timestamp+SESSION_SECONDS));
  await db.batch(writes);
  return json({ok:true},200,{'Set-Cookie':setCookie(token)});
}

export async function authApi(request:Request,env:DatabaseEnv) {
  const path=new URL(request.url).pathname;
  if(!request.headers.get('oai-authenticated-user-id'))return json({error:'Sign in with your authorised ChatGPT account to continue.'},401);
  if(request.method==='POST'&&!validOrigin(request,env))return json({error:'Request origin rejected. Reload the page and try again.'},403);
  if(path==='/api/auth/login'&&request.method==='POST')return login(request,env);
  if(path==='/api/auth/logout'&&request.method==='POST') {
    const token=cookieToken(request);
    if(token)await database(env).prepare('DELETE FROM sessions WHERE token_hash=? AND platform_user_id=?').bind(await digest(token),request.headers.get('oai-authenticated-user-id')).run();
    return json({ok:true},200,{'Set-Cookie':setCookie('',0)});
  }
  if(path==='/api/auth/me'&&request.method==='GET') {
    const user=await getSession(request,env);
    return user ? json({username:user.username,displayName:user.display_name}):json({error:'Please sign in.'},401);
  }
  return json({error:'Not found.'},404);
}

export async function authGate(request:Request,env:DatabaseEnv):Promise<Response|null> {
  const path=new URL(request.url).pathname;
  try {
    if(path.startsWith('/api/auth/'))return await authApi(request,env);
    if(path.startsWith('/api/instruments/')){
      const user=await getSession(request,env);
      if(!user)return json({error:'Your session expired. Sign in again to continue.'},401);
      return await instrumentSearchApi(request,env,user.id);
    }
    if(path.startsWith('/api/market/')){
      const user=await getSession(request,env);
      if(!user)return json({error:'Your session expired. Sign in again to continue.'},401);
      if(request.method!=='GET'&&!validOrigin(request,env))return json({error:'Request origin rejected.'},403);
      return await marketApi(request,env,user.id);
    }
    if(path.startsWith('/api/finance/')){
      const user=await getSession(request,env);
      if(!user)return json({error:'Your session expired. Sign in again to continue.'},401);
      if(request.method!=='GET'&&!validOrigin(request,env))return json({error:'Request origin rejected.'},403);
      return await financeApi(request,env,user.id);
    }
    if(path.startsWith('/api/'))return json({error:'Not found.'},404);
    // Default-deny all application pages except the login page. Covers RSC,
    // direct URLs, encoded paths and any future finance pages automatically.
    if(!['/','/favicon.svg','/robots.txt'].includes(path) && !path.startsWith('/assets/') && !path.startsWith('/_next/static/')) {
      if(!await getSession(request,env))return new Response(null,{status:303,headers:{Location:'/', 'Cache-Control':'no-store'}});
    }
    return null;
  }catch {
    // Do not return SQL, credentials, submitted bodies or stack traces.
    console.error('Authentication storage or verification unavailable');
    if(path.startsWith('/api/'))return json({error:'Sign-in is temporarily unavailable. Please try again shortly.'},503);
    return new Response('Your workspace is temporarily unavailable. Please try again shortly.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'}});
  }
}
