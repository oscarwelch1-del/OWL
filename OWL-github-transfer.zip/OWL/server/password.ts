import { scryptAsync } from '@noble/hashes/scrypt.js';
import { timingSafeEqual } from 'node:crypto';

// OWASP scrypt baseline: 32 MiB, N=2^15, r=8, p=3.
// Encoded format is versioned and strictly bounded before any allocation.
export const HASH_PREFIX = 'scrypt-v1:32768:8:3:';
const PARAMS = {N:32768, r:8, p:3, dkLen:32, maxmem:40*1024*1024};
const encoder = new TextEncoder();
export const hex = (value: Uint8Array) => Array.from(value, b => b.toString(16).padStart(2,'0')).join('');
const unhex = (value:string) => Uint8Array.from(value.match(/.{2}/g)!, b => parseInt(b,16));
export function validHash(value: string) { return /^scrypt-v1:32768:8:3:[a-f0-9]{32}:[a-f0-9]{64}$/.test(value); }
export async function hashPassword(password:string) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const result = await scryptAsync(encoder.encode(password),salt,PARAMS);
  return `${HASH_PREFIX}${hex(salt)}:${hex(result)}`;
}
// Serialise memory-hard work within an isolate to avoid concurrent allocations.
let pending: Promise<unknown> = Promise.resolve();
export function verifyPassword(password:string, encoded:string):Promise<boolean> {
  if(!validHash(encoded)) return Promise.resolve(false);
  const task = pending.then(async () => {
    const [, , , , salt, expected] = encoded.split(':');
    const actual = await scryptAsync(encoder.encode(password),unhex(salt),PARAMS);
    return timingSafeEqual(actual,unhex(expected));
  });
  pending = task.catch(() => undefined);
  return task;
}
