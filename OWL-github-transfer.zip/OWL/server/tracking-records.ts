import {database,type DatabaseEnv} from './database';

// Construct state from the rows actually committed, never from an untrusted
// client snapshot. These statements also run inside version-gated D1 batches.
const stateSql=`json_object(
 'id',a.id,'name',a.name,'category',a.category,'kind',a.kind,
 'valuePence',a.value_pence,'ownershipBps',a.ownership_bps,'valuationDate',a.valuation_date,
 'holdings',json(COALESCE((SELECT json_group_array(json_object(
  'id',h.id,'name',h.name,'type',h.type,'ticker',h.ticker,'isin',h.isin,'exchange',COALESCE(h.exchange,''),
  'valuePence',h.value_pence,'quantity',COALESCE(json_extract(h.details_json,'$.quantity'),''),
  'priceCurrency',COALESCE(json_extract(h.details_json,'$.priceCurrency'),''),
  'quantityDate',COALESCE(NULLIF(json_extract(h.details_json,'$.priceDate'),''),a.valuation_date),
  'listing',json(m.listing_json)
 )) FROM holdings h LEFT JOIN market_listings m ON m.holding_id=h.id WHERE h.account_id=a.id),'[]'))
)`;

export function seedTracking(env:DatabaseEnv,userId:string,at=Date.now()):D1PreparedStatement[]{
 const db=database(env);
 return [
  db.prepare('INSERT INTO tracking_runs (user_id,started_at) VALUES (?,?) ON CONFLICT(user_id) DO NOTHING').bind(userId,at),
  db.prepare(`INSERT INTO tracking_revisions (user_id,account_id,recorded_at,state_json)
   SELECT a.user_id,a.id,?,${stateSql} FROM accounts a WHERE a.user_id=?
   AND NOT EXISTS (SELECT 1 FROM tracking_revisions r WHERE r.user_id=a.user_id AND r.account_id=a.id)`).bind(at,userId),
  // Existing imported accounts predate the quote-currency field in saved
  // tracking states. Record the current state once so their latest valuation
  // uses the statement's GBP/GBp unit without rewriting older history.
  db.prepare(`INSERT INTO tracking_revisions (user_id,account_id,recorded_at,state_json)
   SELECT a.user_id,a.id,?,${stateSql} FROM accounts a WHERE a.user_id=?
   AND EXISTS (SELECT 1 FROM json_each((SELECT r.state_json FROM tracking_revisions r
      WHERE r.user_id=a.user_id AND r.account_id=a.id ORDER BY r.seq DESC LIMIT 1),'$.holdings') j
      WHERE json_type(j.value,'$.priceCurrency') IS NULL AND json_extract(j.value,'$.quantity')<>'')`).bind(at,userId),
 ];
}

export function recordAccount(env:DatabaseEnv,userId:string,accountId:string,at:number,writeToken?:string){
 const db=database(env);
 const query=`INSERT INTO tracking_revisions (user_id,account_id,recorded_at,state_json)
  SELECT a.user_id,a.id,?,${stateSql} FROM accounts a WHERE a.user_id=? AND a.id=?${writeToken?' AND a.write_token=?':''}`;
 return db.prepare(query).bind(at,userId,accountId,...(writeToken?[writeToken]:[]));
}

export function recordDeletion(env:DatabaseEnv,userId:string,accountId:string,version:number,at:number){
 return database(env).prepare(`INSERT INTO tracking_revisions (user_id,account_id,recorded_at,state_json)
  SELECT user_id,id,?,NULL FROM accounts WHERE user_id=? AND id=? AND version=?`).bind(at,userId,accountId,version);
}
