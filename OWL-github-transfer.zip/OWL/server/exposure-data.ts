import {database,type DatabaseEnv} from './database';
import {savedConstituents} from './constituents';
import {savedClassifications} from './exposure-metadata';
import {buildExposure,type ExposureSnapshots} from '../lib/finance/exposure';
import {dayOf,valueDay,inferredListing,type TrackedAccount,type TrackedHolding,type Series} from '../lib/finance/tracker';
import type {Listing} from '../lib/finance/market';

// Current committed accounts + already cached tracker prices. Read-only: no
// price refresh, correction, revision or daily history writes are triggered.
export async function currentExposure(env:DatabaseEnv,userId:string){
 const db=database(env);
 const batch=await db.batch([
  db.prepare("SELECT id,name,category,kind,value_pence,ownership_bps,valuation_date FROM accounts WHERE user_id=? AND (category='investment' OR (category='pension' AND kind<>'defined_benefit'))").bind(userId),
  db.prepare('SELECT h.*,m.listing_json FROM holdings h JOIN accounts a ON a.id=h.account_id LEFT JOIN market_listings m ON m.holding_id=h.id WHERE a.user_id=?').bind(userId),
  db.prepare('SELECT symbol,data_json FROM tracking_series WHERE user_id=?').bind(userId),
 ]);
 const states:TrackedAccount[]=batch[0].results.map((a:any)=>({id:a.id,name:a.name,category:a.category,kind:a.kind,valuePence:a.value_pence,ownershipBps:a.ownership_bps,valuationDate:a.valuation_date,holdings:batch[1].results.filter((h:any)=>h.account_id===a.id).map((h:any):TrackedHolding=>{const d=JSON.parse(h.details_json||'{}');return {id:h.id,name:h.name,type:h.type,ticker:h.ticker,isin:h.isin,exchange:h.exchange||'',valuePence:h.value_pence,quantity:d.quantity||'',quantityDate:d.priceDate||a.valuation_date,listing:h.listing_json?JSON.parse(h.listing_json) as Listing:null};})}));
 const series=new Map<string,Series>(batch[2].results.map((r:any)=>[r.symbol,JSON.parse(r.data_json)]));
 const {point,holdings}=valueDay(states,dayOf(),series);
 const snapshots:ExposureSnapshots['snapshots']={};const seen=new Map<string,Awaited<ReturnType<typeof savedConstituents>>>();
 for(const h of states.flatMap(a=>a.holdings)){
  const listing=h.listing||inferredListing(h);
  if(!listing||!['etf','fund','investment_trust'].includes(h.type)){snapshots[h.id]=null;continue;}
  const key=JSON.stringify([listing.symbol,listing.isin,listing.currency]);
  if(!seen.has(key))seen.set(key,await savedConstituents(env,userId,listing));
  snapshots[h.id]=seen.get(key)||null;
 }
 const types=new Map(states.flatMap(a=>a.holdings).map(h=>[h.id,h.type]));
 return buildExposure(holdings.map(h=>({...h,type:types.get(h.id)||'other'})),snapshots,point.portfolioPence,Date.now(),await savedClassifications(env,userId));
}
