export interface DatabaseEnv { DB:D1Database; BOOTSTRAP_PASSWORD_HASH:string; APP_ORIGIN:string; EODHD_API_TOKEN?:string; MARKET_DATA_ENCRYPTION_KEY?:string; }
export function database(env:DatabaseEnv):D1Database {
  if(!env.DB) throw new Error('Authentication database unavailable');
  return env.DB;
}
