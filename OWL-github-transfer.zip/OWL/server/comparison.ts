import {database,type DatabaseEnv} from './database';
import {currentExposure} from './exposure-data';
import {credential} from './market';
import {providerGet} from './market-provider';
import {dayOf,shiftDay,normalizeCloses,normalizeSplits,type Series} from '../lib/finance/tracker';
import {compareBasket,ukBasket,comparisonRanges,UK_BENCHMARK,type ComparisonRange,type ComparisonResponse} from '../lib/finance/comparison';

type Cached={data_json:string|null;checked_at:number;retry_after:number;error:string};
// Prices are public market facts; user holdings and comparison weights are not cached here.
async function comparisonSeries(env:DatabaseEnv,symbol:string,from:string,through:string,token:string):Promise<Series|undefined>{
 const db=database(env),now=Date.now();
 const read=()=>db.prepare('SELECT data_json,checked_at,retry_after,error FROM comparison_prices WHERE symbol=?').bind(symbol).first<Cached>();
 const cached=await read();
 const decode=(row:Cached|null)=>{if(!row?.data_json)return undefined;try{const value=JSON.parse(row.data_json) as Series;return value.source==='eodhd'?value:undefined;}catch{return undefined;}};
 if(cached&&cached.retry_after>now&&decode(cached))return decode(cached);
 // Legacy Yahoo entries can be replaced immediately; concurrent EODHD requests use a short lease.
 const lease=await db.prepare('INSERT INTO comparison_prices (symbol,retry_after) VALUES (?,?) ON CONFLICT(symbol) DO UPDATE SET retry_after=excluded.retry_after WHERE comparison_prices.retry_after<=? OR comparison_prices.data_json LIKE ? RETURNING symbol').bind(symbol,now+30000,now,'%"source":"yahoo"%').first();
 if(!lease)return decode(await read());
 try{
  const prices=normalizeCloses(await providerGet('eod/'+encodeURIComponent(symbol),token,{from,to:through,period:'d',order:'a'},3600000),from,through);
  if(!prices.length)throw new Error('No completed EODHD closing prices');
  const splits=symbol.endsWith('.INDX')?[]:normalizeSplits(await providerGet('splits/'+encodeURIComponent(symbol),token,{from,to:through},3600000),from,through);
  const data:Series={symbol,prices,splits,from,through,splitsFrom:from,splitsThrough:through,source:'eodhd',splitAdjusted:false};
  await db.prepare("UPDATE comparison_prices SET data_json=?,checked_at=?,retry_after=?,error='' WHERE symbol=?").bind(JSON.stringify(data),now,now+6*3600000,symbol).run();
  return data;
 }catch{
  await db.prepare('UPDATE comparison_prices SET checked_at=?,retry_after=?,error=? WHERE symbol=?').bind(now,now+15*60000,'EODHD historical prices unavailable',symbol).run();
  return decode(cached);
 }
}

export async function comparisonApi(request:Request,env:DatabaseEnv,userId:string){
 if(request.method!=='POST')return Response.json({error:'Run a comparison using POST.'},{status:405});
 const url=new URL(request.url),range=url.searchParams.get('range')||'1M';
 if(!Object.hasOwn(comparisonRanges,range))return Response.json({error:'Choose 1M, 3M or 1Y.'},{status:400});
 if((url.searchParams.get('country')||'GB')!=='GB')return Response.json({error:'UK comparison is available first.'},{status:400});
 const through=shiftDay(dayOf(),-1),from=shiftDay(through,-comparisonRanges[range as ComparisonRange]);
 const exposure=await currentExposure(env,userId),basket=ukBasket(exposure.rows);
 const token=await credential(env,userId);
 const prices=new Map<string,Series>();let benchmark:Series|undefined;
 if(basket.members.length&&token){
  const historyFrom=shiftDay(through,-374);
  benchmark=await comparisonSeries(env,UK_BENCHMARK.symbol,historyFrom,through,token);
  if(benchmark){
   for(let i=0;i<basket.members.length;i+=3)await Promise.all(basket.members.slice(i,i+3).map(async member=>{const data=await comparisonSeries(env,member.symbol,historyFrom,through,token);if(data)prices.set(member.symbol,data);}));
  }
 }
 const result=compareBasket(basket,prices,benchmark,from,through);
 if(!token&&basket.members.length)result.messages=['Connect EODHD to compare your holdings with the benchmark.'];
 if(basket.knownUkPence&&!basket.members.length)result.messages=['The known UK exposure has no supported London identifiers yet. Check the exclusions below.'];
 const response:ComparisonResponse={...result,range:range as ComparisonRange,benchmark:UK_BENCHMARK,generatedAt:new Date().toISOString(),snapshotDates:[...new Set(exposure.rows.filter(r=>r.country==='United Kingdom').map(r=>r.asOf||'Date not supplied'))].sort(),unknownGeographyPence:exposure.totalPence-exposure.geographyClassifiedPence,totalPence:exposure.totalPence,priceSource:'EODHD',methodology:'current-basket-price-return-v1'};
 return Response.json(response,{headers:{'Cache-Control':'no-store'}});
}
