import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
const bundle=await build({entryPoints:['lib/finance/tracker.ts'],bundle:true,write:false,format:'esm',platform:'node'});
const m=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const listing=(currency='GBP',symbol='TEST.LSE')=>({symbol,currency,name:'Test',ticker:'TEST',exchange:'LSE',type:'Common Stock',isin:''});
const holding=(fields={})=>({id:'h',name:'Test',type:'share',ticker:'TEST',isin:'',valuePence:60000,quantity:'10',quantityDate:'2026-09-01',listing:listing(),...fields});
const account=(fields={})=>({id:'a',name:'ISA',category:'investment',kind:'stocks_isa',valuePence:100000,ownershipBps:10000,valuationDate:'2026-09-01',holdings:[holding()],...fields});
const series=(symbol,prices,fields={})=>({symbol,prices,splits:[],from:'2026-09-01',through:'2026-09-10',splitsFrom:'2026-09-01',splitsThrough:'2026-09-10',quoteCurrency:symbol.endsWith('.US')?'USD':'GBP',...fields});

test('GBP portfolio replaces allocated holdings, preserves residual cash, applies ownership, and excludes DB income',()=>{
 const a=account({ownershipBps:5000,holdings:[holding({listing:listing('USD','TEST.US')}),holding({id:'bond',name:'Gilt',type:'bond',valuePence:10000})]});
 const data=new Map([['TEST.US',series('TEST.US',[{date:'2026-09-04',close:100}])],['USDGBP.FOREX',series('USDGBP.FOREX',[{date:'2026-09-04',close:.8}])]]);
 const accounts=[a,account({id:'cash',category:'cash',valuePence:20000,holdings:[]}),account({id:'property',category:'property',valuePence:200000,ownershipBps:5000,holdings:[]}),account({id:'debt',category:'debt',valuePence:50000,holdings:[]}),account({id:'db',category:'pension',kind:'defined_benefit',valuePence:900000,holdings:[]}),account({id:'salary',category:'income',valuePence:300000,holdings:[]})];
 const {point,holdings}=m.valueDay(accounts,'2026-09-04',data);
 assert.equal(point.portfolioPence,60000);assert.equal(point.assetsPence,180000);assert.equal(point.debtPence,50000);assert.equal(point.netPence,130000);assert.equal(point.marketPence,40000);assert.equal(point.recordedPence,20000);assert.equal(holdings[0].valuePence,40000);
});

test('pence quote currencies are case sensitive; GBP is never divided by 100',()=>{
 const data=new Map([['TEST.LSE',series('TEST.LSE',[{date:'2026-09-04',close:100}])]]);
 for(const [currency,expected] of [['GBP',100000],['GBp',1000],['GBX',1000]]){data.get('TEST.LSE').quoteCurrency=currency;assert.equal(m.valueHolding(holding({listing:listing(currency)}),account(),'2026-09-04',data).valuePence,expected);}
});

test('London valuation uses the provider series currency, not the imported statement currency',()=>{
 const h=holding({ticker:'VWRL',exchange:'LN',listing:null,quantity:'112',valuePence:1167040,priceCurrency:'GBP'});
 const data=new Map([['VWRL.LSE',series('VWRL.LSE',[{date:'2026-09-04',close:141.09}])]]);
 assert.equal(m.valueHolding({...h,priceCurrency:'GBp'},account(),'2026-09-04',data).valuePence,1580208);
 assert.equal(m.valueHolding(h,account(),'2026-09-04',data).valuePence,1580208);
 data.get('VWRL.LSE').quoteCurrency=undefined;assert.equal(m.valueHolding(h,account(),'2026-09-04',data).status,'unavailable');
});

test('verified 2:1 split preserves value, while a quantity entered after the split is not doubled again',()=>{
 const data=new Map([['TEST.LSE',series('TEST.LSE',[{date:'2026-09-03',close:100},{date:'2026-09-04',close:50}],{splits:[{date:'2026-09-04',factor:2}]})]]);
 const before=m.valueHolding(holding(),account(),'2026-09-03',data),after=m.valueHolding(holding(),account(),'2026-09-04',data);
 assert.equal(before.valuePence,100000);assert.equal(after.valuePence,100000);assert.equal(after.quantity,20);
 assert.equal(m.valueHolding(holding({quantity:'20',quantityDate:'2026-09-04'}),account(),'2026-09-04',data).valuePence,100000);
});

test('weekends carry the actual price date, never use a future close, and expose stale data',()=>{
 const data=new Map([['TEST.LSE',series('TEST.LSE',[{date:'2026-09-04',close:50},{date:'2026-09-10',close:99}])]]);
 const sat=m.valueHolding(holding(),account(),'2026-09-05',data);
 assert.equal(sat.valuePence,50000);assert.equal(sat.priceDate,'2026-09-04');assert.equal(sat.status,'carried');
 assert.equal(m.valueDay([account()],'2026-09-09',data).point.stale,true);
});

test('missing quantity, listing, close, FX or split coverage retain the entered holding value',()=>{
 const h=holding({listing:listing('USD','TEST.US')});const data=new Map([['TEST.US',series('TEST.US',[{date:'2026-09-04',close:100}])]]);
 const cases=[[{...h,quantity:''},data],[{...h,listing:null},data],[h,new Map()],[h,data],[holding(),new Map([['TEST.LSE',series('TEST.LSE',[{date:'2026-09-04',close:100}],{splitsThrough:''})]])]];
 for(const [position,prices] of cases){const result=m.valueHolding(position,account(),'2026-09-04',prices);assert.equal(result.valuePence,60000);assert.equal(result.status,'unavailable');}
});

test('account revisions use the state known at each UTC day, including deletion and same-millisecond writes',()=>{
 const ms=day=>Date.parse(day+'T12:00:00Z');
 const original=account(),changed=account({holdings:[holding({quantity:'30'})]});
 const revisions=[{seq:1,accountId:'a',recordedAt:ms('2026-09-05'),state:original},{seq:2,accountId:'a',recordedAt:ms('2026-09-08'),state:changed},{seq:3,accountId:'a',recordedAt:ms('2026-09-08'),state:account({name:'Final',holdings:[holding({quantity:'31'})]})},{seq:4,accountId:'a',recordedAt:ms('2026-09-10'),state:null}];
 assert.equal(m.statesOn(revisions,'2026-09-04').length,0);assert.equal(m.statesOn(revisions,'2026-09-07')[0].holdings[0].quantity,'10');assert.equal(m.statesOn(revisions,'2026-09-09')[0].holdings[0].quantity,'31');assert.equal(m.statesOn(revisions,'2026-09-10').length,0);
});

test('a contribution or quantity edit cannot be reported as market gain; names can change safely',()=>{
 const data=new Map([['TEST.LSE',series('TEST.LSE',[{date:'2026-09-03',close:60},{date:'2026-09-04',close:66}])]]);
 const before=m.valueDay([account()],'2026-09-03',data).point;
 const market=m.valueDay([account({name:'Renamed ISA'})],'2026-09-04',data,before).point;
 assert.equal(market.marketChangePence,6000);assert.equal(market.accountChanges,false);
 const deposited=m.valueDay([account({valuePence:150000})],'2026-09-04',data,before).point;
 assert.equal(deposited.changePence,56000);assert.equal(deposited.marketChangePence,null);assert.equal(deposited.accountChanges,true);
 const changed=m.valueDay([account({holdings:[holding({quantity:'20'})]})],'2026-09-04',data,before).point;assert.equal(changed.marketChangePence,null);
});

test('raw close determines market value; adjusted close never invents dividend cash',()=>{
 assert.deepEqual(m.normalizeCloses([{date:'2026-09-04',close:100,adjusted_close:85}],'2026-09-01','2026-09-05'),[{date:'2026-09-04',close:100}]);
 assert.deepEqual(m.normalizeSplits([{date:'2026-09-04',split:'4.000000/1.000000'}],'2026-09-01','2026-09-05'),[{date:'2026-09-04',factor:4}]);
});

test('invalid provider rows and duplicate dates fail closed',()=>{
 for(const close of [NaN,Infinity,0,-1,'100'])assert.throws(()=>m.normalizeCloses([{date:'2026-09-04',close}],'2026-09-01','2026-09-05'));
 assert.throws(()=>m.normalizeCloses([{date:'2026-02-30',close:100}],'2026-01-01','2026-09-05'));
 assert.throws(()=>m.normalizeCloses([{date:'2026-09-04',close:1},{date:'2026-09-04',close:2}],'2026-09-01','2026-09-05'));
 assert.throws(()=>m.normalizeSplits([{date:'2026-09-04',split:'1/0'}],'2026-09-01','2026-09-05'));
 assert.throws(()=>m.normalizeCloses({error:'provider error'},'2026-09-01','2026-09-05'));
});


test('fractional ownership pennies reconcile between holdings, chart segments and account total',()=>{
 const positions=[holding({id:'a',quantity:'1',valuePence:1}),holding({id:'b',quantity:'1',valuePence:1})];
 const data=new Map([['TEST.LSE',series('TEST.LSE',[{date:'2026-09-04',close:.01}])]]);
 const {point,holdings}=m.valueDay([account({valuePence:2,ownershipBps:5000,holdings:positions})],'2026-09-04',data);
 assert.equal(point.portfolioPence,1);assert.equal(point.marketPence,1);assert.equal(point.recordedPence,0);assert.equal(holdings.reduce((n,h)=>n+h.valuePence,0),1);
});
