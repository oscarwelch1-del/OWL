import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
const bundle=await build({entryPoints:['lib/finance/exposure.ts'],bundle:true,write:false,format:'esm',platform:'node'});
const {buildExposure,groups,countryInfo}=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const position={id:'fund',name:'Test fund',accountName:'ISA',type:'etf',valuePence:1000000};
let identity=0;
const company=(weightPercent,sector='Technology',country='United States')=>({name:'Company',symbol:'EXAMPLE'+(++identity)+'.US',weightPercent,sector,industry:'Semiconductors',country,region:null});
const snapshot=(holdings,extra={})=>({status:'ready',holdings,source:'EODHD',retrievedAt:'2026-09-01T12:00:00Z',holdingsAsOf:null,stale:false,...extra});
test('an unseen direct share uses its verified EODHD company classification',()=>{
 const direct={id:'direct',name:'New Nordic Company',accountName:'ISA',type:'share',valuePence:70000,symbol:'NEW.ST'};
 const classification={symbol:'NEW.ST',sector:'Industrials',industry:'Industrial Machinery',country:'Sweden',asOf:'2026-09-01',retrievedAt:'2026-09-02T12:00:00Z',source:'EODHD'};
 const result=buildExposure([direct],{},70000,Date.parse('2026-09-03'),{'NEW.ST':classification});
 assert.equal(result.rows[0].country,'Sweden');assert.equal(result.rows[0].continent,'Europe');
 assert.equal(result.rows[0].sector,'Industrials');assert.equal(result.rows[0].industry,'Industrial Machinery');
 assert.equal(result.sectorClassifiedPence,70000);assert.equal(result.geographyClassifiedPence,70000);
});
test('partial holdings stay partial, account remainder stays in denominator, and totals reconcile',()=>{
 const result=buildExposure([position],{fund:snapshot([company(10)])},1200000);
 assert.equal(result.totalPence,1200000);assert.equal(result.sectorClassifiedPence,100000);assert.equal(result.geographyClassifiedPence,100000);
 assert.equal(result.rows.reduce((s,r)=>s+r.valuePence,0),1200000);
 assert.equal(groups(result.rows,'sector').find(r=>r.name==='Unclassified').valuePence,1100000);
});
test('complete saved lists are used rather than the UI top-ten slice',()=>{
 const result=buildExposure([position],{fund:snapshot([company(10)],{allHoldings:[company(10),company(20,'Industrials','United Kingdom')]})},1000000);
 assert.equal(result.sectorClassifiedPence,300000);assert.equal(groups(result.rows,'continent').find(r=>r.name==='Europe').valuePence,200000);
});
test('invalid weights withhold allocation and missing classifications are never guessed',()=>{
 for(const weights of [[company(101)],[company(-1)],[company(NaN)]])assert.equal(buildExposure([position],{fund:snapshot(weights)},1000000).sectorClassifiedPence,0);
 const r=buildExposure([position],{fund:snapshot([company(100,null,null)])},1000000);assert.equal(r.sectorClassifiedPence,0);assert.equal(r.geographyClassifiedPence,0);
 assert.equal(countryInfo('Unrecognised location').continent,'Unclassified');
 assert.equal(countryInfo('USA').continent,'North America');assert.equal(countryInfo('GB').continent,'Europe');
});
test('penny apportionment, repeated funds and empty portfolios are deterministic',()=>{
 const s=snapshot([company(33.3333),company(33.3333),company(33.3334)]);
 const r=buildExposure([{...position,valuePence:1},{...position,id:'fund2',valuePence:2}],{fund:s,fund2:s},3);
 assert.equal(r.totalPence,3);assert.equal(r.rows.reduce((n,x)=>n+x.valuePence,0),3);assert.equal(r.sectorClassifiedPence,3);
 assert.equal(buildExposure([],{},0).rows.length,0);
});
test('direct stocks await verified classification and snapshots are not mutated',()=>{
 const s=snapshot([company(100)]),before=JSON.stringify(s);
 assert.equal(buildExposure([{...position,type:'share'}],{fund:s},1000000).sectorClassifiedPence,0);
 buildExposure([position],{fund:s},1000000);assert.equal(JSON.stringify(s),before);
});
