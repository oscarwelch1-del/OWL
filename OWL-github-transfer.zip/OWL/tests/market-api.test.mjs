import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import { build } from 'esbuild';
import { Miniflare, createFetchMock } from 'miniflare';

test('market routes enforce session, origin and ownership; validate and encrypt credentials; save only provider-verified listings',async()=>{
 const bundle=await build({stdin:{contents:"import {authGate} from './server/auth.ts'; export default {async fetch(r,e){return await authGate(r,e) ?? new Response('Page')}};",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'neutral',external:['node:crypto'],conditions:['workerd','worker','browser']});
 const fetchMock=createFetchMock();fetchMock.disableNetConnect();const provider=fetchMock.get('https://eodhd.com');
 const key='private-test-provider-key';
 provider.intercept({path:path=>path.startsWith('/api/user?')&&path.includes(key)}).reply(200,{email:'test@example.test',dailyRateLimit:1000}).persist();
 provider.intercept({path:path=>path.startsWith('/api/user?')&&path.includes('invalid-key')}).reply(401,'sensitive diagnostic').persist();
 provider.intercept({path:path=>path.startsWith('/api/search/AAPL?')}).reply(200,[{Code:'AAPL',Exchange:'US',Name:'Apple Inc',Currency:'USD',Type:'Common Stock',ISIN:'US0378331005'}]).persist();
 provider.intercept({path:path=>path.startsWith('/api/eod/AAPL.US?')}).reply(200,[{date:'2024-03-01',close:100,open:99,high:102,low:98,volume:10}]).persist();
 provider.intercept({path:path=>path.startsWith('/api/real-time/AAPL.US?')}).reply(403,'not included').persist();
 provider.intercept({path:path=>path.startsWith('/api/v1.1/fundamentals/AAPL.US?')}).reply(403,'not included').persist();
 const mf=new Miniflare({modules:true,script:bundle.outputFiles[0].text,compatibilityDate:'2026-05-22',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],fetchMock,bindings:{APP_ORIGIN:'https://example.test',MARKET_DATA_ENCRYPTION_KEY:randomBytes(32).toString('base64')}});
 try{
  const db=await mf.getD1Database('DB');
  for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const sql of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint'))if(sql.trim())await db.prepare(sql.trim()).run();
  // Seed existing sessions: this suite tests the new market routes, not password sign-in.
  for(const id of ['owner','other'])await db.prepare('INSERT INTO users (id,username,display_name,password_hash,created_at) VALUES (?,?,?,?,?)').bind(id,id,id,'unused-by-this-test',Date.now()).run();
  const session=randomBytes(32).toString('hex');
  await db.prepare('INSERT INTO sessions (token_hash,user_id,platform_user_id,created_at,expires_at) VALUES (?,?,?,?,?)').bind(createHash('sha256').update(session).digest('hex'),'owner','owner-platform',Math.floor(Date.now()/1000),Math.floor(Date.now()/1000)+3600).run();
  const cookie='__Host-oscar_session='+session;
  for(const user of ['owner','other']){
   await db.prepare("INSERT INTO accounts (id,user_id,name,category,kind,provider,value_pence,ownership_bps,valuation_date,mode,remainder,notes,version,write_token,updated_at) VALUES (?,?,'ISA','investment','stocks_isa','Test',10000,10000,'2024-03-01','percent','cash','',1,'test',1)").bind(user+'-account',user).run();
   await db.prepare("INSERT INTO holdings (id,account_id,name,type,ticker,isin,amount,value_pence,position,asset_class) VALUES (?,?,'Apple Inc','share','AAPL','','100',10000,0,'stock')").bind(user+'-holding',user+'-account').run();
  }
  const call=(path,method='GET',body,headers={})=>mf.dispatchFetch('https://example.test/api/market'+path,{method,headers:{cookie,'oai-authenticated-user-id':'owner-platform',origin:'https://example.test','content-type':'application/json',...headers},...(body===undefined?{}:{body:JSON.stringify(body)})});
  assert.equal((await call('/connection','GET',undefined,{cookie:''})).status,401);
  assert.equal((await call('/connection','GET',undefined,{'oai-authenticated-user-id':'someone-else'})).status,401);
  assert.equal((await call('/connection','PUT',{token:key},{origin:'https://evil.example'})).status,403);
  assert.equal((await call('/holdings/other-holding')).status,404);
  assert.equal((await call('/holdings/other-holding/listing','DELETE')).status,404);
  assert.equal((await call('/holdings/owner-holding?range=9Y')).status,400);
  assert.equal((await (await call('/holdings/owner-holding')).json()).status,'setup_required');
  assert.deepEqual(await (await call('/connection')).json(),{configured:false,managed:false,canConfigure:true});
  assert.equal((await call('/connection','PUT',{token:'demo'})).status,400);
  const rejected=await call('/connection','PUT',{token:'invalid-key'});assert.equal(rejected.status,401,await rejected.clone().text());assert.ok(!(await rejected.text()).includes('sensitive diagnostic'));
  assert.equal(await db.prepare('SELECT * FROM market_connections').first(),null);
  const connected=await call('/connection','PUT',{token:key});assert.equal(connected.status,200,await connected.clone().text());
  const stored=await db.prepare('SELECT encrypted_token FROM market_connections').first();assert.ok(stored.encrypted_token.startsWith('v1:'));assert.ok(!stored.encrypted_token.includes(key));
  const status=await call('/connection');assert.equal(status.headers.get('cache-control'),'no-store');assert.deepEqual(await status.json(),{configured:true,managed:false,canConfigure:true});
  const choices=await (await call('/holdings/owner-holding')).json();assert.equal(choices.status,'select_listing');assert.equal(choices.candidates[0].symbol,'AAPL.US');
  assert.equal((await call('/holdings/owner-holding/listing','PUT',{symbol:'WRONG.US'})).status,400);
  assert.equal(await db.prepare('SELECT * FROM market_listings').first(),null);
  assert.equal((await call('/holdings/owner-holding/listing','PUT',{symbol:'AAPL.US',currency:'GBP'})).status,200);
  const saved=JSON.parse((await db.prepare('SELECT listing_json FROM market_listings').first()).listing_json);assert.equal(saved.currency,'USD');
  const detail=await (await call('/holdings/owner-holding')).json();assert.equal(detail.status,'ready');assert.equal(detail.quote.kind,'end-of-day');assert.equal(detail.quote.price,100);assert.ok(!JSON.stringify(detail).includes(key));
  assert.equal((await call('/holdings/owner-holding/listing','DELETE')).status,200);
  assert.equal((await (await call('/holdings/owner-holding')).json()).status,'select_listing');
  assert.equal((await call('/holdings/owner-holding/listing','PUT',{symbol:'AAPL.US'})).status,200);
  await db.prepare('DELETE FROM holdings WHERE id=?').bind('owner-holding').run();assert.equal(await db.prepare('SELECT * FROM market_listings').first(),null);
  assert.equal((await call('/connection','DELETE')).status,200);assert.equal(await db.prepare('SELECT * FROM market_connections').first(),null);
 }finally{await mf.dispose();await fetchMock.close();}
});
