import test from 'node:test';import assert from 'node:assert/strict';import {build} from 'esbuild';
const b=await build({entryPoints:['lib/finance/history-corrections.ts'],bundle:true,write:false,format:'esm',platform:'node'});
const {correctedHoldingHistory}=await import('data:text/javascript;base64,'+Buffer.from(b.outputFiles[0].text).toString('base64'));
const h=(id,valuePence)=>({id,valuePence});
const r=(seq,date,holdings,valuePence,accountId='isa')=>({seq,recordedAt:Date.parse(date),accountId,state:{id:accountId,valuePence,holdings}});
test('a deleted £10k position disappears from every historical account valuation while cash is preserved',()=>{
 const revisions=[r(1,'2026-01-01',[h('other',8000000)],8500000),r(2,'2026-01-02',[h('other',8000000),h('tesla',1000000)],9500000),r(3,'2026-09-15',[h('other',8000000)],8500000)];
 const original=structuredClone(revisions);const out=correctedHoldingHistory(revisions);
 assert.equal(out.from,'2026-01-02');assert.deepEqual(out.revisions.map(r=>r.state.valuePence),[8500000,8500000,8500000]);assert.deepEqual(revisions,original);
 assert.equal(out.revisions[1].state.holdings.length,1);
});
test('remove uses the original holding value at each date and does not erase another account or an account deletion',()=>{
 const rows=[r(1,'2026-01-01',[h('tesla',1000000)],1000100),r(2,'2026-02-01',[h('tesla',1200000)],1200100),r(3,'2026-03-01',[],100),r(4,'2026-01-01',[h('tesla',1000000)],1000000,'lisa'),{...r(5,'2026-09-01',[],0,'lisa'),state:null}];
 const out=correctedHoldingHistory(rows);assert.deepEqual(out.revisions.slice(0,3).map(r=>r.state.valuePence),[100,100,100]);assert.equal(out.revisions[3].state.valuePence,1000000);
});
