import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
const bundle=await build({stdin:{contents:"export * from './lib/finance/overview-valuation';export * from './lib/finance/model';",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'node'});
const m=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
test('overview reconciles current assets, debts, holdings and weights without changing statement inputs',()=>{
 const make=(id,category,value,ownershipBps=10000)=>({...m.newAccount(category),id,name:id,value:String(value/100),valuePence:value,ownershipBps,ownership:String(ownershipBps/100),holdings:[]});
 const isa=make('isa','investment',100000);isa.mode='value';isa.holdings=[{...m.newHolding(),id:'fund',name:'Fund',amount:'900',valuePence:90000}];
 const property=make('home','property',1000000,5000),cash=make('cash','cash',20000),debt=make('debt','debt',30000);
 const accounts=[isa,property,cash,debt],before=JSON.stringify(accounts);
 const view=m.overviewValuation(accounts,{accounts:[{id:'isa',latestPence:110000},{id:'home',latestPence:500000},{id:'cash',latestPence:20000},{id:'debt',latestPence:30000}],holdings:[{id:'fund',valuePence:100000}]});
 assert.equal(view.totals.assets,630000);assert.equal(view.totals.net,600000);assert.equal(view.totals.investedAccounts,110000);
 assert.equal(view.holdingValue(isa.holdings[0])+m.allocate(isa).remaining,view.accountValue(isa));
 assert.equal(m.percent(view.holdingValue(isa.holdings[0]),view.accountValue(isa)),'90.91%');
 assert.equal(JSON.stringify(accounts),before);
 assert.equal(m.overviewValuation(accounts,null).accountValue(isa),100000);
});
test('roundoff is repaired but material excess precision still requires correction',()=>{
 assert.equal(m.canonicalUnitPrice('7.6225000000000005'),'7.6225');
 assert.equal(m.canonicalUnitPrice('202.72500000000002'),'202.725');
 assert.equal(m.canonicalUnitPrice('1.123456789'),'1.123456789');
});
