import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import { build } from 'esbuild';
import { Miniflare, createFetchMock } from 'miniflare';

test('import-sized account writes are atomic, scoped and preserve matching listings and pension records',async()=>{
 const [worker,model]=await Promise.all([
  build({stdin:{contents:"import {authGate} from './server/auth.ts'; export default {async fetch(r,e){return await authGate(r,e) ?? new Response('Page')}};",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'neutral',external:['node:crypto'],conditions:['workerd','worker','browser']}),
  build({stdin:{contents:"export * from './lib/finance/model';export * from './lib/finance/holding-balance';",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'node'})
 ]);
 const m=await import('data:text/javascript;base64,'+Buffer.from(model.outputFiles[0].text).toString('base64'));
 const mock=createFetchMock();mock.disableNetConnect();
 const mf=new Miniflare({modules:true,script:worker.outputFiles[0].text,compatibilityDate:'2026-05-22',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],fetchMock:mock,bindings:{APP_ORIGIN:'https://example.test'}});
 try{
  const db=await mf.getD1Database('DB');
  for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const sql of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint'))if(sql.trim())await db.prepare(sql.trim()).run();
  for(const id of ['owner','other'])await db.prepare('INSERT INTO users (id,username,display_name,password_hash,created_at) VALUES (?,?,?,?,?)').bind(id,id,id,'unused',Date.now()).run();
  const token=randomBytes(32).toString('hex');const now=Math.floor(Date.now()/1000);
  await db.prepare('INSERT INTO sessions (token_hash,user_id,platform_user_id,created_at,expires_at) VALUES (?,?,?,?,?)').bind(createHash('sha256').update(token).digest('hex'),'owner','owner-platform',now,now+3600).run();
  const headers={cookie:'__Host-oscar_session='+token,'oai-authenticated-user-id':'owner-platform',origin:'https://example.test','content-type':'application/json'};
  const call=(method='GET',body,extra={})=>mf.dispatchFetch('https://example.test/api/finance/accounts',{method,headers:{...headers,...extra},...(body===undefined?{}:{body:JSON.stringify(body)})});
  const toDraft=({valuePence,ownershipBps,updatedAt,...a})=>({...a,holdings:a.holdings.map(({valuePence,...h})=>h)});
  let draft={...m.newAccount(),name:'ISA',value:'1000',mode:'value',holdings:[{...m.newHolding(),name:'Example trust',ticker:'EXT',exchange:'LN',type:'investment_trust',amount:'900',details:{...m.blankHoldingDetails(),quantity:'300',unitPrice:'3',priceCurrency:'GBP',priceDate:'2024-01-01'}},{...m.newHolding(),name:'Cash GBP',type:'cash',amount:'100'}]};
  assert.equal((await call('PUT',draft,{cookie:''})).status,401);
  assert.equal((await call('PUT',draft,{origin:'https://evil.example'})).status,403);
  const created=await call('PUT',draft);assert.equal(created.status,200,await created.clone().text());
  let saved=(await created.json()).account;assert.equal(saved.holdings.length,2);assert.equal(saved.holdings[0].details.quantity,'300');
  // Previously published demo repair metadata must not poison manual edits.
  await db.prepare("UPDATE holdings SET details_json=json_set(details_json,'$.quantitySource','demo allocation / verified EODHD close','$.unitPrice','7.6225000000000005') WHERE id=?").bind(saved.holdings[0].id).run();
  const loaded=(await (await call()).json()).accounts.find(a=>a.id===saved.id);assert.ok(!('quantitySource' in loaded.holdings[0].details));
  assert.equal(loaded.holdings[0].details.unitPrice,'7.6225');saved=loaded;
  await db.prepare('INSERT INTO market_listings (holding_id,listing_json,selected_at) VALUES (?,?,?)').bind(saved.holdings[0].id,JSON.stringify({symbol:'EXT.LSE'}),Date.now()).run();
  const stale=toDraft(saved);draft=toDraft(saved);draft.holdings[0].details.quantity='301';draft.holdings[0].amount='903';draft.holdings[1].amount='97';
  draft.holdings[0].details.quantitySource='demo allocation / verified EODHD close';draft.holdings[0].details.unitPrice='202.72500000000002';
  const updated=await call('PUT',draft);assert.equal(updated.status,200,await updated.clone().text());saved=(await updated.json()).account;
  assert.equal(saved.holdings[0].details.unitPrice,'202.725');assert.equal(saved.valuePence,100000);assert.equal(saved.holdings.length,2);assert.equal(saved.holdings[0].details.quantity,'301');
  assert.ok(await db.prepare('SELECT * FROM market_listings WHERE holding_id=?').bind(saved.holdings[0].id).first());
  assert.equal((await call('PUT',stale)).status,409);assert.equal((await (await call()).json()).accounts[0].holdings[0].details.quantity,'301');
  draft=toDraft(saved);draft.holdings[0].ticker='DIFFERENT';const changed=await call('PUT',draft);assert.equal(changed.status,200);saved=(await changed.json()).account;
  assert.equal(await db.prepare('SELECT * FROM market_listings WHERE holding_id=?').bind(saved.holdings[0].id).first(),null);
  const pension={...m.newAccount('pension'),name:'Pension unchanged',provider:'Retained provider',value:'5000',details:{...m.blankAccountDetails(),employeeContribution:'250',employerContribution:'300',contributionFrequency:'monthly'}};
  const pensionSave=await call('PUT',pension);assert.equal(pensionSave.status,200);const originalPension=(await pensionSave.json()).account;
  const income={...m.newAccount('income'),name:'Employment',details:{...m.blankAccountDetails(),netAmount:'2400',incomeFrequency:'monthly'}};
  const incomeSave=await call('PUT',income);assert.equal(incomeSave.status,200);assert.equal((await incomeSave.json()).account.valuePence,240000);
  const data=await (await call()).json();assert.deepEqual(data.accounts.find(a=>a.id===pension.id),originalPension);assert.equal(data.snapshots[0].assetsPence,600000);
  const otherId=crypto.randomUUID();await db.prepare("INSERT INTO accounts (id,user_id,name,category,kind,provider,value_pence,ownership_bps,valuation_date,mode,remainder,notes,version,write_token,updated_at) VALUES (?,?,'Other','investment','gia','',10000,10000,'2024-01-01','value','unassigned','',1,'test',1)").bind(otherId,'other').run();
  const attempt={...toDraft(saved),id:otherId,version:1};assert.equal((await call('PUT',attempt)).status,400);
  assert.equal((await call('DELETE',{id:otherId,version:1})).status,409);
  // Foreign account IDs are rejected even without another account's child IDs.
  assert.equal((await call('PUT',{...attempt,holdings:[]})).status,409);
  const before=await db.prepare('SELECT * FROM accounts WHERE id=?').bind(otherId).first();assert.equal(before.user_id,'other');assert.equal(before.value_pence,10000);
  assert.equal((await call('PUT',{...toDraft(saved),value:'1'})).status,400);
  // Exercise the same editor calculation through persistence and the chart,
  // without asking any market provider for new data.
  const tracker=()=>mf.dispatchFetch('https://example.test/api/finance/tracker',{headers});
  const starting=(await (await tracker()).json()).points.at(-1).portfolioPence;
  const tesla={...m.newHolding(),name:'Tesla',ticker:'TSLA',exchange:'US',type:'share',amount:'10000'};
  const expanded=m.editHoldingBalance(toDraft(saved),[...saved.holdings.map(({valuePence,...h})=>h),tesla]);
  const expansion=await call('PUT',expanded);assert.equal(expansion.status,200,await expansion.clone().text());saved=(await expansion.json()).account;
  assert.equal((await (await tracker()).json()).points.at(-1).portfolioPence,starting+1000000);
  const deletion=await call('PUT',m.removeHolding(toDraft(saved),tesla.id));assert.equal(deletion.status,200,await deletion.clone().text());saved=(await deletion.json()).account;
  await db.prepare('UPDATE tracking_runs SET lease_until=? WHERE user_id=?').bind(Date.now()+60000,'owner').run();
  const corrected=await (await tracker()).json();assert.equal(corrected.points.at(-1).portfolioPence,starting);assert.equal(corrected.budgetUsed,0);assert.equal(corrected.refreshing,true);
  const removed=await call('PUT',{...toDraft(saved),holdings:[]});assert.equal(removed.status,200);assert.equal((await removed.json()).account.holdings.length,0);
  const hidden=await mf.dispatchFetch('https://example.test/workspace/analyse',{redirect:'manual'});assert.notEqual(hidden.status,200);
 }finally{await mf.dispose();await mock.close();}
});
