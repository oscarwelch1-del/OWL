import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
const bundle=await build({stdin:{contents:"export * from './lib/finance/insights.ts';",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'node'});
const {portfolioInsights}=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const position=(id,valuePence,type='etf')=>({id,name:id,accountName:'ISA',valuePence,type});
const row=(extra={})=>({holdingId:'fund-a',holdingName:'Fund A',accountName:'ISA',name:'Company A',symbol:'AAA.US',direct:false,valuePence:1000,sector:'Technology',industry:'Software',country:'United States of America',continent:'North America',source:'EODHD',basis:'Reported',asOf:null,retrievedAt:null,stale:false,reason:null,...extra});
test('partial coverage uses the full portfolio denominator, combines identities and preserves unclassified exposure',()=>{
 const rows=[row(),row({holdingId:'fund-b',valuePence:2000}),row({holdingId:'direct',direct:true,valuePence:500}),row({symbol:null,valuePence:6500,sector:'Unclassified',country:'Unclassified',reason:'Missing holdings'})];
 const result=portfolioInsights([position('fund-a',3000),position('fund-b',5500),position('direct',500,'share'),position('cash',1000,'cash')],rows,10000);
 assert.equal(result.company.valuePence,3500);assert.equal(result.topTen,3500);assert.equal(result.count,1);
 assert.equal(result.countryUnknown,6500);assert.equal(result.sectorUnknown,6500);assert.equal(result.cash,1000);
 assert.equal(result.largest.id,'fund-b');assert.equal(result.overlapCount,1);assert.equal(result.overlap.contributions.length,3);
 assert.equal(result.warnings.some(w=>w.label==='Top 10 identified holdings'),false);
});
test('cash excludes unassigned balances; unknown identifiers and zero positions do not inflate counts',()=>{
 const result=portfolioInsights([position('cash',2000,'cash'),position('empty',0)], [row({symbol:null,valuePence:8000}),row({symbol:null,valuePence:2000,reason:'Cash allocation'})],10000);
 assert.equal(result.cash,2000);assert.equal(result.count,0);assert.equal(result.largest,null);assert.equal(result.overlap,null);
 assert.deepEqual(portfolioInsights([],[],0).warnings,[]);
});
test('review thresholds include the boundary and deterministic ranking breaks equal-value ties',()=>{
 const r=portfolioInsights([position('b',2500),position('a',2500)], [row({valuePence:4000}),row({symbol:'BBB.US',name:'Company B',valuePence:2000})],10000);
 assert.equal(r.largest.id,'a');assert.equal(r.warnings.find(w=>w.label==='a').threshold,25);
 assert.equal(r.warnings.find(w=>w.label==='Technology sector').threshold,40);
 assert.equal(r.warnings.find(w=>w.label==='United States of America').threshold,60);
 assert.equal(r.warnings.find(w=>w.label==='Top 10 identified holdings').value,6000);
});
