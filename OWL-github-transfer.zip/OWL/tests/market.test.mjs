import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { build } from 'esbuild';

const bundle=await build({stdin:{contents:"export * from './server/market.ts'; export * from './server/market-provider.ts'; export * from './lib/finance/market.ts';",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'node'});
const market=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const listing={symbol:'VTI.US',ticker:'VTI',exchange:'US',currency:'USD',name:'Vanguard Total Stock Market ETF',isin:'US9229087690',type:'ETF'};

test('keeps currency units explicit and missing numbers unavailable',()=>{
 assert.equal(market.priceText(125.5,'GBX'),'125.50p');
 assert.equal(market.priceText(125.5,'GBp'),'125.50p');
 assert.equal(market.priceText(1.255,'GBP'),'1.26 GBP');
 for(const value of [null,undefined,NaN,Infinity])assert.equal(market.priceText(value,'USD'),'Unavailable');
 for(const value of [null,undefined,'','NA',true,[],Infinity])assert.equal(market.number(value),null);
 assert.equal(market.number('0'),0);
});
test('matches ISIN precisely while preserving different trading currencies',()=>{
 const payload=[
  {Code:'VWRL',Exchange:'LSE',Name:'Vanguard',Currency:'GBX',Type:'ETF',ISIN:'IE00B3RBWM25'},
  {Code:'VWRD',Exchange:'LSE',Name:'Vanguard',Currency:'USD',Type:'ETF',ISIN:'IE00B3RBWM25'},
  {Code:'VWRL',Exchange:'US',Name:'Different security',Currency:'USD',Type:'ETF',ISIN:'US9229087690'},
  {Code:'VWRL',Exchange:'XETRA',Name:'Missing identity',Currency:'EUR',Type:'ETF'},
  {Code:'VWRL',Exchange:'LSE',Name:'Derivative',Currency:'GBX',Type:'Option',ISIN:'IE00B3RBWM25'},
 ];
 assert.deepEqual(market.normalizeListings(payload,{ticker:'VWRL',isin:'IE00B3RBWM25'}).map(r=>[r.symbol,r.currency]),[['VWRL.LSE','GBX'],['VWRD.LSE','USD']]);
 assert.equal(market.normalizeListings(payload,{ticker:'INTC',isin:''}).length,0);
});
test('does not accept a wrong symbol, fabricated timestamp or invalid close',()=>{
 const row={code:'VTI.US',close:100,timestamp:Math.floor(Date.now()/1000),open:'NA',volume:0};
 assert.equal(market.normalizeQuote(row,'VTI.US').open,null);
 assert.equal(market.normalizeQuote(row,'VTI.US').volume,0);
 assert.equal(market.normalizeQuote(row,'VTI.LSE'),null);
 assert.equal(market.normalizeQuote({...row,timestamp:row.timestamp+600},'VTI.US'),null);
 assert.equal(market.normalizeQuote({...row,close:'NA'},'VTI.US'),null);
});
test('normalizes actual observations without filling missing days',()=>{
 assert.deepEqual(market.normalizeDaily([
  {date:'2024-02-30',close:100},{date:'2024-03-03',close:'NA'},
  {date:'2024-03-04',close:104},{date:'2024-03-01',close:100},
  {date:'2024-03-04',close:105},{date:'2099-01-01',close:999},
 ]).map(r=>[r.date,r.close]),[['2024-03-01',100],['2024-03-04',105]]);
 assert.equal(market.rangeStart('1M',new Date('2024-03-31')), '2024-02-29');
 assert.equal(market.rangeStart('1Y',new Date('2024-02-29')), '2023-02-28');
 assert.equal(market.rangeStart('YTD',new Date('2024-06-05')), '2024-01-01');
 assert.equal(market.rangeStart('MAX'),undefined);
});
test('one-day chart contains only the latest available trading session',()=>{
 const times=['2024-03-01T15:00:00Z','2024-03-04T15:00:00Z','2024-03-04T16:00:00Z'];
 const result=market.normalizeIntraday(times.map((date,i)=>({timestamp:Date.parse(date)/1000,close:100+i})),'US');
 assert.deepEqual(result.map(r=>r.time),times.slice(1).map(t=>new Date(t).toISOString()));
});
test('does not turn partial history into a 52-week range or missing values into zero',()=>{
 const rows=market.normalizeDaily([{date:new Date().toISOString().slice(0,10),high:110,low:90,close:100,volume:5}]);
 const stats=market.normalizeStats({General:{CurrencyCode:'USD'},ETF_Data:{Yield:'1.030000',NetExpenseRatio:'0.00030'}},listing,rows);
 assert.equal(stats.high52,null);assert.equal(stats.low52,null);assert.equal(stats.averageVolume,null);
 assert.equal(stats.dividendYield,1.03);assert.equal(stats.expenseRatio,0.03);assert.equal(stats.marketCap,null);
 assert.equal('nav' in stats,false);
});
test('encrypts each saved token and binds decryption to its owner',async()=>{
 const env={MARKET_DATA_ENCRYPTION_KEY:randomBytes(32).toString('base64')};
 const value=await market.encryptToken('test-private-key','owner',env);
 assert.ok(!value.includes('test-private-key'));
 assert.notEqual(value,await market.encryptToken('test-private-key','owner',env));
 assert.equal(await market.decryptToken(value,'owner',env),'test-private-key');
 await assert.rejects(market.decryptToken(value,'someone-else',env));
 await assert.rejects(market.decryptToken(value.slice(0,-4)+'AAAA','owner',env));
 await assert.rejects(market.decryptToken(value,'owner',{MARKET_DATA_ENCRYPTION_KEY:randomBytes(32).toString('base64')}));
});
test('preserves useful closing data when quote or intraday access is denied; withholds mismatched fundamentals',async()=>{
 const original=globalThis.fetch;const calls=[];
 globalThis.fetch=async url=>{
  calls.push(String(url));const path=new URL(url).pathname;
  if(path.includes('/eod/'))return Response.json([{date:'2024-03-01',open:99,high:102,low:98,close:100,volume:10},{date:'2024-03-04',open:100,high:105,low:99,close:103,volume:12}]);
  if(path.includes('/fundamentals/'))return Response.json({General:{Code:'WRONG',CurrencyCode:'USD'},Highlights:{MarketCapitalization:123456789}});
  return new Response('provider sensitive diagnostic', {status:403});
 };
 try{
  const result=await market.detail(listing,'1D','unit-'+randomBytes(8).toString('hex'));
  assert.equal(result.status,'ready');assert.equal(result.quote.kind,'end-of-day');assert.equal(result.quote.time,'2024-03-04');assert.equal(result.quote.previousClose,100);
  assert.deepEqual(result.points,[]);assert.equal(result.stats.marketCap,null);
  assert.ok(result.warnings.some(w=>w.includes('did not match')));
  assert.ok(!JSON.stringify(result).includes('sensitive diagnostic'));assert.equal(calls.length,4);
 }finally{globalThis.fetch=original;}
});
