import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
const bundle=await build({entryPoints:['lib/finance/tracker.ts'],bundle:true,write:false,format:'esm',platform:'node'});
const m=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
// The exact seven cached closes and quantities behind the reported £4,108,077.
const input=[['CSUK',20272.5,'GBX',9000],['SWDA',11094,'GBX',20000],['IITU',4033,'GBX',16000],['IEUX',4715.5,'GBX',11000],['INRG',762.25,'GBX',6000],['VFEM',62.43,'GBP',14000],['VWRL',141.09,'GBP',24000]];
const account={id:'demo',name:'DEMO',category:'investment',kind:'portfolio',valuePence:10000000,ownershipBps:10000,valuationDate:'2026-09-23',holdings:input.map(([ticker,,,value])=>({id:ticker,name:ticker,type:'etf',ticker,isin:'',exchange:'LSE',valuePence:value*100,quantity:'100',quantityDate:'2026-09-23',priceCurrency:'GBP',listing:null}))};
const series=new Map(input.map(([ticker,close,quoteCurrency])=>[ticker+'.LSE',{symbol:ticker+'.LSE',prices:[{date:'2026-09-23',close}],splits:[],from:'2026-09-23',through:'2026-09-23',splitsFrom:'2026-09-23',splitsThrough:'2026-09-23',source:'eodhd',splitAdjusted:false,quoteCurrency}]));
test('reported 41x inflation is reproduced by wrong units and corrected at source',()=>{
 assert.equal(input.reduce((sum,[,close])=>sum+100*close,0),4108077);
 const result=m.valueDay([account],'2026-09-23',series);
 assert.equal(result.point.portfolioPence,6122925);
 assert.equal(result.holdings.reduce((n,h)=>n+h.valuePence,0),result.point.portfolioPence);
 const rows=m.reconcileAccounts([account],'2026-09-23',series);
 assert.equal(rows.length,1);assert.equal(rows[0].recordedPence,10000000);assert.equal(rows[0].latestPence,6122925);
 const unverified=new Map([...series].map(([key,value])=>[key,{...value,quoteCurrency:undefined}]));
 const safe=m.valueDay([account],'2026-09-23',unverified);
 assert.equal(safe.point.portfolioPence,10000000);assert.equal(safe.point.unavailableCount,7);
});
test('missing Thursday/Friday closes are stale on Saturday, while Friday closes carry normally',()=>{
 const day=m.valueDay([account],'2026-09-26',series);
 assert.equal(day.point.carriedCount,7);assert.equal(day.point.stale,true);
 const friday=new Map([...series].map(([key,value])=>[key,{...value,prices:value.prices.map(p=>({...p,date:'2026-09-25'})),splitsThrough:'2026-09-25'}]));
 assert.equal(m.valueDay([account],'2026-09-26',friday).point.stale,false);
});
test('account additions are labelled and empty states are distinguishable from real zero balances',()=>{
 assert.equal(m.valueDay([],'2026-09-22',series).point.investmentAccountCount,0);
 assert.equal(m.valueDay([{...account,valuePence:0,holdings:[]}],'2026-09-22',series).point.investmentAccountCount,1);
 assert.deepEqual(m.adjustmentLabels([],[account]),['Account added: DEMO']);
 assert.deepEqual(m.adjustmentLabels([account],[]),['Account removed: DEMO']);
});
test('20% alert fires for an unexplained move and suppresses returns, but not for an account edit',()=>{
 const previous=m.valueDay([account],'2026-09-23',series).point;
 const next={...previous,date:'2026-09-24',portfolioPence:previous.portfolioPence*2,netPence:previous.netPence*2,accountChanges:false};
 m.applyAnomalyCheck(next,previous);assert.equal(next.anomalies.portfolioPence,100);assert.equal(m.dailyPercentage(next,previous),null);
 next.accountChanges=true;m.applyAnomalyCheck(next,previous);assert.deepEqual(next.anomalies,{});
});
