import { test } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, scryptSync, createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import { build } from 'esbuild';
import { Miniflare } from 'miniflare';

test('private authentication lifecycle against a real local D1 database', async () => {
  const password=randomBytes(24).toString('hex');
  const salt=randomBytes(16);
  const encoded=`scrypt-v1:32768:8:3:${salt.toString('hex')}:${scryptSync(password,salt,32,{N:32768,r:8,p:3,maxmem:40*1024*1024}).toString('hex')}`;
  const bundle=await build({stdin:{contents:"import {authGate} from './server/auth.ts'; export default {async fetch(r,e){return await authGate(r,e) ?? new Response('Protected page')}};",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'neutral',external:['node:crypto'],conditions:['workerd','worker','browser']});
  const mf=new Miniflare({modules:true,script:bundle.outputFiles[0].text,compatibilityDate:'2026-05-22',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],bindings:{BOOTSTRAP_PASSWORD_HASH:encoded,APP_ORIGIN:'https://example.test'}});
  try {
    const db=await mf.getD1Database('DB');
    for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort()) {
      for(const sql of (await readFile(`drizzle/${file}`,'utf8')).split('--> statement-breakpoint')) if(sql.trim())await db.prepare(sql.trim()).run();
    }
    const request=(path,opts={})=>mf.dispatchFetch(`https://example.test${path}`,{redirect:'manual',...opts,headers:{'oai-authenticated-user-id':'owner-platform-id',...opts.headers}});
    const login=(body,extra={})=>request('/api/auth/login',{method:'POST',body:JSON.stringify(body),headers:{origin:'https://example.test','content-type':'application/json',...extra}});
    const reset=()=>db.prepare('DELETE FROM login_limits').run();
    assert.equal((await request('/workspace')).status,303);
    assert.equal((await request('/workspace?_rsc=probe')).status,303);
    assert.equal((await request('/future-finance-page')).status,303);
    assert.equal((await request('/api/auth/me')).status,401);
    assert.equal((await login({username:'oscar',password},{'oai-authenticated-user-id':''})).status,401);
    assert.equal((await login({username:'oscar',password},{origin:'https://evil.example'})).status,403);
    assert.equal((await login({username:'oscar',password},{origin:''})).status,403);
    assert.equal((await login({username:'oscar',password:'x'.repeat(3000)})).status,400);
    assert.equal((await request('/api/auth/register',{method:'POST',headers:{origin:'https://example.test'}})).status,404);
    const wrong=await login({username:'oscar',password:'wrong'});
    assert.equal(wrong.status,401);
    const wrongBody=await wrong.json();
    const unknown=await login({username:"' OR 1=1 --",password});
    assert.equal(unknown.status,401);assert.deepEqual(await unknown.json(),wrongBody);
    const good=await login({username:'oscar',password});assert.equal(good.status,200);
    const header=good.headers.get('set-cookie');
    for(const part of ['HttpOnly','Secure','SameSite=Strict','Path=/','Max-Age=28800'])assert.ok(header.includes(part));
    const cookie=header.split(';')[0];const token=cookie.split('=')[1];
    const stored=await db.prepare('SELECT * FROM sessions').first();
    assert.notEqual(stored.token_hash,token);
    assert.equal(stored.token_hash,createHash('sha256').update(token).digest('hex'));
    assert.equal((await db.prepare('SELECT password_hash FROM users').first()).password_hash,encoded);
    const me=await request('/api/auth/me',{headers:{cookie}});assert.equal(me.status,200);assert.deepEqual(await me.json(),{username:'oscar',displayName:'Oscar'});
    assert.equal((await request('/workspace',{headers:{cookie}})).status,200);
    assert.equal((await request('/api/auth/me',{headers:{cookie,'oai-authenticated-user-id':'different-user'}})).status,401);
    assert.equal((await request('/api/auth/me',{headers:{cookie:cookie.slice(0,-1)+(cookie.endsWith('a')?'b':'a')}})).status,401);
    const rotated=await login({username:'oscar',password},{cookie});const newCookie=rotated.headers.get('set-cookie').split(';')[0];
    assert.notEqual(cookie,newCookie);assert.equal((await request('/api/auth/me',{headers:{cookie}})).status,401);
    assert.equal((await request('/api/auth/logout',{method:'POST',headers:{cookie:newCookie,origin:'https://evil.example'}})).status,403);
    const logout=await request('/api/auth/logout',{method:'POST',headers:{cookie:newCookie,origin:'https://example.test'}});assert.equal(logout.status,200);assert.ok(logout.headers.get('set-cookie').includes('Max-Age=0'));
    assert.equal((await request('/api/auth/me',{headers:{cookie:newCookie}})).status,401);
    const expired=await login({username:'oscar',password});const expiredCookie=expired.headers.get('set-cookie').split(';')[0];
    await db.prepare('UPDATE sessions SET expires_at=0').run();assert.equal((await request('/api/auth/me',{headers:{cookie:expiredCookie}})).status,401);
    await reset();
    const guesses=await Promise.all(Array.from({length:12},()=>login({username:'oscar',password:'wrong'})));
    assert.equal(guesses.filter(r=>r.status===401).length,10);assert.equal(guesses.filter(r=>r.status===429).length,2);
    assert.equal((await login({username:'oscar',password})).status,429);
    await db.prepare('UPDATE login_limits SET reset_at=0').run();assert.equal((await login({username:'oscar',password})).status,200);
    await db.prepare('DROP TABLE sessions').run();assert.equal((await request('/api/auth/me',{headers:{cookie:expiredCookie}})).status,503);
  } finally {await mf.dispose();}
});
