import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {createHash,randomBytes} from 'node:crypto';
import {build} from 'esbuild';
import {Miniflare,createFetchMock} from 'miniflare';

test('constituent route verifies access, reuses saved data, preserves changed snapshots and retains verified data on a provider failure',async()=>{
 const fixture=JSON.parse(await readFile('tests/fixtures/eodhd-vti-2026-09-12.json','utf8'));
 const bundle=await build({stdin:{contents:"import {authGate} from './server/auth.ts';export default {async fetch(r,e){return await authGate(r,e)??new Response('Page')}}",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'neutral',conditions:['workerd','worker','browser'],external:['node:crypto']});
 const mock=createFetchMock();mock.disableNetConnect();let requests=0;
 mock.get('https://eodhd.com').intercept({path:p=>p.startsWith('/api/v1.1/fundamentals/VTI.US?')}).reply(()=>{requests++;return {statusCode:200,data:JSON.stringify(fixture)};}).persist();
 mock.get('https://eodhd.com').intercept({path:p=>p.startsWith('/api/search/'+fixture.ETF_Data.ISIN+'?')}).reply(200,[{Code:'VTI',Exchange:'US',Name:'Vanguard',Currency:'USD',Type:'ETF',ISIN:fixture.ETF_Data.ISIN}]).persist();
 const mf=new Miniflare({modules:true,script:bundle.outputFiles[0].text,compatibilityDate:'2026-05-22',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],fetchMock:mock,bindings:{APP_ORIGIN:'https://example.test',EODHD_API_TOKEN:'unit-test-private-key'}});
 try{
  const db=await mf.getD1Database('DB');
  for(const f of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const sql of (await readFile('drizzle/'+f,'utf8')).split('--> statement-breakpoint'))if(sql.trim())await db.prepare(sql.trim()).run();
  const listing={symbol:'VTI.US',ticker:'VTI',name:'Vanguard',exchange:'US',currency:'USD',isin:fixture.ETF_Data.ISIN,type:'ETF'};
  for(const user of ['owner','other']){
   await db.prepare('INSERT INTO users (id,username,display_name,password_hash,created_at) VALUES (?,?,?,?,?)').bind(user,user,user,'unused',1).run();
   await db.prepare("INSERT INTO accounts (id,user_id,name,category,kind,provider,value_pence,ownership_bps,valuation_date,mode,remainder,notes,version,write_token,updated_at) VALUES (?,?,'ISA','investment','stocks_isa','',10000,10000,'2026-09-10','value','cash','',1,'seed',1)").bind(user+'-a',user).run();
   await db.prepare("INSERT INTO holdings (id,account_id,name,type,ticker,isin,amount,value_pence,position) VALUES (?,?,'Vanguard','etf','VTI',?,'100',10000,0)").bind(user+'-h',user+'-a',listing.isin).run();
   await db.prepare('INSERT INTO market_listings (holding_id,listing_json,selected_at) VALUES (?,?,?)').bind(user+'-h',JSON.stringify(listing),1).run();
  }
  const session=randomBytes(32).toString('hex');const now=Math.floor(Date.now()/1000);
  await db.prepare('INSERT INTO sessions (token_hash,user_id,platform_user_id,created_at,expires_at) VALUES (?,?,?,?,?)').bind(createHash('sha256').update(session).digest('hex'),'owner','platform-owner',now,now+3600).run();
  const headers={cookie:'__Host-oscar_session='+session,'oai-authenticated-user-id':'platform-owner',origin:'https://example.test'};
  const call=(id='owner-h',overrides={},method='GET')=>mf.dispatchFetch('https://example.test/api/market/holdings/'+id+'/constituents',{method,headers:{...headers,...overrides}});
  assert.equal((await call('owner-h',{cookie:''})).status,401);assert.equal((await call('other-h')).status,404);assert.equal((await call('owner-h',{},'POST')).status,405);assert.equal(requests,0);
  const [one,two]=await Promise.all([call(),call()]);const a=await one.json();const b=await two.json();
  assert.equal(a.status,'ready');assert.equal(b.status,'ready');assert.equal(a.coveragePercent,31.87);assert.equal(requests,1);assert.ok(!JSON.stringify(a).includes('private-key'));
  const cached=await (await call()).json();assert.equal(cached.cached,true);assert.equal(requests,1);
  const exposure=()=>mf.dispatchFetch('https://example.test/api/market/exposure',{headers});
  assert.equal((await mf.dispatchFetch('https://example.test/api/market/exposure')).status,401);
  const view=await (await exposure()).json();
  assert.deepEqual(Object.keys(view.snapshots),['owner-h']);assert.equal(view.snapshots['owner-h'].holdings.length,10);assert.equal(requests,1,'Exposure reads must not call providers');
  // A newer normalized observation appends and a failure keeps both saved lists.
  const saved=(await db.prepare('SELECT * FROM fund_constituent_snapshots WHERE user_id=?').bind('owner').all()).results;
  assert.ok(saved.length>=1);const prior=saved[0];const changed={...a,retrievedAt:new Date(Date.now()+1000).toISOString(),holdings:a.holdings.map((h,i)=>i===0?{...h,weightPercent:6}:h),coveragePercent:31.55,otherPercent:68.45};
  await db.prepare('INSERT INTO fund_constituent_snapshots (id,user_id,listing_key,symbol,data_hash,data_json,retrieved_at) VALUES (?,?,?,?,?,?,?)').bind('new-snapshot','owner',prior.listing_key,'VTI.US','new',JSON.stringify(changed),Date.now()+1000).run();
  assert.equal((await (await call()).json()).holdings[0].weightPercent,6);
  assert.ok((await db.prepare('SELECT COUNT(*) AS n FROM fund_constituent_snapshots WHERE user_id=?').bind('owner').first()).n>=2);
  assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM fund_constituent_snapshots WHERE user_id=?').bind('other').first()).n,0);
  // Switch the verified listing identity: the earlier snapshot must not leak in.
  await db.prepare('UPDATE market_listings SET listing_json=? WHERE holding_id=?').bind(JSON.stringify({...listing,symbol:'OTHER.US',ticker:'OTHER',isin:'DIFFERENT'}),'owner-h').run();
  assert.equal((await (await exposure()).json()).snapshots['owner-h'],null,'A changed listing cannot reuse another instrument snapshot');
  const fail=await (await call()).json();assert.equal(fail.status,'unavailable');assert.deepEqual(fail.holdings,[]);assert.equal(fail.coveragePercent,null);
  // A previously unselected imported holding with ticker and exchange should
  // show its EODHD report immediately, without a manual listing confirmation.
  await db.prepare('DELETE FROM market_listings WHERE holding_id=?').bind('owner-h').run();
  await db.prepare('UPDATE holdings SET exchange=? WHERE id=?').bind('US','owner-h').run();
  const imported=await (await call()).json();assert.equal(imported.status,'ready');assert.equal(imported.holdings[0].symbol,'NVDA.US');
  assert.equal(await db.prepare('SELECT * FROM market_listings WHERE holding_id=?').bind('owner-h').first(),null);
  // Manual refresh bypasses recent saved reports, but each subsequent batch
  // in the same sweep must skip symbols it has already checked.
  const before=requests;
  const refresh=await (await mf.dispatchFetch('https://example.test/api/market/exposure?refresh=1',{method:'POST',headers})).json();
  assert.equal(requests,before+1);assert.equal(refresh.remaining,0);assert.ok(refresh.refreshAfter);
  const again=await (await mf.dispatchFetch('https://example.test/api/market/exposure?after='+refresh.refreshAfter,{method:'POST',headers})).json();
  assert.equal(requests,before+1);assert.equal(again.refreshed,0);
  // A second listing of the exact same ISIN can provide holdings while the
  // chosen trading listing and its price currency remain untouched.
  const london={...listing,symbol:'VTI.LSE',exchange:'LSE',currency:'GBP'};
  await db.prepare('INSERT INTO market_listings (holding_id,listing_json,selected_at) VALUES (?,?,?)').bind('owner-h',JSON.stringify(london),Date.now()).run();
  mock.get('https://eodhd.com').intercept({path:p=>p.startsWith('/api/v1.1/fundamentals/VTI.LSE?')}).reply(200,{General:{Code:'VTI',CurrencyCode:'GBP',Type:'ETF'},ETF_Data:{ISIN:listing.isin}}).persist();
  const alternate=await (await call()).json();assert.equal(alternate.status,'ready');assert.equal(alternate.symbol,'VTI.LSE');assert.equal(alternate.sourceSymbol,'VTI.US');assert.equal(alternate.holdings[0].symbol,'NVDA.US');
  assert.deepEqual(JSON.parse((await db.prepare('SELECT listing_json FROM market_listings WHERE holding_id=?').bind('owner-h').first()).listing_json),london);
 }finally{await mf.dispose();await mock.close();}
});
