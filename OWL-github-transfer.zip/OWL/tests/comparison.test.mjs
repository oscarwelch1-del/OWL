import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
const b=await build({stdin:{contents:"export * from './lib/finance/comparison.ts'",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'node'});
const m=await import('data:text/javascript;base64,'+Buffer.from(b.outputFiles[0].text).toString('base64'));
const row=(symbol='AAA.L',valuePence=600,country='United Kingdom')=>({symbol,valuePence,country,name:symbol||'Private',holdingName:'Fund A'});
const dates=['2026-08-03','2026-08-04','2026-08-05'];
const series=(symbol,closes,splits=[])=>({symbol,prices:dates.map((date,i)=>({date,close:closes[i]})),splits,from:dates[0],through:dates[2],splitsFrom:dates[0],splitsThrough:dates[2],source:'eodhd',splitAdjusted:false});
const benchmark=series('FTSE100.INDX',[100,101,105]);
test('current weights are applied at the start and buy-and-hold return differs from daily rebalancing',()=>{
 const basket=m.ukBasket([row(),row('BBB.LSE',400)]);
 const result=m.compareBasket(basket,new Map([['AAA.LSE',series('AAA.LSE',[100,200,110])],['BBB.LSE',series('BBB.LSE',[100,50,90])]]),benchmark,dates[0],dates[2]);
 assert.equal(result.status,'ready');assert.equal(result.points[0].basket,100);assert.ok(Math.abs(result.basketReturnPercent-2)<1e-10);assert.equal(result.benchmarkReturnPercent,5);assert.ok(Math.abs(result.differencePp+3)<1e-10);assert.equal(result.coveragePercent,100);
});
test('overlap is aggregated by verified listing; missing listings remain in coverage denominator',()=>{
 const basket=m.ukBasket([row(),{...row('AAA.LSE',200),holdingName:'Fund B'},row(null,200),row('OTHER.US',200,'United States')]);
 assert.equal(basket.members.length,1);assert.equal(basket.members[0].valuePence,800);assert.deepEqual(basket.members[0].heldThrough,['Fund A','Fund B']);assert.equal(basket.knownUkPence,1000);
 const r=m.compareBasket(basket,new Map([['AAA.LSE',series('AAA.LSE',[100,105,110])]]),benchmark,dates[0],dates[2]);
 assert.equal(r.coveragePercent,80);assert.equal(r.included[0].weightPercent,100);assert.ok(r.messages.some(x=>x.includes('Partial')));assert.equal(r.excluded.length,1);
});
test('split correction does not become a spurious 50% loss and dividends are not invented',()=>{
 const r=m.compareBasket(m.ukBasket([row()]),new Map([['AAA.LSE',series('AAA.LSE',[100,100,50],[{date:dates[2],factor:2}])]]),benchmark,dates[0],dates[2]);
 assert.equal(r.basketReturnPercent,0);
});
test('IPOs or missing end prices exclude a company for the entire window',()=>{
 const short=series('BBB.LSE',[10,11,12]);short.prices.shift();
 const r=m.compareBasket(m.ukBasket([row(),row('BBB.LSE',400)]),new Map([['AAA.LSE',series('AAA.LSE',[100,105,110])],['BBB.LSE',short]]),benchmark,dates[0],dates[2]);
 assert.equal(r.coveragePercent,60);assert.equal(r.excluded[0].symbol,'BBB.LSE');assert.equal(r.included[0].weightPercent,100);
});
test('unknown benchmarks, stale windows and malformed data never produce a chart',()=>{
 const basket=m.ukBasket([row()]),prices=new Map([['AAA.LSE',series('AAA.LSE',[100,105,110])]]);
 for(const bench of [undefined,{...benchmark,symbol:'WRONG'},{...benchmark,splitsThrough:''},{...benchmark,prices:[...benchmark.prices,benchmark.prices[0]]}])assert.equal(m.compareBasket(basket,prices,bench,dates[0],dates[2]).status,'unavailable');
 assert.equal(m.compareBasket(basket,prices,benchmark,'2026-07-01',dates[2]).status,'unavailable');
 assert.equal(m.londonSymbol('RPRX.US'),null);assert.equal(m.londonSymbol('LSE'),null);
});
test('request cap is disclosed rather than silently dropping companies',()=>{
 const basket=m.ukBasket([row('A.L',10),row('B.L',20),row('C.L',30)],2);
 assert.equal(basket.knownUkPence,60);assert.equal(basket.members.length,2);assert.equal(basket.excluded[0].valuePence,10);
});
test('isolated missing closes remove the same date from both chart lines',()=>{
 const manyDates=Array.from({length:20},(_,i)=>`2026-08-${String(i+1).padStart(2,'0')}`);
 const full={...benchmark,from:manyDates[0],through:manyDates.at(-1),splitsFrom:manyDates[0],splitsThrough:manyDates.at(-1),prices:manyDates.map((date,i)=>({date,close:100+i}))};
 const stock={...full,symbol:'AAA.LSE',prices:full.prices.filter((_,i)=>i!==7)};
 const r=m.compareBasket(m.ukBasket([row()]),new Map([['AAA.LSE',stock]]),full,manyDates[0],manyDates.at(-1));
 assert.equal(r.status,'ready');assert.equal(r.points.length,19);assert.ok(!r.points.some(p=>p.date===manyDates[7]));assert.ok(r.messages.some(s=>s.includes('1 trading dates')));
});
test('FTSE benchmark uses the EODHD index identifier',()=>{
 assert.equal(m.UK_BENCHMARK.symbol,'FTSE100.INDX');
});
