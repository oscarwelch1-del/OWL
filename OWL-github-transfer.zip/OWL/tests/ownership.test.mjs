import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
const bundle=await build({stdin:{contents:"export * from './lib/finance/ownership.ts';export * from './lib/finance/exposure.ts';",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'node'});
const m=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const row=(extra={})=>({holdingId:'fund-a',holdingName:'Fund A',accountName:'ISA',name:'Company',symbol:'AAA.LSE',isin:null,direct:false,valuePence:100,sector:'Technology',industry:'Software',country:'United Kingdom',continent:'Europe',basis:'Source',source:'EODHD',asOf:'2026-09-01',retrievedAt:'2026-09-20T12:00:00Z',stale:false,reason:null,...extra});
test('listing aliases combine fund and direct positions and all contributions reconcile',()=>{
 const rows=[row(),row({symbol:'AAA.L',holdingId:'fund-b',holdingName:'Fund B',source:'Baillie Gifford',valuePence:200}),row({holdingId:'direct',direct:true,valuePence:50,reason:'Company classification not yet available'})];
 const r=m.ownership(rows,1000);assert.equal(r.groups.length,1);assert.equal(r.top(5),350);assert.equal(r.unknownPence,650);assert.equal(r.groups[0].directPence,50);assert.equal(r.groups[0].fundCount,2);assert.equal(r.overlapPence,350);
 assert.equal(r.groups[0].contributions.reduce((n,x)=>n+x.valuePence,0),r.groups[0].valuePence);
});
test('ISIN links different listings, while distinct share classes remain separate',()=>{
 const r=m.ownership([row({isin:'GB0000000001'}),row({isin:'GB0000000001',symbol:'OTHER.US'}),row({isin:'GB0000000002',symbol:'CLASSB.US'})],300);
 assert.equal(r.groups.length,2);assert.equal(r.groups[0].valuePence,200);
});
test('same-name private companies and unsupported direct ticker names never merge',()=>{
 const r=m.ownership([row({symbol:null}),row({symbol:null,holdingId:'fund-b'}),row({symbol:'AAA',direct:true})],300);
 assert.equal(r.groups.length,0);assert.equal(r.unresolved.length,3);assert.equal(r.unknownPence,300);
});
test('conflicting ISINs make symbol-only matches unresolved',()=>{
 const r=m.ownership([row({isin:'GB0000000001'}),row({isin:'GB0000000002'}),row()],300);
 assert.equal(r.groups.length,2);assert.equal(r.unresolved.length,1);assert.equal(r.identifiedPence,200);
});
test('missing fund allocation never becomes an identified company; top twenty retains full denominator',()=>{
 const r=m.ownership([row(),row({symbol:null,reason:'Remaining fund allocation is not classified',valuePence:900})],1000);
 assert.equal(r.top(20),100);assert.equal(r.unknownPence,900);assert.equal(r.unresolved.length,0);
 assert.equal(m.ownership([],0).top(1),0);
});
test('coverage separates undated, old, partial, missing and invalid snapshots',()=>{
 const p={id:'f',name:'Fund',type:'etf',accountName:'ISA',valuePence:1000};
 const h={name:'Company',symbol:'AAA.US',weightPercent:100,sector:'Technology',country:'United States'};
 const s={status:'ready',holdings:[h],source:'EODHD',holdingsAsOf:null,retrievedAt:'2026-09-22T00:00:00Z',stale:false};
 const report=(snapshot)=>m.fundCoverage([p],{f:snapshot},Date.parse('2026-09-22T00:00:00Z'))[0];
 assert.equal(report(s).completeness,'Full allocation');assert.equal(report(s).freshness,'Holdings date unknown');
 assert.equal(report({...s,holdingsAsOf:'2026-01-01'}).freshness,'Older than 90 days');
 assert.equal(report({...s,reportedCount:20}).completeness,'Partial');
 assert.equal(report({...s,holdings:[{...h,weightPercent:40}]}).weight,40);
 assert.equal(report(null).completeness,'Missing');assert.equal(report({...s,holdings:[h,h]}).completeness,'Needs review');
 const result=m.buildExposure([p],{f:{...s,holdings:[{...h,weightPercent:40},{...h,weightPercent:40}]}},1000);
 assert.equal(result.sectorClassifiedPence,0);assert.equal(result.totalPence,1000);
});
test('fund count uses position IDs, not duplicate account display names',()=>{
 const r=m.ownership([row(),row({holdingId:'fund-b'})],200);assert.equal(r.groups[0].fundCount,2);assert.equal(r.groups[0].overlap,true);
});
test('direct identities survive exposure calculation without invented classifications',()=>{
 const exposure=m.buildExposure([{id:'direct',name:'Company',type:'share',accountName:'ISA',valuePence:500,isin:'GB0000000001',symbol:'AAA.LSE'}],{},500);
 assert.equal(exposure.rows[0].isin,'GB0000000001');assert.equal(exposure.sectorClassifiedPence,0);
 const r=m.ownership(exposure.rows,500);assert.equal(r.identifiedPence,500);assert.equal(r.groups[0].directPence,500);
});
