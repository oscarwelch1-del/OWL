import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {createHash,randomBytes} from 'node:crypto';
import {build} from 'esbuild';
import {Miniflare,createFetchMock} from 'miniflare';

test('private comparison uses server-owned weights, caches EODHD history and does not mutate tracking',async()=>{
 const bundle=await build({stdin:{contents:"import {authGate} from './server/auth.ts';export default {async fetch(r,e){return await authGate(r,e)??new Response('Page')}}",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'neutral',conditions:['workerd','worker','browser'],external:['node:crypto']});
 const mock=createFetchMock();mock.disableNetConnect();let requests=0;
 const today=new Date().toISOString().slice(0,10),through=new Date(Date.parse(today)-86400000).toISOString().slice(0,10);
 const dates=[];for(let n=374;n>=0;n--){const d=new Date(Date.parse(through)+86400000*(-n));if(d.getUTCDay()!==0&&d.getUTCDay()!==6)dates.push(d.toISOString().slice(0,10));}
 const provider=mock.get('https://eodhd.com');
 provider.intercept({path:p=>p.startsWith('/api/eod/')}).reply(options=>{requests++;const symbol=decodeURIComponent(options.path.split('/api/eod/')[1].split('?')[0]);if(symbol==='FAIL.LSE')return {statusCode:429,data:'Rate limited'};return {statusCode:200,data:JSON.stringify(dates.map((date,i)=>({date,close:100+i*(symbol==='FTSE100.INDX'?0.2:0.3)})))};}).persist();
 provider.intercept({path:p=>p.startsWith('/api/splits/')}).reply(200,[]).persist();
 const mf=new Miniflare({modules:true,script:bundle.outputFiles[0].text,compatibilityDate:'2026-05-22',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],fetchMock:mock,bindings:{APP_ORIGIN:'https://example.test',EODHD_API_TOKEN:'private-eodhd-test-token'}});
 try{
  const db=await mf.getD1Database('DB');
  for(const f of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const sql of (await readFile('drizzle/'+f,'utf8')).split('--> statement-breakpoint'))if(sql.trim())await db.prepare(sql.trim()).run();
  const listing={symbol:'VTI.US',ticker:'VTI',name:'Fund',exchange:'US',currency:'USD',isin:'US9229087690',type:'ETF'};
  const key=createHash('sha256').update(JSON.stringify([listing.symbol,listing.isin,listing.currency])).digest('hex');
  for(const user of ['owner','other']){
   await db.prepare('INSERT INTO users (id,username,display_name,password_hash,created_at) VALUES (?,?,?,?,?)').bind(user,user,user,'unused',1).run();
   await db.prepare("INSERT INTO accounts (id,user_id,name,category,kind,provider,value_pence,ownership_bps,valuation_date,mode,remainder,notes,version,write_token,updated_at) VALUES (?,?,'ISA','investment','stocks_isa','',10000,10000,?,'value','cash','',1,'seed',1)").bind(user+'-a',user,through).run();
   await db.prepare("INSERT INTO holdings (id,account_id,name,type,ticker,isin,amount,value_pence,position) VALUES (?,?,'Fund','etf','VTI',?,'100',10000,0)").bind(user+'-h',user+'-a',listing.isin).run();
   await db.prepare('INSERT INTO market_listings (holding_id,listing_json,selected_at) VALUES (?,?,?)').bind(user+'-h',JSON.stringify(listing),1).run();
   const snapshot={status:'ready',source:'EODHD',holdings:[{name:user==='owner'?'Owner company':'Private other company',symbol:'AAA.LSE',weightPercent:100,country:'United Kingdom',sector:'Industrials',industry:null}],holdingsAsOf:through,retrievedAt:new Date().toISOString(),stale:false};
   await db.prepare('INSERT INTO fund_constituent_snapshots (id,user_id,listing_key,symbol,data_hash,data_json,retrieved_at) VALUES (?,?,?,?,?,?,?)').bind(user+'-snapshot',user,key,listing.symbol,'hash',JSON.stringify(snapshot),Date.now()).run();
  }
  const session=randomBytes(32).toString('hex'),now=Math.floor(Date.now()/1000);
  await db.prepare('INSERT INTO sessions (token_hash,user_id,platform_user_id,created_at,expires_at) VALUES (?,?,?,?,?)').bind(createHash('sha256').update(session).digest('hex'),'owner','platform-owner',now,now+3600).run();
  const headers={cookie:'__Host-oscar_session='+session,'oai-authenticated-user-id':'platform-owner',origin:'https://example.test'};
  const call=(query='range=1M',overrides={},method='POST')=>mf.dispatchFetch('https://example.test/api/market/comparison?'+query,{method,headers:{...headers,...overrides}});
  assert.equal((await call('',{cookie:''})).status,401);assert.equal((await call('',{origin:'https://evil.test'})).status,403);assert.equal((await call('',{},'GET')).status,405);
  assert.equal((await call('range=5Y')).status,400);assert.equal((await call('country=US')).status,400);assert.equal(requests,0);
  const response=await call();assert.equal(response.status,200);const result=await response.json();
  assert.equal(result.status,'ready');assert.equal(result.knownUkPence,10000);assert.equal(result.coveragePercent,100);assert.equal(result.included[0].name,'Owner company');assert.equal(result.points[0].basket,100);assert.equal(result.points[0].benchmark,100);assert.equal(requests,2);
  assert.ok(!JSON.stringify(result).includes('Private other'));assert.ok(!JSON.stringify(result).includes('private-eodhd-test-token'));
  const next=await (await call('range=3M')).json();assert.equal(next.status,'ready');assert.equal(requests,2,'Range switching reuses the durable yearly series');
  for(const table of ['tracking_series','tracking_days','tracking_revisions'])assert.equal((await db.prepare(`SELECT COUNT(*) AS n FROM ${table}`).first()).n,0,table+' unchanged');
  assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM comparison_prices').first()).n,2);
  // A newly disclosed constituent with rate-limited prices is not charted as flat.
  await db.prepare("INSERT INTO fund_constituent_snapshots (id,user_id,listing_key,symbol,data_hash,data_json,retrieved_at) SELECT 'new-owner-snapshot',user_id,listing_key,symbol,'changed',json_set(data_json,'$.holdings[0].symbol','FAIL.LSE'),retrieved_at+1000 FROM fund_constituent_snapshots WHERE id='owner-snapshot'").run();
  const failed=await (await call()).json();assert.equal(failed.status,'unavailable');assert.deepEqual(failed.points,[]);assert.equal(failed.coveragePercent,0);assert.equal(requests,3);
  await call();assert.equal(requests,3,'Failure cooldown prevents repeated provider calls');
  assert.equal((await db.prepare("SELECT COUNT(*) AS n FROM fund_constituent_snapshots WHERE user_id='owner'").first()).n,2,'Older constituent observations survive');
 }finally{await mf.dispose();await mock.close();}
});
