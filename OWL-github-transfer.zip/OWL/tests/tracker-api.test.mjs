import test from 'node:test';
import assert from 'node:assert/strict';
import {randomBytes,createHash} from 'node:crypto';
import {readFile,readdir} from 'node:fs/promises';
import {build} from 'esbuild';
import {Miniflare,createFetchMock} from 'miniflare';
const day=n=>new Date(Date.now()+n*86400000).toISOString().slice(0,10);
const ms=n=>Date.parse(day(n)+'T12:00:00Z');

test('daily tracking uses EODHD alone, persists history, scopes access, caches across accounts and retains verified data on failure',async()=>{
 const built=await build({stdin:{contents:"import {authGate} from './server/auth.ts';export default {async fetch(r,e){return await authGate(r,e)??new Response('Page')}}",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'neutral',conditions:['workerd','worker','browser'],external:['node:crypto']});
 const mock=createFetchMock();mock.disableNetConnect();const provider=mock.get('https://eodhd.com');
 provider.intercept({path:p=>p.startsWith('/api/search/AAPL?')}).reply(200,[{Code:'AAPL',Exchange:'US',Name:'Apple',Type:'Common Stock',Currency:'USD',ISIN:'US0378331005'}]).persist();
 const prices=[{date:day(-3),close:100},{date:day(-2),close:110},{date:day(-1),close:55}];
 const fx=prices.map(p=>({date:p.date,close:.8}));
 provider.intercept({path:p=>p.startsWith('/api/eod/USDGBP.FOREX?')}).reply(200,fx).times(1);
 provider.intercept({path:p=>p.startsWith('/api/eod/AAPL.US?')}).reply(200,prices).times(1);
 provider.intercept({path:p=>p.startsWith('/api/splits/AAPL.US?')}).reply(200,[{date:day(-1),split:'2/1'}]).persist();
 const secret='test-provider-secret';
 const mf=new Miniflare({modules:true,script:built.outputFiles[0].text,compatibilityDate:'2026-05-22',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],fetchMock:mock,bindings:{APP_ORIGIN:'https://example.test',EODHD_API_TOKEN:secret}});
 try{
  const db=await mf.getD1Database('DB');
  for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const sql of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint'))if(sql.trim())await db.prepare(sql.trim()).run();
  for(const id of ['owner','other'])await db.prepare('INSERT INTO users (id,username,display_name,password_hash,created_at) VALUES (?,?,?,?,?)').bind(id,id,id,'unused',Date.now()).run();
  const session=randomBytes(32).toString('hex');const now=Math.floor(Date.now()/1000);
  await db.prepare('INSERT INTO sessions (token_hash,user_id,platform_user_id,created_at,expires_at) VALUES (?,?,?,?,?)').bind(createHash('sha256').update(session).digest('hex'),'owner','platform-owner',now,now+3600).run();
  const headers={cookie:'__Host-oscar_session='+session,'oai-authenticated-user-id':'platform-owner',origin:'https://example.test','content-type':'application/json'};
  const call=(method='GET',extra={},suffix='')=>mf.dispatchFetch('https://example.test/api/finance/tracker'+suffix,{method,headers:{...headers,...extra}});
  for(const [id,user] of [['one','owner'],['two','owner'],['private-other','other']]){
   await db.prepare("INSERT INTO accounts (id,user_id,name,category,kind,provider,value_pence,ownership_bps,valuation_date,mode,remainder,notes,version,write_token,updated_at) VALUES (?,?,'ISA','investment','stocks_isa','',100000,10000,?,'value','cash','',1,'seed',?)").bind(id,user,day(-3),ms(-3)).run();
   await db.prepare("INSERT INTO holdings (id,account_id,name,type,ticker,isin,amount,value_pence,position,details_json) VALUES (?,?,'Apple','share','AAPL','US0378331005','1000',100000,0,?)").bind(id+'-h',id,JSON.stringify({quantity:'10',priceDate:day(-3)})).run();
   await db.prepare('INSERT INTO market_listings (holding_id,listing_json,selected_at) VALUES (?,?,?)').bind(id+'-h',JSON.stringify({symbol:'AAPL.US',ticker:'AAPL',currency:'USD',name:'Apple',exchange:'US',isin:'US0378331005',type:'Common Stock'}),ms(-3)).run();
  }
  assert.equal((await call('GET',{cookie:''})).status,401);
  assert.equal((await call('POST',{origin:'https://evil.example'})).status,403);
  assert.equal((await call('GET',{'oai-authenticated-user-id':'other-platform'})).status,401);
  const initialResponse=await call();assert.equal(initialResponse.status,200,await initialResponse.clone().text());const initial=await initialResponse.json();
  assert.equal(initial.points.length,1);assert.equal(initial.points[0].provisional,true);assert.equal(initial.recordedPortfolioPence,200000);assert.equal(initial.budgetUsed,0);assert.equal(initial.holdings.length,2);
  assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM tracking_revisions WHERE user_id=?').bind('owner').first()).n,2);
  assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM tracking_revisions WHERE user_id=?').bind('other').first()).n,0);
  // Represent an account first captured three days ago, without fabricating
  // a backfill in production. Existing input dates alone never start history.
  await db.prepare('UPDATE tracking_runs SET started_at=? WHERE user_id=?').bind(ms(-3),'owner').run();
  await db.prepare('UPDATE tracking_revisions SET recorded_at=? WHERE user_id=?').bind(ms(-3),'owner').run();
  const updatedResponse=await call('POST');assert.equal(updatedResponse.status,200,await updatedResponse.clone().text());const updated=await updatedResponse.json();
  assert.equal(updated.points.length,4);assert.deepEqual(updated.points.map(p=>p.portfolioPence),[160000,176000,176000,176000]);assert.equal(updated.budgetUsed,4);
  assert.equal(updated.points[1].marketChangePence,16000);assert.equal(updated.points[2].marketChangePence,0);assert.equal(updated.points[0].date,day(-3));assert.equal(updated.through,day(0));assert.equal(updated.holdings[0].quantity,20);assert.ok(updated.holdings.every(h=>h.source==='eodhd'),'EODHD is the sole source for fresh market prices.');
  assert.equal(updated.accounts.length,2);assert.equal(updated.accounts.reduce((sum,a)=>sum+a.latestPence,0),updated.currentPortfolioPence);
  // A pre-fix corrupt derived snapshot is rebuilt from positions and verified units.
  const broken={...updated.points[0],portfolioPence:410807700};delete broken.valuationVersion;
  await db.prepare('UPDATE tracking_days SET snapshot_json=? WHERE user_id=? AND day=?').bind(JSON.stringify(broken),'owner',day(-3)).run();
  const repaired=await (await call()).json();assert.equal(repaired.points[0].portfolioPence,160000);assert.equal(repaired.points[0].valuationVersion,2);
  assert.ok(!JSON.stringify(updated).includes(secret));assert.ok(!JSON.stringify(updated).includes('private-other'));assert.ok(!('stateKey' in updated.points[0]));
  const concurrent=await Promise.all([call('POST'),call('POST')]);for(const response of concurrent)assert.equal(response.status,200,await response.clone().text());
  const cached=await (await call()).json();assert.equal(cached.budgetUsed,4);assert.ok(cached.messages.every(m=>m.includes('Latest available market close')||m.includes('fresh closing price')||m.includes('Last completed refresh')||m.includes('expected weekday')));assert.deepEqual(cached.points,updated.points);
  assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM tracking_days WHERE user_id=?').bind('owner').first()).n,4);
  // Refresh failure keeps the previous series. The provider body is private.
  provider.intercept({path:p=>p.startsWith('/api/eod/AAPL.US?')}).reply(429,'private diagnostic '+secret).persist();
  const old=await db.prepare('SELECT data_json FROM tracking_series WHERE symbol=? AND user_id=?').bind('AAPL.US','owner').first();const data=JSON.parse(old.data_json);data.through=day(-2);
  await db.prepare('UPDATE tracking_series SET data_json=?,attempted_day=? WHERE symbol=? AND user_id=?').bind(JSON.stringify(data),day(-1),'AAPL.US','owner').run();
  const failed=await (await call('POST')).json();assert.equal(failed.points.at(-1).portfolioPence,176000);assert.equal(failed.budgetUsed,6);assert.ok(failed.messages.length);assert.ok(!JSON.stringify(failed).includes(secret));
  assert.equal((await (await call('POST')).json()).budgetUsed,6);
  // Removing an account today retains earlier daily ownership and quantities.
  const deleted=await mf.dispatchFetch('https://example.test/api/finance/accounts',{method:'DELETE',headers,body:JSON.stringify({id:'two',version:1})});assert.equal(deleted.status,200,await deleted.clone().text());
  const after=await (await call('GET')).json();assert.deepEqual(after.points.slice(0,-1),failed.points.slice(0,-1));assert.equal(after.points.at(-1).portfolioPence,88000);assert.equal(after.points.at(-1).accountChanges,true);assert.equal(after.points.at(-1).marketChangePence,null);assert.equal(after.holdings.length,1);assert.equal(after.recordedPortfolioPence,100000);
  const deletion=await db.prepare('SELECT state_json FROM tracking_revisions WHERE account_id=? ORDER BY seq DESC LIMIT 1').bind('two').first();assert.equal(deletion.state_json,null);
  const attempted=await mf.dispatchFetch('https://example.test/api/finance/accounts',{method:'DELETE',headers,body:JSON.stringify({id:'private-other',version:1})});assert.equal(attempted.status,409);
  assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM tracking_revisions WHERE user_id=?').bind('other').first()).n,0);
  assert.equal((await (await call('GET',{},'?userId=other')).json()).holdings.length,1);
  await db.prepare('UPDATE tracking_runs SET budget_date=?,budget_used=200 WHERE user_id=?').bind(day(0),'owner').run();
  await db.prepare('UPDATE tracking_series SET attempted_day=? WHERE user_id=?').bind(day(-1),'owner').run();
  const capped=await (await call('POST')).json();assert.equal(capped.budgetUsed,200);assert.ok(capped.messages.some(m=>m.includes('request guard')));
  assert.equal(capped.points.at(-1).portfolioPence,88000);
  assert.equal((await call('PUT')).status,405);
 }finally{await mf.dispose();await mock.close();}
});
