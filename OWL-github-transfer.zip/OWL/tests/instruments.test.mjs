import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';

const bundle=await build({entryPoints:['server/instruments.ts'],bundle:true,write:false,format:'esm',platform:'node'});
const {normalizeEodInstruments,instrumentSearchApi}=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));

test('EODHD search keeps exact identifiers and supports unseen exchanges',()=>{
 const rows=[
  {Code:'NEW',Exchange:'ST',Name:'New Nordic Company',Type:'Common Stock',Currency:'SEK',ISIN:'SE0000000001'},
  {Code:'NEW',Exchange:'US',Name:'Another Company',Type:'Common Stock',Currency:'USD',ISIN:'US0000000001'},
  {Code:'FUND',Exchange:'LSE',Name:'Example Trust',Type:'Closed-end Fund',Currency:'GBp',ISIN:'GB0000000001'},
  {Code:'NEW',Exchange:'ST',Name:'New Warrant',Type:'Warrant',Currency:'SEK',ISIN:'SE0000000001'},
 ];
 const exact=normalizeEodInstruments(rows,'NEW');
 assert.deepEqual(exact.map(r=>r.id),['NEW.ST','NEW.US']);
 assert.ok(exact.every(r=>r.source==='eodhd'));
 assert.deepEqual(normalizeEodInstruments(rows,'SE0000000001').map(r=>r.exchange),['ST']);
 assert.equal(normalizeEodInstruments(rows,'GB0000000001','LN')[0].type,'investment_trust');
});

test('instrument search requires a connected EODHD key and uses its results',async()=>{
 const invalid=await instrumentSearchApi(new Request('https://site.test/api/instruments/search?q=Apple%20Inc'),{},'user');
 assert.equal(invalid.status,400);
 const missing=await instrumentSearchApi(new Request('https://site.test/api/instruments/search?q=AAPL'),{DB:{prepare:()=>({bind:()=>({first:async()=>null})})}},'user');
 assert.equal(missing.status,409);
 const original=globalThis.fetch;
 globalThis.fetch=async()=>Response.json([{Code:'AAPL',Exchange:'US',Name:'Apple Inc',Type:'Common Stock',Currency:'USD',ISIN:'US0378331005'}]);
 try{
  const response=await instrumentSearchApi(new Request('https://site.test/api/instruments/search?q=AAPL'),{EODHD_API_TOKEN:'test-token'},'user');
  assert.equal(response.status,200);
  const body=await response.json();assert.deepEqual(body.results.map(r=>r.id),['AAPL.US']);
 }finally{globalThis.fetch=original;}
});

test('ticker search falls back to exact ETF fundamentals when EODHD search misses it',async()=>{
 const original=globalThis.fetch;
 globalThis.fetch=async url=>Response.json(String(url).includes('/search/')?[]:{General:{Code:'VWRL',Exchange:'LSE',Name:'Vanguard FTSE All-World UCITS ETF',Type:'ETF'},ETF_Data:{ISIN:'IE00B3RBWM25'}});
 try{
  const response=await instrumentSearchApi(new Request('https://site.test/api/instruments/search?q=VWRL&exchange=LN'),{EODHD_API_TOKEN:'test-token'},'user');
  assert.equal(response.status,200);
  const body=await response.json();assert.deepEqual(body.results.map(r=>[r.id,r.isin,r.type]),[['VWRL.LSE','IE00B3RBWM25','etf']]);
 }finally{globalThis.fetch=original;}
});
