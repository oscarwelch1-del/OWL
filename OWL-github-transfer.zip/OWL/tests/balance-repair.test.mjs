import test from 'node:test';import assert from 'node:assert/strict';
import {build} from 'esbuild';import {readFile,readdir} from 'node:fs/promises';import {Miniflare} from 'miniflare';
test('reported Tesla repair is scoped, idempotent, version guarded and preserves the original revision',async()=>{
 const b=await build({stdin:{contents:"import {repairReportedDeletion} from './server/balance-repair';export default {async fetch(r,e){await repairReportedDeletion(e,new URL(r.url).searchParams.get('user'));return new Response('ok')}}",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'neutral'});
 const mf=new Miniflare({modules:true,script:b.outputFiles[0].text,compatibilityDate:'2026-05-22',d1Databases:['DB']});
 try{
 const db=await mf.getD1Database('DB');
 for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const sql of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint'))if(sql.trim())await db.prepare(sql.trim()).run();
 const id='3ab41062-7fe8-49a4-9201-a21fa82498aa',at=1789510707676;
 await db.prepare("INSERT INTO users VALUES ('owner','owner','Owner','unused',0)").run();
 await db.prepare("INSERT INTO accounts(id,user_id,name,category,kind,provider,value_pence,ownership_bps,valuation_date,mode,remainder,notes,version,write_token,updated_at) VALUES (?,'owner','ISA','investment','stocks_isa','',7391033,10000,'2026-09-10','value','unassigned','',6,'old',?)").bind(id,at).run();
 for(let i=0;i<12;i++)await db.prepare("INSERT INTO holdings(id,account_id,name,type,ticker,isin,amount,value_pence,position) VALUES (?,?,'Existing','share','','','0',?,?)").bind('h'+i,id,i===0?6391033:0,i).run();
 await db.prepare("INSERT INTO tracking_revisions(user_id,account_id,recorded_at,state_json) VALUES ('owner',?,?,?)").bind(id,at,JSON.stringify({id,valuePence:7391033,holdings:[]})).run();
 const repair=user=>mf.dispatchFetch('https://test/?user='+user);
 await repair('other');assert.equal((await db.prepare('SELECT value_pence FROM accounts').first()).value_pence,7391033);
 await db.prepare('UPDATE accounts SET version=7').run();await repair('owner');assert.equal((await db.prepare('SELECT value_pence FROM accounts').first()).value_pence,7391033);
 await db.prepare('UPDATE accounts SET version=6').run();await repair('owner');await repair('owner');
 const a=await db.prepare('SELECT * FROM accounts').first();assert.equal(a.value_pence,6391033);assert.equal(a.version,7);
 const revisions=(await db.prepare('SELECT * FROM tracking_revisions ORDER BY seq').all()).results;
 assert.equal(revisions.length,2);assert.equal(JSON.parse(revisions[0].state_json).valuePence,7391033);assert.equal(JSON.parse(revisions[1].state_json).valuePence,6391033);assert.equal(revisions[1].recorded_at,at);
 }finally{await mf.dispose();}
});
