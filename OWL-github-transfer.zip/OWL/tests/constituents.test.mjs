import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {build} from 'esbuild';
const b=await build({entryPoints:['server/constituents.ts'],bundle:true,write:false,format:'esm',platform:'node'});
const m=await import('data:text/javascript;base64,'+Buffer.from(b.outputFiles[0].text).toString('base64'));
const fixture=JSON.parse(await readFile('tests/fixtures/eodhd-vti-2026-09-12.json','utf8'));
const listing={symbol:'VTI.US',ticker:'VTI',exchange:'US',currency:'USD',isin:fixture.ETF_Data.ISIN,name:fixture.General.Name,type:'ETF'};
const normalize=(raw=fixture,l=listing)=>m.normalizeConstituents(raw,l,'etf',Date.parse('2026-09-12T23:00:00Z'));

test('real EODHD VTI response returns the ten reported weights without scaling or invented dates',()=>{
 const r=normalize();assert.equal(r.status,'ready');assert.equal(r.holdings.length,10);assert.equal(r.holdings[0].symbol,'NVDA.US');assert.equal(r.holdings[0].weightPercent,6.32);assert.equal(r.coveragePercent,31.87);assert.equal(r.otherPercent,68.13);assert.equal(r.holdingsAsOf,null);assert.equal(r.providerUpdatedAt,'2026-09-12');assert.equal(r.holdings[0].country,'United States');assert.equal(r.holdings[0].sector,'Technology');
 assert.equal(r.holdings.filter(h=>h.name.includes('Alphabet')).length,2,'Distinct share classes remain distinct holdings.');
 for(const h of r.holdings)assert.equal(h.weightPercent,fixture.ETF_Data.Top_10_Holdings[h.symbol]['Assets_%']);
});

test('a supplied full Holdings object is retained for later top-X views while the default remains ten',()=>{
 const raw=structuredClone(fixture);const top=raw.ETF_Data.Top_10_Holdings;
 raw.ETF_Data.Holdings={...top};
 for(let i=0;i<15;i++)raw.ETF_Data.Holdings['TEST'+i+'.US']={Code:'TEST'+i,Exchange:'US',Name:'Test '+i,'Assets_%':0.1,Sector:'Technology',Country:'United States',Region:'North America'};
 raw.ETF_Data.Holdings_Count=25;
 const r=normalize(raw);assert.equal(r.status,'ready');assert.equal(r.holdings.length,10);assert.equal(r.allHoldings.length,25);assert.equal(r.reportedCount,25);assert.equal(r.holdings[0].symbol,'NVDA.US');assert.ok(r.warnings.some(w=>w.includes('25 holdings')));
});

test('missing, invalid and contradictory weights or identities never become a top-ten list',()=>{
 for(const weight of [null,'',true,'NaN',-5,101,Infinity]){const raw=structuredClone(fixture);raw.ETF_Data.Top_10_Holdings['NVDA.US']['Assets_%']=weight;assert.equal(normalize(raw).status,'unavailable');}
 for(const change of [{Code:'OTHER'}]){const raw=structuredClone(fixture);Object.assign(raw.General,change);assert.equal(normalize(raw).status,'unavailable');}
 assert.equal(normalize(fixture,{...listing,isin:'WRONG'}).status,'unavailable');
 const conflict=structuredClone(fixture);conflict.ETF_Data.Top_10_Holdings['NVDA.US'].Code='AAPL';assert.equal(normalize(conflict).status,'unavailable');
 const overweight=structuredClone(fixture);for(const h of Object.values(overweight.ETF_Data.Top_10_Holdings))h['Assets_%']=20;assert.equal(normalize(overweight).status,'unavailable');
});

test('a partial list retains its original weights and unprovided classifications stay null',()=>{
 const raw=structuredClone(fixture);const nvda=raw.ETF_Data.Top_10_Holdings['NVDA.US'];delete nvda.Sector;delete nvda.Country;delete nvda.Exchange;
 raw.ETF_Data.Top_10_Holdings={'NVDA.US':nvda};const r=normalize(raw);assert.equal(r.holdings.length,1);assert.equal(r.coveragePercent,6.32);assert.equal(r.holdings[0].sector,null);assert.equal(r.holdings[0].country,null);assert.equal(r.holdings[0].symbol,'NVDA.US');assert.ok(r.warnings.some(w=>w.includes('1 holdings')));
});

test('investment-trust shareholders are never mistaken for portfolio constituents',()=>{
 const l={...listing,symbol:'SMT.LSE',ticker:'SMT',currency:'GBX',isin:'',type:'Common Stock'};
 const raw={General:{Code:'SMT',CurrencyCode:'GBX',Type:'Common Stock'},Holders:{Institutions:{0:{name:'Asset manager',totalAssets:20}}}};
 const trust=m.normalizeConstituents(raw,l,'investment_trust');assert.equal(trust.status,'unavailable');assert.equal(trust.holdings.length,0);assert.ok(trust.warnings.some(w=>w.includes('investment trust')));
 assert.equal(m.normalizeConstituents(raw,l,'share').status,'not_applicable');
});

test('unseen mutual fund top holdings can arrive as an array',()=>{
 const l={...listing,symbol:'NEW.US',ticker:'NEW',isin:'',type:'Fund'};
 const raw={General:{Code:'NEW',CurrencyCode:'USD',Type:'Fund'},MutualFund_Data:{Top_Holdings:[{Name:'First Company',Weight:'12.5%',Sector:'Industrials',Country:'Sweden'}]}};
 const value=m.normalizeConstituents(raw,l,'fund');
 assert.equal(value.status,'ready');assert.equal(value.holdings[0].weightPercent,12.5);assert.equal(value.holdings[0].symbol,null);assert.equal(value.holdings[0].country,'Sweden');
});

test('constituent enrichment accepts the unwrapped General section EODHD actually returns',async()=>{
 const original=globalThis.fetch;
 globalThis.fetch=async()=>Response.json({Code:'NEW',ISIN:'',Sector:'Industrials',Industry:'Machinery',CountryName:'Sweden'});
 try{
  const input={...normalize(),allHoldings:undefined,holdings:[{symbol:'NEW.ST',name:'New company',weightPercent:5,sector:null,industry:null,country:null,region:null}]};
  const result=await m.enrichConstituents(input,'test-unwrapped-general');
  assert.equal(result.holdings[0].industry,'Machinery');assert.equal(result.holdings[0].country,'Sweden');assert.equal(result.holdings[0].sector,'Industrials');
 }finally{globalThis.fetch=original;}
});


test('fund composition uses matching ISIN independently of trading currency, and retains array holdings',()=>{
 const raw=structuredClone(fixture);raw.General.CurrencyCode='EUR';raw.ETF_Data.Holdings=Object.values(raw.ETF_Data.Top_10_Holdings);
 const result=normalize(raw);assert.equal(result.status,'ready');assert.equal(result.holdings.length,10);
 assert.equal(normalize(raw,{...listing,isin:'WRONG'}).status,'unavailable');
});
test('a broken full list can use an independently verified top list without inventing full coverage',()=>{
 const raw=structuredClone(fixture);raw.ETF_Data.Holdings={BROKEN:{Name:'Broken','Assets_%':null}};
 const result=normalize(raw);assert.equal(result.status,'ready');assert.equal(result.coveragePercent,31.87);assert.equal(result.allHoldings,undefined);assert.ok(result.warnings.some(w=>w.includes('complete holdings list failed')));
});
