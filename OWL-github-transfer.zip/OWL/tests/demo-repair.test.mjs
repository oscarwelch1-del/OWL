import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {build} from 'esbuild';
import {Miniflare} from 'miniflare';
test('demo repair preserves allocations, replaces invented quantities once and resets only its history',async()=>{
 const built=await build({stdin:{contents:"import {repairDemoPositions} from './server/demo-repair';export default {async fetch(r,e){await repairDemoPositions(e,new URL(r.url).searchParams.get('user')||'owner');return new Response('ok')}}",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'neutral'});
 const mf=new Miniflare({modules:true,script:built.outputFiles[0].text,compatibilityDate:'2026-05-22',d1Databases:['DB']});
 try{
 const db=await mf.getD1Database('DB');
 for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const sql of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint'))if(sql.trim())await db.prepare(sql.trim()).run();
 for(const user of ['owner','other'])await db.prepare('INSERT INTO users (id,username,display_name,password_hash,created_at) VALUES (?,?,?,?,0)').bind(user,user,user,'unused').run();
 const id='ad4f9568-ba45-4203-8f91-e41c0bfe3183';
 await db.prepare("INSERT INTO accounts (id,user_id,name,category,kind,provider,value_pence,ownership_bps,valuation_date,mode,remainder,notes,version,write_token,updated_at) VALUES (?,'owner','DEMO','investment','portfolio','',10000000,10000,'2026-09-23','value','cash','',1,'seed',0)").bind(id).run();
 const inputs=[['VWRL',24000,141.09,'GBP'],['SWDA',20000,11094,'GBX'],['IITU',16000,4033,'GBX'],['VFEM',14000,62.43,'GBP'],['IEUX',11000,4715.5,'GBX'],['CSUK',9000,20272.5,'GBX'],['INRG',6000,762.25,'GBX']];
 for(const [ticker,value,price,currency] of inputs){
 await db.prepare("INSERT INTO holdings (id,account_id,name,type,ticker,isin,amount,value_pence,position,details_json) VALUES (?,? ,?,'etf',?,'',?,?,0,?)").bind(ticker,id,ticker,ticker,String(value),value*100,JSON.stringify({quantity:'100',unitPrice:String(value/100),priceCurrency:'GBP',priceDate:'2026-09-23'})).run();
 await db.prepare("INSERT INTO tracking_series (id,user_id,symbol,data_json,attempted_day) VALUES (?,'owner',?,?,'')").bind(ticker,ticker+'.LSE',JSON.stringify({prices:[{date:'2026-09-23',close:price}],source:'eodhd',splitAdjusted:false,quoteCurrency:currency})).run();
 }
 for(const user of ['owner','other']){
 await db.prepare('INSERT INTO tracking_runs (user_id,started_at,budget_used) VALUES (?,0,50)').bind(user).run();
 await db.prepare("INSERT INTO tracking_days VALUES (?,?, '2026-09-23','{}',0)").bind(user,user).run();
 await db.prepare("INSERT INTO tracking_revisions (user_id,account_id,recorded_at,state_json) VALUES (?,?,0,'{}')").bind(user,id).run();
 }
 await mf.dispatchFetch('https://test/?user=other');assert.equal((await db.prepare('SELECT version FROM accounts WHERE id=?').bind(id).first()).version,1);
 await mf.dispatchFetch('https://test/');
 const rows=(await db.prepare('SELECT ticker,value_pence,details_json FROM holdings').all()).results;
 assert.equal(rows.reduce((n,r)=>n+r.value_pence,0),10000000);
 for(const row of rows){const d=JSON.parse(row.details_json);assert.equal(Math.round(Number(d.quantity)*Number(d.unitPrice)*100),row.value_pence);assert.notEqual(d.quantity,'100');}
 const inrg=JSON.parse(rows.find(r=>r.ticker==='INRG').details_json);assert.equal(Math.round(Number(inrg.quantity)*7.445*100),586028);
 assert.equal((await db.prepare("SELECT COUNT(*) AS n FROM tracking_days WHERE user_id='owner'").first()).n,0);
 assert.equal((await db.prepare("SELECT COUNT(*) AS n FROM tracking_days WHERE user_id='other'").first()).n,1);
 assert.equal((await db.prepare("SELECT budget_used FROM tracking_runs WHERE user_id='owner'").first()).budget_used,50);
 await db.prepare("INSERT INTO tracking_days VALUES ('new','owner','2026-09-26','{}',0)").run();
 await mf.dispatchFetch('https://test/');assert.equal((await db.prepare("SELECT COUNT(*) AS n FROM tracking_days WHERE user_id='owner'").first()).n,1);
 assert.equal((await db.prepare('SELECT version FROM accounts WHERE id=?').bind(id).first()).version,2);
 }finally{await mf.dispose();}
});
