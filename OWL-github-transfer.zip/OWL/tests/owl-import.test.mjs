import test from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
const bundle=await build({stdin:{contents:"export * from './lib/finance/model.ts'; export * from './lib/finance/aj-bell.ts'; export * from './lib/finance/bonds.ts'; export {normalizeEodInstruments} from './server/instruments.ts';",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'node'});
const m=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const header='Investment,Quantity,Price,Value (£),Cost (£),Change (£),Change (%),Price +/- today (%),Valuation currency,Market currency,Exchange rate,Date,Time,Portfolio,Ticker';
const sample=header+'\r\n"Example Trust Ord (LSE:EXT)","1,100",2.635,"2,898.50",,,,,GBP,GBP,1,10-Sep-24,12:00,ISA,EXT\r\nExample Acc (FUND:ABC1234),16.7198,342.7586,"5,730.86",,,,,GBP,GBP,1,10-Sep-24,12:00,ISA,ABC1234\r\nCash GBP,12.34,1,12.34,,,,,GBP,GBP,1,10-Sep-24,12:00,ISA';
const account=()=>({...m.newAccount(),name:'Test ISA',value:'9000',mode:'value'});
const review=p=>p.rows.map(row=>({row,include:true,confirmed:true,type:row.type==='other'?'investment_trust':row.type}));

test('AJ Bell layout: quoted thousands, fractional units, cash, fund codes and absent ISINs',()=>{
 const p=m.parseAjBell('\uFEFF'+sample);
 assert.equal(p.rows.length,3);assert.equal(p.totalPence,864170);assert.equal(p.valuationDate,'2024-09-10');
 assert.equal(p.rows[0].quantity,'1100');assert.equal(p.rows[0].unitPrice,'2.635');assert.equal(p.rows[0].exchange,'LN');
 assert.equal(p.rows[0].isin,'');assert.equal(p.rows[0].errors.length,0);
 assert.equal(p.rows[1].ticker,'');assert.equal(p.rows[1].instrumentCode,'ABC1234');assert.equal(p.rows[1].type,'fund');
 assert.equal(p.rows[2].type,'cash');assert.deepEqual(p.rows.map(r=>r.errors),[[],[],[]]);
 assert.equal(m.validateAccount(m.mergeImport(account(),review(p))).holdings.length,3);
});
test('unsafe CSV data and ambiguous duplicates stay visible and cannot silently import',()=>{
 assert.throws(()=>m.parseAjBell('Account,Cash,Investments,Total\nISA,1,2,3'),/overview/);
 assert.throws(()=>m.readCsv('a,b\n"unfinished'),/quoted/);
 assert.throws(()=>m.readCsv('a,b\n"a"oops,2'),/Unexpected/);
 assert.deepEqual(m.readCsv('a,b\n"line\nwith ""quotes""",2'),[['a','b'],['line\nwith "quotes"','2']]);
 const negative=m.parseAjBell(sample.replace('"2,898.50"','-200'));assert.ok(negative.rows[0].errors.length);
 assert.throws(()=>m.mergeImport(account(),review(negative)),/Review row/);
 const foreign=m.parseAjBell(sample.replace('GBP,GBP','USD,USD'));assert.match(foreign.rows[0].errors.join(' '),/GBP/);
 const duplicate=m.parseAjBell(sample+'\nCash GBP,12.34,1,12.34,,,,,GBP,GBP,1,10-Sep-24,12:00,ISA');
 assert.equal(duplicate.rows.filter(r=>r.duplicate).length,2);assert.equal(duplicate.totalPence,null);
 assert.throws(()=>m.mergeImport(account(),review(duplicate)),/duplicate/);
 const unconfirmed=review(m.parseAjBell(sample));unconfirmed[0].confirmed=false;
 assert.throws(()=>m.mergeImport(account(),unconfirmed),/Review row/);
 const badNumber=m.parseAjBell(sample.replace('"1,100"','"1,10"'));assert.match(badNumber.rows[0].errors.join(' '),/quantity/);
});
test('imports update a selected holding, retain unrelated data and never change account total',()=>{
 const p=m.parseAjBell(sample);const a=account();a.remainder='cash';
 const original=m.mergeImport(a,review(p));assert.equal(original.value,'9000');assert.equal(original.remainder,'unassigned');
 assert.equal(a.holdings.length,0);
 original.holdings[0].details.dividendYield='4';original.holdings[0].instrumentId='verified-figi';
 const r=review(p).map(r=>({...r,targetId:original.holdings.find(h=>m.sameInstrument(r.row,h))?.id}));
 const updated=m.mergeImport(original,r);
 assert.equal(updated.holdings.length,3);assert.equal(updated.holdings[0].id,original.holdings[0].id);
 assert.equal(updated.holdings[0].details.dividendYield,'4');assert.equal(updated.holdings[0].instrumentId,'verified-figi');
 assert.equal(updated.value,original.value);assert.equal(updated.valuationDate,original.valuationDate);
 assert.throws(()=>m.mergeImport(original,review(p)),/existing holding/);
 const wrongExchange={...p.rows[0],exchange:'US'};assert.equal(m.sameInstrument(wrongExchange,original.holdings[0]),false);
 const noExchange={...p.rows[0],exchange:''};assert.equal(m.sameInstrument(noExchange,original.holdings[0]),false);
 const identityConflict={...p.rows[0],isin:'US0378331005'};assert.equal(m.sameInstrument(identityConflict,{...original.holdings[0],isin:'GB00B03MLX29'}),false);
 const one=review(p);one[1].include=false;one[2].include=false;one[0].targetId=original.holdings[0].id;
 assert.equal(m.mergeImport(original,one).holdings.length,3);
});
test('percentage holdings retain their exact penny allocation when an import changes to value mode',()=>{
 const a={...account(),value:'1.01',mode:'percent',holdings:[{...m.newHolding(),name:'First',amount:'50'},{...m.newHolding(),name:'Second',amount:'50'}]};
 const expected=m.allocate(a).values;const row={...m.parseAjBell(sample).rows[2],valuePence:0,quantity:'0'};
 const result=m.mergeImport(a,[{row,include:true,confirmed:true,type:'cash'}]);
 assert.deepEqual(result.holdings.slice(0,2).map(h=>m.units(h.amount)),expected);assert.equal(result.value,'1.01');
});
test('fixed-rate bond schedule handles semiannual coupons, month ends, missing terms and zero coupons',()=>{
 const d={...m.blankHoldingDetails(),nominalValue:'1000',couponRate:'5',couponFrequency:'semiannually',maturityDate:'2028-09-10',redemptionValue:'1000'};
 const p=m.projectBond(d,'2026-09-10');assert.equal(p.annualPence,5000);assert.equal(p.couponPence,2500);assert.equal(p.couponsRemaining,4);assert.equal(p.totalCouponPence,10000);assert.equal(p.nextCoupon,'2027-03-10');
 assert.equal(m.projectBond({...d,maturityDate:'2027-08-31'},'2027-02-27').nextCoupon,'2027-02-28');
 assert.equal(m.projectBond({...d,couponRate:''}),null);assert.equal(m.projectBond({...d,redemptionValue:''}),null);
 assert.equal(m.projectBond({...d,couponFrequency:'irregular'}),null);
 const zero=m.projectBond({...d,couponRate:'0',couponFrequency:'none'},'2026-09-10');assert.equal(zero.totalCouponPence,0);assert.equal(zero.redemptionPence,100000);
 const matured=m.projectBond(d,'2028-09-10');assert.equal(matured.couponsRemaining,0);assert.equal(matured.matured,true);
});
test('income is after tax per period; pensions retain their fields and stay separate in totals',()=>{
 const income={...m.newAccount('income'),name:'Employment',details:{...m.blankAccountDetails(),netAmount:'2400',incomeFrequency:'monthly'}};
 assert.equal(m.validateAccount(income).value,'2400');
 assert.throws(()=>m.validateAccount({...income,details:{...income.details,netAmount:''}}),/after tax/);
 const legacy=m.incomeDetails({...m.blankAccountDetails(),netAnnual:'30000',incomeFrequency:'monthly'});assert.equal(legacy.netAmount,'30000');assert.equal(legacy.incomeFrequency,'annually');
 assert.equal(m.incomeDetails({...m.blankAccountDetails(),grossAnnual:'60000'}).netAmount,'');
 const pension={...m.newAccount('pension'),kind:'defined_benefit',name:'Pension',value:'12000'};
 const records=[{...m.validateAccount(income),valuePence:240000,ownershipBps:10000},{...m.validateAccount(pension),valuePence:1200000,ownershipBps:10000}];
 assert.equal(m.summary(records).assets,0);assert.equal(m.summary(records).pensionIncome,1200000);
 assert.equal(m.validateAccount({...m.newAccount('other'),kind:'legacy_collectible',name:'Other',value:'10'}).kind,'custom');
});
test('EODHD instrument matching filters the requested exchange and excludes options',()=>{
 const rows=[{Code:'EXT',Exchange:'US',Name:'Example',Type:'Common Stock',Currency:'USD'},
  {Code:'EXT',Exchange:'LSE',Name:'Example',Type:'Common Stock',Currency:'GBp'},
  {Code:'OPT',Exchange:'LSE',Name:'Example option',Type:'Option',Currency:'GBp'},
  {Code:'TRUST',Exchange:'LSE',Name:'Example Trust',Type:'Closed-end Fund',Currency:'GBp'}];
 const results=m.normalizeEodInstruments(rows,'EXT','LN');
 assert.equal(results.length,1);assert.equal(results[0].id,'EXT.LSE');
 assert.equal(m.normalizeEodInstruments(rows,'TRUST','LN')[0].type,'investment_trust');
});

test('name-only import detects ISA/LISA and builds a complete portfolio without classification prompts',()=>{
 const p=m.parseAjBell(sample);const empty={...m.newAccount(),name:'',kind:'portfolio',value:'0',mode:'value'};
 const rows=m.automaticRows(p,empty,[]);
 assert.ok(rows.every(r=>r.confirmed));assert.equal(rows[0].type,'other');assert.equal(rows[1].type,'fund');
 const imported=m.validateAccount(m.finishAutomaticImport(empty,p,rows,' My portfolio ',true));
 assert.equal(imported.name,'My portfolio');assert.equal(imported.kind,'stocks_isa');assert.equal(imported.value,'8641.70');
 assert.equal(imported.valuationDate,'2024-09-10');assert.equal(imported.holdings.length,3);assert.equal(m.allocate(imported).remaining,0);
 const lisa=m.parseAjBell(sample.replaceAll(',ISA,',',Lifetime ISA,').replace(/,ISA$/,',Lifetime ISA'));
 assert.equal(m.finishAutomaticImport(empty,lisa,m.automaticRows(lisa,empty,[]),'LISA',true).kind,'stocks_lisa');
 assert.equal(m.portfolioKind('Unexpected wrapper'),'portfolio');assert.equal(m.portfolioKind(''),'portfolio');
 assert.throws(()=>m.finishAutomaticImport(empty,p,rows,'',true),/name/);
 const duplicate=m.parseAjBell(sample+'\nCash GBP,12.34,1,12.34,,,,,GBP,GBP,1,10-Sep-24,12:00,ISA');
 assert.throws(()=>m.finishAutomaticImport(empty,duplicate,m.automaticRows(duplicate,empty,[]),'Name',true),/duplicate/);
});

test('automatic lookup accepts a unique exact exchange match and leaves uncertain types unavailable',()=>{
 const p=m.parseAjBell(sample);const a=account();const row=m.automaticRows(p,a,[])[0];
 const exact={id:'EXT.LSE',name:'EXAMPLE TRUST',ticker:'EXT',exchange:'LN',isin:'',type:'investment_trust',assetClass:'stock',source:'eodhd'};
 assert.equal(m.automaticMatch(row,[exact]).type,'investment_trust');
 assert.equal(m.automaticMatch(row,[exact,{...exact,id:'EXT2.LSE'}]).type,'other');
 assert.equal(m.automaticMatch(row,[{...exact,exchange:'US'}]).type,'other');
 assert.equal(m.automaticMatch(row,[{...exact,ticker:'OTHER'}]).type,'other');
 assert.equal(m.automaticMatch(row,[]).confirmed,true);
 const first=m.finishAutomaticImport(a,p,m.automaticRows(p,a,[]),'Initial',true);
 const updates=m.automaticRows(p,first,first.holdings);
 assert.ok(updates.every(r=>r.targetId));
 const repeated=m.finishAutomaticImport({...first,value:'10000'},p,updates,'Renamed');
 assert.equal(repeated.value,'10000');assert.equal(repeated.holdings.length,3);
 assert.equal(m.automaticMatch(updates[0],[exact]).type,'investment_trust');
});

test('SIPP import creates a pension, retains holdings and supports subsequent statement updates',()=>{
 const p=m.parseAjBell(sample.replaceAll(',ISA',',SIPP'));
 const empty={...m.newAccount(),kind:'portfolio',value:'0',mode:'value'};
 const imported=m.validateAccount(m.finishAutomaticImport(empty,p,m.automaticRows(p,empty,[]),'Demo SIPP',true));
 assert.equal(imported.category,'pension');assert.equal(imported.kind,'sipp');
 assert.equal(imported.value,'8641.70');assert.equal(imported.holdings.length,3);
 assert.equal(m.allocate(imported).remaining,0);
 const updated=m.finishAutomaticImport(imported,p,m.automaticRows(p,imported,imported.holdings),'Demo SIPP',false,true);
 assert.equal(updated.category,'pension');assert.equal(updated.holdings.length,3);
 assert.equal(m.portfolioKind('Self-invested personal pension'),'sipp');
 assert.throws(()=>m.mergeImport({...imported,kind:'defined_benefit'},m.automaticRows(p,imported,[])),/investment holdings/);
});
