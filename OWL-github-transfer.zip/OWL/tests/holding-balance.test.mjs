import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
const built=await build({stdin:{contents:"export * from './lib/finance/model';export * from './lib/finance/holding-balance';",resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'node'});
const m=await import('data:text/javascript;base64,'+Buffer.from(built.outputFiles[0].text).toString('base64'));
const holding=(amount,name='Tesla')=>({...m.newHolding(),name,type:'share',amount});
test('add, edit and remove £10,000 symmetrically, preserving explicit cash and residual exactly',()=>{
 const stock=holding('80000','Existing stock'),cash={...holding('2000','Cash'),type:'cash'};
 const base={...m.newAccount(),name:'ISA',mode:'value',value:'85000',holdings:[stock,cash]};
 const tesla=holding('10000');
 const added=m.editHoldingBalance(base,[...base.holdings,tesla]);
 assert.equal(added.value,'95000.00');assert.equal(m.allocate(added).remaining,300000);
 const edited=m.editHoldingBalance(added,[stock,cash,{...tesla,amount:'5000'}]);assert.equal(edited.value,'90000.00');
 const removed=m.removeHolding(edited,tesla.id);assert.equal(removed.value,'85000.00');assert.deepEqual(removed.holdings,base.holdings);
 assert.equal(m.editHoldingBalance(removed,removed.holdings).value,'85000.00');
 assert.equal(m.editHoldingBalance(added,[stock,cash,{...tesla,amount:''}]).value,'85000.00');
 assert.equal(m.editHoldingBalance(base,[stock,cash,{...tesla,amount:'10000.'}]).value,'95000.00');
 assert.throws(()=>m.editHoldingBalance(base,[stock,cash,{...tesla,amount:'garbage'}]));
});
test('deletion from percentage mode freezes surviving penny values instead of revaluing them',()=>{
 const first=holding('33.33'),second=holding('66.67');
 const a={...m.newAccount(),value:'100.01',holdings:[first,second]};
 const old=m.allocate(a),next=m.removeHolding(a,first.id),now=m.allocate(next);
 assert.equal(next.mode,'value');assert.equal(now.values[0],old.values[1]);assert.equal(now.remaining,0);
});
test('value-only holdings never acquire fictional units during balance edits',()=>{
 const h=holding('10000');const a=m.editHoldingBalance({...m.newAccount(),mode:'value',value:'0'},[h]);
 assert.equal(a.value,'10000.00');assert.equal(a.holdings[0].details.quantity,'');
 assert.equal(m.removeHolding(a,h.id).value,'0.00');
});
