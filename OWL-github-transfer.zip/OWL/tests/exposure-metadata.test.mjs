import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';

const bundle=await build({entryPoints:['server/exposure-metadata.ts'],bundle:true,write:false,format:'esm',platform:'node'});
const {normalizeClassification,exposureKind}=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const listing={symbol:'NEW.ST',ticker:'NEW',exchange:'ST',currency:'SEK',isin:'SE0000000001',name:'New Nordic Company',type:'Common Stock'};

test('unseen listing uses EODHD registration, sector and industry, with identity checks',()=>{
 const payload={General:{Code:'NEW',Type:'Common Stock',CurrencyCode:'SEK',ISIN:listing.isin,Sector:'Industrials',Industry:'Industrial Machinery',CountryName:'Sweden',UpdatedAt:'2026-08-31'}};
 const result=normalizeClassification(payload,listing,Date.parse('2026-09-01T12:00:00Z'));
 assert.deepEqual(normalizeClassification(payload.General,listing,Date.parse('2026-09-01T12:00:00Z')),result,'Single-section EODHD filters return the section directly');
 assert.deepEqual([result.sector,result.industry,result.country,result.asOf],['Industrials','Industrial Machinery','Sweden','2026-08-31']);
 assert.equal(normalizeClassification({General:{...payload.General,Code:'DIFFERENT'}},listing),null);
 assert.equal(normalizeClassification({General:{...payload.General,ISIN:'SE9999999999'}},listing),null);
 assert.equal(normalizeClassification({General:{...payload.General,Type:'ETF'}},listing),null);
 assert.equal(normalizeClassification({General:{...payload.General,CountryName:null,Sector:null,Industry:null}},listing),null);
});

test('imported investment trusts refresh fund holdings despite trading as stock',()=>{
 assert.equal(exposureKind('investment_trust','stock'),'fund');
 assert.equal(exposureKind('etf','stock'),'fund');
 assert.equal(exposureKind('fund',null),'fund');
 assert.equal(exposureKind('share','stock'),'share');
});
