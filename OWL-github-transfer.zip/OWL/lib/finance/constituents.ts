export type Constituent={
 symbol:string|null;name:string;weightPercent:number;
 sector:string|null;industry:string|null;country:string|null;region:string|null;
 isin?:string|null;classificationSource?:string;countryBasis?:string;
};
export type Constituents={
 status:'ready'|'unavailable'|'not_applicable';
 symbol:string;sourceSymbol?:string;source:'EODHD'|'AJ Bell / Morningstar'|'Scottish Mortgage'|'Baillie Gifford'|'Aberdeen';
 // Displayed slice (top ten by default). A complete provider list is kept
 // separately so changing top-X does not trigger another provider request.
 holdings:Constituent[];allHoldings?:Constituent[];reportedCount?:number|null;
 sourceUrl?:string;listScope?:'holdings'|'equity holdings';weightBasis?:string;
 coveragePercent:number|null;otherPercent:number|null;
 holdingsAsOf:string|null;providerUpdatedAt:string|null;retrievedAt:string;
 cached:boolean;stale:boolean;warnings:string[];
};
