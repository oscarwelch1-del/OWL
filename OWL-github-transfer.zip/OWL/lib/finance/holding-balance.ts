import {allocate,decimal,units,type AccountDraft,type HoldingDraft} from './model';

// Editing a recorded holding changes the account by the same amount. Existing
// cash/unassigned balances are preserved explicitly, never created by deletion.
// Blank amounts and trailing decimal points are valid intermediate editor states.
const amount=(value:string)=>units(value.trim().replace(/\.$/,'')||'0');
export function editHoldingBalance(before:AccountDraft,holdings:HoldingDraft[]):AccountDraft {
 if(before.mode!=='value')return {...before,holdings};
 const oldSum=before.holdings.reduce((n,h)=>n+amount(h.amount),0);
 const newSum=holdings.reduce((n,h)=>n+amount(h.amount),0);
 const remainder=Math.max(0,amount(before.value)-oldSum);
 const value=decimal(remainder+newSum);
 units(value); // Preserve the shared money limits.
 return {...before,holdings,value};
}

export function removeHolding(before:AccountDraft,id:string):AccountDraft {
 if(before.mode==='value')return editHoldingBalance(before,before.holdings.filter(h=>h.id!==id));
 // A deletion is an absolute removal. Freeze the other allocations in pounds
// so changing the denominator cannot inadvertently revalue every survivor.
 const allocated=allocate(before);
 const converted={...before,mode:'value' as const,holdings:before.holdings.map((h,i)=>({...h,amount:decimal(allocated.values[i])}))};
 return editHoldingBalance(converted,converted.holdings.filter(h=>h.id!==id));
}
