import type {ExposureRow} from './exposure';
import {shiftDay,validDay,type Series} from './tracker';

export const comparisonRanges={'1M':31,'3M':93,'1Y':366} as const;
export type ComparisonRange=keyof typeof comparisonRanges;
export const UK_BENCHMARK={id:'ftse100',symbol:'FTSE100.INDX',name:'FTSE 100',description:'UK large-company price index',sourceUrl:'https://www.lseg.com/en/ftse-russell/indices/uk'} as const;
export type BasketMember={symbol:string;name:string;valuePence:number;heldThrough:string[]};
export type ExcludedMember={name:string;symbol:string|null;valuePence:number;reason:string};
export type ComparisonPoint={date:string;basket:number;benchmark:number};
export type ComparisonResult={status:'ready'|'unavailable';points:ComparisonPoint[];included:Array<BasketMember&{weightPercent:number;returnPercent:number}>;excluded:ExcludedMember[];knownUkPence:number;includedPence:number;coveragePercent:number;requestedFrom:string;requestedThrough:string;actualFrom:string|null;actualThrough:string|null;basketReturnPercent:number|null;benchmarkReturnPercent:number|null;differencePp:number|null;messages:string[]};
export type ComparisonResponse=ComparisonResult&{benchmark:typeof UK_BENCHMARK;range:ComparisonRange;generatedAt:string;snapshotDates:string[];unknownGeographyPence:number;totalPence:number;priceSource:'EODHD';methodology:'current-basket-price-return-v1'};

// Only explicit London aliases are accepted. Country and ticker names never
// infer an exchange. Overseas listings need an FX-aware adapter in a later version.
export function londonSymbol(symbol:string|null):string|null{
 const match=/^([A-Z0-9][A-Z0-9._-]{0,30})\.(L|LN|LSE|XLON)$/.exec((symbol||'').toUpperCase());
 return match?match[1]+'.LSE':null;
}
export function ukBasket(rows:ExposureRow[],limit=20){
 const selected=rows.filter(r=>r.country==='United Kingdom'&&r.valuePence>0);
 const knownUkPence=selected.reduce((n,r)=>n+r.valuePence,0);
 const map=new Map<string,BasketMember>();const excluded:ExcludedMember[]=[];
 for(const row of selected){
  const symbol=londonSymbol(row.symbol);
  if(!symbol){excluded.push({name:row.name,symbol:row.symbol,valuePence:row.valuePence,reason:row.symbol?'This listing needs verified currency / FX support':'No verified tradable identifier'});continue;}
  const prior=map.get(symbol);if(prior){prior.valuePence+=row.valuePence;prior.heldThrough=[...new Set([...prior.heldThrough,row.holdingName])];}
  else map.set(symbol,{symbol,name:row.name,valuePence:row.valuePence,heldThrough:[row.holdingName]});
 }
 const sorted=[...map.values()].sort((a,b)=>b.valuePence-a.valuePence||a.symbol.localeCompare(b.symbol));
 for(const m of sorted.slice(limit))excluded.push({...m,reason:`Outside the ${limit}-company request limit`});
 return {members:sorted.slice(0,limit),excluded,knownUkPence};
}
function validSeries(series:Series|undefined,from:string,through:string):series is Series{
 if(!series||series.splitAdjusted||!validDay(series.splitsFrom)||!validDay(series.splitsThrough)||series.splitsFrom>from||series.splitsThrough<through||!series.prices.length)return false;
 const dates=new Set<string>();
 for(const p of series.prices){if(!validDay(p.date)||!Number.isFinite(p.close)||p.close<=0||dates.has(p.date))return false;dates.add(p.date);}
 return series.splits.every(s=>validDay(s.date)&&Number.isFinite(s.factor)&&s.factor>0)&&new Set(series.splits.map(s=>s.date)).size===series.splits.length;
}
// Synthetic buy-and-hold: today's observed weights are applied at the first
// common close. Splits alter hypothetical units once; dividends are excluded.
export function compareBasket(basket:ReturnType<typeof ukBasket>,series:Map<string,Series>,benchmark:Series|undefined,from:string,through:string):ComparisonResult{
 const excluded=[...basket.excluded];const messages:string[]=[];
 const result:ComparisonResult={status:'unavailable',points:[],included:[],excluded,knownUkPence:basket.knownUkPence,includedPence:0,coveragePercent:0,requestedFrom:from,requestedThrough:through,actualFrom:null,actualThrough:null,basketReturnPercent:null,benchmarkReturnPercent:null,differencePp:null,messages};
 if(!basket.knownUkPence){messages.push('No classified UK exposure is available. Refresh fund holdings to improve coverage.');return result;}
 if(!validSeries(benchmark,from,through)||benchmark.symbol!==UK_BENCHMARK.symbol){messages.push('Verified benchmark prices are unavailable. No comparison has been calculated.');return result;}
 const dates=benchmark.prices.filter(p=>p.date>=from&&p.date<=through).map(p=>p.date).sort();
 if(dates.length<2||dates[0]>shiftDay(from,7)||dates.at(-1)!<shiftDay(through,-7)){messages.push('The benchmark does not cover the requested period with recent closes.');return result;}
 const start=dates[0],end=dates.at(-1)!;
 const included:Array<{member:BasketMember;data:Series;prices:Map<string,number>}>=[];
 for(const member of basket.members){
  const data=series.get(member.symbol);
  if(!validSeries(data,from,through)||data.symbol!==member.symbol){excluded.push({...member,reason:'Verified price or split history unavailable'});continue;}
  const prices=new Map(data.prices.map(p=>[p.date,p.close]));
  // Missing beginning/end means exclusion for the whole run, not a changing basket.
  // Allow isolated interior gaps only by omitting those dates from BOTH lines.
  const available=dates.filter(d=>prices.has(d)).length;
  if(!prices.has(start)||!prices.has(end)||available/dates.length<0.9){excluded.push({...member,reason:'Insufficient history over the selected period'});continue;}
  included.push({member,data,prices});
 }
 const includedPence=included.reduce((n,i)=>n+i.member.valuePence,0);
 result.includedPence=includedPence;result.coveragePercent=basket.knownUkPence?includedPence/basket.knownUkPence*100:0;
 if(!includedPence){messages.push('No UK companies have sufficient verified GBP history for this period.');return result;}
 const common=dates.filter(d=>included.every(i=>i.prices.has(d)));
 if(common.length<2||common.length/dates.length<0.8){messages.push('Too few common trading dates. A line would hide material gaps, so the comparison is withheld.');return result;}
 const benchPrices=new Map(benchmark.prices.map(p=>[p.date,p.close]));
 const growth=(i:typeof included[number],d:string)=>i.prices.get(d)!/i.prices.get(start)!*i.data.splits.filter(s=>s.date>start&&s.date<=d).reduce((n,s)=>n*s.factor,1);
 result.points=common.map(date=>({date,basket:100*included.reduce((n,i)=>n+i.member.valuePence/includedPence*growth(i,date),0),benchmark:100*benchPrices.get(date)!/benchPrices.get(start)!}));
 result.included=included.map(i=>({...i.member,weightPercent:i.member.valuePence/includedPence*100,returnPercent:(growth(i,end)-1)*100}));
 result.status='ready';result.actualFrom=start;result.actualThrough=end;
 result.basketReturnPercent=result.points.at(-1)!.basket-100;result.benchmarkReturnPercent=result.points.at(-1)!.benchmark-100;result.differencePp=result.basketReturnPercent-result.benchmarkReturnPercent;
 if(common.length<dates.length)messages.push(`${dates.length-common.length} trading dates omitted from both lines because a constituent close is missing.`);
 if(result.coveragePercent<99.95)messages.push('Partial comparison: included companies are reweighted to 100% of the simulated basket. Excluded exposure is not assumed to have earned zero.');
 return result;
}
