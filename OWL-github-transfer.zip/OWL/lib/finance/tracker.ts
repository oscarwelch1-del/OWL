import type {Listing} from './market';

export type TrackedHolding={id:string;name:string;type:string;ticker:string;isin:string;exchange:string;valuePence:number;quantity:string;quantityDate:string;priceCurrency?:string;listing:Listing|null};
export type TrackedAccount={id:string;name:string;category:string;kind:string;valuePence:number;ownershipBps:number;valuationDate:string;holdings:TrackedHolding[]};
export type Revision={seq:number;accountId:string;recordedAt:number;state:TrackedAccount|null};
export type Close={date:string;close:number};
export type Split={date:string;factor:number};
export type Series={symbol:string;prices:Close[];splits:Split[];from:string;through:string;splitsFrom:string;splitsThrough:string;source:'eodhd'|'yahoo';splitAdjusted:boolean;quoteCurrency?:string;currencyVerifiedAt?:string};
export type ValuedHolding={id:string;accountId:string;name:string;accountName:string;symbol:string|null;valuePence:number;status:'priced'|'carried'|'manual'|'unavailable';reason:string;priceDate:string|null;fxDate:string|null;quantity:number|null;source:'eodhd'|'yahoo'|'manual';quoteCurrency?:string;close?:number;stale?:boolean};
export type DailyPoint={provisional?:boolean;date:string;portfolioPence:number;assetsPence:number;debtPence:number;netPence:number;marketPence:number;recordedPence:number;pricedCount:number;carriedCount:number;unavailableCount:number;manualCount:number;stale:boolean;changePence:number|null;marketChangePence:number|null;accountChanges:boolean;stateKey:string;valuationVersion?:number;accountCount?:number;investmentAccountCount?:number;adjustments?:string[];anomalies?:Partial<Record<'portfolioPence'|'netPence',number>>};
export type AccountValuation={id:string;name:string;category:string;investment:boolean;recordedPence:number;latestPence:number;differencePence:number;statementDate:string;oldestPriceDate:string|null;newestPriceDate:string|null;unavailableCount:number;staleCount:number};
export type TrackingResponse={startedAt:string;through:string;points:Omit<DailyPoint,'stateKey'>[];holdings:ValuedHolding[];recordedPortfolioPence:number;currentPortfolioPence?:number;connection:boolean;refreshing:boolean;pending:boolean;budgetUsed:number;budgetLimit:number;lastRefresh:string|null;messages:string[];mode:'catch-up';accounts?:AccountValuation[];oldestPriceDate?:string|null;newestPriceDate?:string|null;anomalyThresholdPercent?:number};
export const VALUATION_VERSION=2;
export const ANOMALY_THRESHOLD_PERCENT=20;

export const dayOf=(timestamp=Date.now())=>new Date(timestamp).toISOString().slice(0,10);
export function shiftDay(day:string,n:number){return dayOf(Date.parse(day+'T00:00:00Z')+n*86400000);}
export function validDay(value:unknown):value is string{return typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&Number.isFinite(Date.parse(value))&&dayOf(Date.parse(value))===value;}
export const investmentAccount=(a:TrackedAccount)=>a.category==='investment'||(a.category==='pension'&&a.kind!=='defined_benefit');
export const marketHolding=(h:TrackedHolding)=>['share','etf','fund','investment_trust'].includes(h.type);
export function validListing(listing:Listing|null):listing is Listing{return !!listing&&/^[A-Z0-9][A-Z0-9._-]{0,39}\.[A-Z0-9_-]{1,10}$/.test(listing.symbol)&&/^(?:[A-Z]{3}|GBp)$/.test(listing.currency);}
export function quoteCurrency(currency:string){return currency==='GBp'||currency==='GBX'?{currency:'GBP',scale:.01}:{currency,scale:1};}
export const validQuoteCurrency=(currency:unknown):currency is string=>typeof currency==='string'&&/^(?:[A-Z]{3}|GBp)$/.test(currency);
export function completedThrough(symbol:string,now=new Date()):string{
 const today=dayOf(now.getTime()),exchange=symbol.slice(symbol.lastIndexOf('.')+1).toUpperCase();
 const weekday=(day:string)=>{while([0,6].includes(new Date(day+'T12:00:00Z').getUTCDay()))day=shiftDay(day,-1);return day;};
 const market=exchange==='LSE'?{zone:'Europe/London',close:17*60}:exchange==='US'?{zone:'America/New_York',close:16*60+30}:null;
 if(!market)return weekday(shiftDay(today,-1));
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:market.zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now);
 const part=(kind:string)=>parts.find(p=>p.type===kind)?.value||'';
 const localDay=`${part('year')}-${part('month')}-${part('day')}`;
 return weekday(localDay===today&&Number(part('hour'))*60+Number(part('minute'))>=market.close?today:shiftDay(today,-1));
}
export function fxSymbol(currency:string){return currency+'GBP.FOREX';}
const exchangeCurrency:Record<string,string>={US:'USD',LN:'GBp',LSE:'GBp',XLON:'GBp',XETRA:'EUR',GY:'EUR',DE:'EUR',PA:'EUR',FP:'EUR',XPAR:'EUR',AS:'EUR',NA:'EUR',XAMS:'EUR',SW:'CHF',SWX:'CHF',HK:'HKD',AU:'AUD',AX:'AUD',TO:'CAD',TSX:'CAD'};
const exchangeAliases:Record<string,string>={L:'LSE',LN:'LSE',XLON:'LSE',GY:'XETRA',DE:'XETRA',XPAR:'PA',FP:'PA',XAMS:'AS',NA:'AS',SWX:'SW',AU:'AU',AX:'AU',TSX:'TO'};
export function inferredListing(h:TrackedHolding):Listing|null{
 let ticker=(h.ticker||'').trim().toUpperCase();if(!ticker)return null;
 let exchange=(h.listing?.exchange||h.exchange||'').trim().toUpperCase();exchange=exchangeAliases[exchange]||exchange;const dot=ticker.lastIndexOf('.');
 // Accept both a bare ticker plus exchange field and common Yahoo/EOD-style
 // ticker suffixes such as AAPL.US or SMT.L. Never duplicate the suffix.
 if(dot>0){const embedded=exchangeAliases[ticker.slice(dot+1)]||ticker.slice(dot+1);if(exchangeCurrency[embedded]&&(!exchange||embedded===exchange)){if(!exchange)exchange=embedded;ticker=ticker.slice(0,dot);}}
 if(!exchange)return null;exchange=exchange.toUpperCase();
 // This currency is a legacy display hint only. valueHolding requires the
 // provider series' verified unit, never this hint or a CSV price currency.
 const currency=exchangeCurrency[exchange]||'';
 if(!/^[A-Z0-9][A-Z0-9._-]{0,39}$/.test(ticker))return null;
 return {symbol:ticker+'.'+exchange,name:h.name,ticker,exchange,currency,isin:h.isin,type:h.type==='etf'?'ETF':h.type==='share'?'Common Stock':h.type};
}
const latest=(rows:Close[],day:string)=>{let lo=0,hi=rows.length;while(lo<hi){const m=(lo+hi)>>>1;if(rows[m].date<=day)lo=m+1;else hi=m;}return rows[lo-1]??null;};
const safeMoney=(n:number)=>Number.isFinite(n)&&n>=0&&Number.isSafeInteger(Math.round(n));

export function statesOn(revisions:Revision[],day:string){
 const end=Date.parse(shiftDay(day,1)+'T00:00:00Z');
 const states=new Map<string,TrackedAccount>();
 for(const r of [...revisions].sort((a,b)=>a.recordedAt-b.recordedAt||a.seq-b.seq)){
  if(r.recordedAt>=end)continue;
  if(r.state)states.set(r.accountId,r.state);else states.delete(r.accountId);
 }
 return [...states.values()].sort((a,b)=>a.id.localeCompare(b.id));
}

export function valueHolding(h:TrackedHolding,a:TrackedAccount,day:string,series:Map<string,Series>):ValuedHolding{
 const listing=validListing(h.listing)?h.listing:inferredListing(h);const base:ValuedHolding={id:h.id,accountId:a.id,name:h.name,accountName:a.name,symbol:listing?.symbol||null,valuePence:h.valuePence,status:'manual',reason:'Recorded value',priceDate:null,fxDate:null,quantity:null,source:'manual'};
 const unavailable=(reason:string)=>({...base,status:'unavailable' as const,reason});
 if(!marketHolding(h))return base;
 if(!h.quantity||!/^\d+(\.\d{1,8})?$/.test(h.quantity)||!Number.isFinite(Number(h.quantity))||Number(h.quantity)<=0)return unavailable('Add the number of units to track this holding.');
 if(!listing)return unavailable('Add a ticker and exchange to track this holding.');
 if(!validDay(h.quantityDate)||h.quantityDate>day)return unavailable('The units need a valid valuation date.');
 const prices=series.get(listing.symbol);
 const quote=latest(prices?.prices||[],day);
 if(!quote)return unavailable('No closing price available; using the recorded value.');
 // Raw closes are used for value, not dividend-adjusted prices. Units are
 // adjusted only for verified splits after their recorded quantity date.
 if(!prices)return unavailable('No verified closing price is available; using the recorded value.');
 let quantity=Number(h.quantity);
 if(prices.splitAdjusted)return unavailable('The closing-price adjustment needs verification; using the recorded value.');
 {
  if(prices.splitsFrom>h.quantityDate||!prices.splitsFrom||prices.splitsThrough<quote.date)return unavailable('Split data is unavailable; using the recorded value.');
  for(const split of prices.splits)if(split.date>h.quantityDate&&split.date<=quote.date)quantity*=split.factor;
 }
 const providerCurrency=prices.quoteCurrency;
 if(!validQuoteCurrency(providerCurrency))return unavailable('Provider quote currency is unverified; using the recorded value.');
 const unit=quoteCurrency(providerCurrency);
 const fx=unit.currency==='GBP'?null:latest(series.get(fxSymbol(unit.currency))?.prices||[],day);
 if(unit.currency!=='GBP'&&!fx)return unavailable('No GBP exchange rate available; using the recorded value.');
 const raw=quantity*quote.close*unit.scale*(fx?.close??1)*100;
 if(!safeMoney(raw))return unavailable('The calculated value needs review; using the recorded value.');
 const carried=quote.date!==day||!!(fx&&fx.date!==day);
 const asOf=day===dayOf()?new Date():new Date(day+'T23:59:59Z');
 const stale=quote.date<completedThrough(listing.symbol,asOf)||!!(fx&&fx.date<completedThrough(fxSymbol(unit.currency),asOf));
 return {...base,valuePence:Math.round(raw),quantity,status:carried?'carried':'priced',priceDate:quote.date,fxDate:fx?.date??null,reason:stale?'Awaiting a newer market close':carried?'Latest available close carried forward':'Closing price',source:prices.source,quoteCurrency:providerCurrency,close:quote.close,stale};
}

export function valueDay(accounts:TrackedAccount[],day:string,series:Map<string,Series>,previous?:DailyPoint){
 let assets=0,debt=0,portfolio=0,market=0;const holdings:ValuedHolding[]=[];
 for(const a of accounts){
  if(a.category==='income'||(a.category==='pension'&&a.kind==='defined_benefit'))continue;
  let value=a.valuePence;const positions:ValuedHolding[]=[];
  if(investmentAccount(a)){
   for(const h of a.holdings){
    const result=valueHolding(h,a,day,series);
    // Replace each allocated holding inside its account, preserving residual
    // cash/unassigned value. Never add holdings on top of the account total.
    value+=result.valuePence-h.valuePence;
    positions.push(result);
   }
  }
  if(!safeMoney(value))throw new Error('Account value is outside the supported range.');
  const owned=Number((BigInt(value)*BigInt(a.ownershipBps)+5000n)/10000n);
  if(positions.length){
   // Allocate fractional ownership pennies once, across holdings and residual,
   // so the chart segments and holding values always reconcile to the account.
   const pieces=[...positions.map(p=>p.valuePence),a.valuePence-a.holdings.reduce((n,h)=>n+h.valuePence,0)];
   const scaled=pieces.map((p,i)=>{const n=BigInt(p)*BigInt(a.ownershipBps);return {i,value:Number(n/10000n),remainder:Number(n%10000n)};});
   let pennies=owned-scaled.reduce((n,p)=>n+p.value,0);
   for(const p of [...scaled].sort((a,b)=>b.remainder-a.remainder||a.i-b.i)){if(pennies--<=0)break;p.value++;}
   for(let i=0;i<positions.length;i++){
    const result={...positions[i],valuePence:scaled[i].value};holdings.push(result);
    if(result.status==='priced'||result.status==='carried')market+=result.valuePence;
   }
  }
  if(a.category==='debt')debt+=owned;else assets+=owned;
  if(investmentAccount(a))portfolio+=owned;
 }
 if(![assets,debt,portfolio,market].every(Number.isSafeInteger))throw new Error('Portfolio value is outside the supported range.');
 // Names and notes do not affect comparability; quantities, manual values and
 // account changes do. No inferred deposits, dividends or pension income.
 const stateKey=JSON.stringify(accounts.map(a=>[a.id,a.category,a.kind,a.valuePence,a.ownershipBps,a.holdings.map(h=>{const listing=validListing(h.listing)?h.listing:inferredListing(h);return [h.id,h.type,h.quantity,h.quantityDate,h.valuePence,listing?.symbol,listing?.currency]}).sort((a,b)=>String(a[0]).localeCompare(String(b[0])))]));
 const unavailableCount=holdings.filter(h=>h.status==='unavailable').length;
 const stale=holdings.some(h=>h.stale);
 const accountChanges=!!previous&&previous.stateKey!==stateKey;
 const point:DailyPoint={date:day,portfolioPence:portfolio,assetsPence:assets,debtPence:debt,netPence:assets-debt,marketPence:market,recordedPence:portfolio-market,pricedCount:holdings.filter(h=>h.status==='priced').length,carriedCount:holdings.filter(h=>h.status==='carried').length,unavailableCount,manualCount:holdings.filter(h=>h.status==='manual').length,stale,changePence:previous?portfolio-previous.portfolioPence:null,marketChangePence:previous&&!accountChanges&&!unavailableCount&&!previous.unavailableCount&&!stale&&!previous.stale?market-previous.marketPence:null,accountChanges,stateKey};
 point.valuationVersion=VALUATION_VERSION;
 point.accountCount=accounts.filter(a=>a.category!=='income'&&!(a.category==='pension'&&a.kind==='defined_benefit')).length;
 point.investmentAccountCount=accounts.filter(investmentAccount).length;
 applyAnomalyCheck(point,previous);
 return {point,holdings};
}

export function applyAnomalyCheck(point:DailyPoint,previous?:DailyPoint){
 point.anomalies={};
 if(!previous||point.accountChanges||previous.date!==shiftDay(point.date,-1))return;
 for(const metric of ['portfolioPence','netPence'] as const){
  if(previous[metric]===0)continue;
  const percent=(point[metric]-previous[metric])/Math.abs(previous[metric])*100;
  if(Math.abs(percent)>ANOMALY_THRESHOLD_PERCENT)point.anomalies[metric]=percent;
 }
 if(Object.keys(point.anomalies).length)point.marketChangePence=null;
}

export function adjustmentLabels(before:TrackedAccount[],after:TrackedAccount[]):string[]{
 const prior=new Map(before.map(a=>[a.id,a])),next=new Map(after.map(a=>[a.id,a]));
 const labels:string[]=[];
 for(const a of after){const old=prior.get(a.id);if(!old)labels.push(`Account added: ${a.name}`);else{
  const key=(v:TrackedAccount)=>JSON.stringify([v.valuePence,v.ownershipBps,v.category,v.kind,v.holdings.map(h=>[h.id,h.quantity,h.quantityDate,h.valuePence,h.ticker,h.exchange,h.isin])]);
  if(key(old)!==key(a))labels.push(`Balance or holdings changed: ${a.name}`);
 }}
 for(const a of before)if(!next.has(a.id))labels.push(`Account removed: ${a.name}`);
 return labels;
}

export function reconcileAccounts(accounts:TrackedAccount[],day:string,series:Map<string,Series>):AccountValuation[]{
 return accounts.filter(a=>a.category!=='income'&&!(a.category==='pension'&&a.kind==='defined_benefit')).map(a=>{
  const {point,holdings}=valueDay([a],day,series);const recordedPence=Number((BigInt(a.valuePence)*BigInt(a.ownershipBps)+5000n)/10000n);
  const dates=holdings.flatMap(h=>h.priceDate?[h.priceDate]:[]).sort();
  const latestPence=a.category==='debt'?-point.netPence:point.netPence;
  return {id:a.id,name:a.name,category:a.category,investment:investmentAccount(a),recordedPence,latestPence,differencePence:latestPence-recordedPence,statementDate:a.valuationDate,oldestPriceDate:dates[0]||null,newestPriceDate:dates.at(-1)||null,unavailableCount:holdings.filter(h=>h.status==='unavailable').length,staleCount:holdings.filter(h=>h.stale).length};
 });
}

export function normalizeCloses(raw:unknown,from:string,to:string):Close[]{
 if(!Array.isArray(raw))throw new Error('Invalid closing-price response.');
 const byDate=new Map<string,Close>();
 for(const r of raw){
  if(!r||!validDay(r.date)||typeof r.close!=='number'||!Number.isFinite(r.close)||r.close<=0)throw new Error('Invalid closing-price row.');
  if(r.date<from||r.date>to)continue;
  if(byDate.has(r.date))throw new Error('Duplicate closing-price date.');
  byDate.set(r.date,{date:r.date,close:r.close});
 }
 return [...byDate.values()].sort((a,b)=>a.date.localeCompare(b.date));
}
export function normalizeSplits(raw:unknown,from:string,to:string):Split[]{
 if(!Array.isArray(raw))throw new Error('Invalid split response.');
 const byDate=new Map<string,Split>();
 for(const r of raw){
  const match=typeof r?.split==='string'?/^(\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)$/.exec(r.split):null;
  const factor=match?Number(match[1])/Number(match[2]):NaN;
  if(!validDay(r?.date)||!Number.isFinite(factor)||factor<=0)throw new Error('Invalid split row.');
  if(r.date<from||r.date>to)continue;
  if(byDate.has(r.date))throw new Error('Duplicate split date.');
  byDate.set(r.date,{date:r.date,factor});
 }
 return [...byDate.values()].sort((a,b)=>a.date.localeCompare(b.date));
}

// Both providers are normalized to unadjusted prices before they are stored.
// Retain older observations and split coverage when a fallback takes over.
export function mergeSeries(old:Series,next:Series):Series{
 if(old.symbol!==next.symbol||next.splitAdjusted)throw new Error('Incompatible price series.');
 if(old.splitAdjusted||!old.from)return next;
 const prices=new Map(old.prices.map(p=>[p.date,p]));for(const p of next.prices)prices.set(p.date,p);
 const splits=new Map(old.splits.filter(s=>s.date<next.splitsFrom||s.date>next.splitsThrough).map(s=>[s.date,s]));for(const s of next.splits)splits.set(s.date,s);
 return {...next,prices:[...prices.values()].sort((a,b)=>a.date.localeCompare(b.date)),splits:[...splits.values()].sort((a,b)=>a.date.localeCompare(b.date)),from:old.from<next.from?old.from:next.from,through:old.through>next.through?old.through:next.through,splitsFrom:old.splitsFrom&&old.splitsFrom<next.splitsFrom?old.splitsFrom:next.splitsFrom,splitsThrough:old.splitsThrough>next.splitsThrough?old.splitsThrough:next.splitsThrough};
}

export function dailyPercentage(current:Pick<DailyPoint,'date'|'stale'|'unavailableCount'|'accountChanges'|'portfolioPence'|'netPence'|'anomalies'>|undefined,previous:Pick<DailyPoint,'date'|'stale'|'unavailableCount'|'portfolioPence'|'netPence'>|undefined,metric:'portfolioPence'|'netPence'='portfolioPence'){
 if(!current||!previous||current.anomalies?.[metric]!==undefined||previous.date!==shiftDay(current.date,-1)||current.accountChanges||current.stale||previous.stale||current.unavailableCount||previous.unavailableCount||previous[metric]<=0)return null;
 return (current[metric]-previous[metric])/previous[metric]*100;
}
