import type {Constituents} from './constituents';
import geography from './world-map.json';

export const UNKNOWN='Unclassified';
export const continents=['North America','South America','Europe','Africa','Asia','Oceania'] as const;
export type ExposurePosition={id:string;name:string;accountName:string;type:string;valuePence:number;isin?:string;symbol?:string|null};
export type DirectClassification={symbol:string;sector:string|null;industry:string|null;country:string|null;asOf:string|null;retrievedAt:string;source:'EODHD'};
export type ExposureSnapshots={snapshots:Record<string,Constituents|null>;classifications:Record<string,DirectClassification>;readAt:string;remaining?:number;message?:string;issues?:{symbol:string;message:string;checkedAt:string}[]};
export type ExposureRow={holdingId:string;holdingName:string;accountName:string;name:string;symbol:string|null;isin?:string|null;direct?:boolean;valuePence:number;sector:string;industry:string;country:string;continent:string;basis:string;source:string;asOf:string|null;retrievedAt:string|null;stale:boolean;reason:string|null};
export type ExposureGroup={name:string;valuePence:number};
const blank=(value:string|null|undefined)=>!value||/^(unknown|unavailable|n\/a|null|-)$/i.test(value.trim());
const countryAliases:Record<string,string>={'usa':'United States of America','us':'United States of America','united states':'United States of America','uk':'United Kingdom','great britain':'United Kingdom','south korea':'South Korea','korea, republic of':'South Korea','russian federation':'Russia','hong kong':'Hong Kong','hk':'Hong Kong','singapore':'Singapore','sg':'Singapore','taiwan, china':'Taiwan'};
export function countryInfo(raw:string|null){
 if(blank(raw))return {country:UNKNOWN,continent:UNKNOWN};
 const value=countryAliases[raw!.trim().toLowerCase()]||raw!.trim();
 if(['Hong Kong','Singapore','Macao'].includes(value))return {country:value,continent:'Asia'};
 const entry=geography.find(c=>c.aliases.some(a=>a.toLowerCase()===value.toLowerCase()));
 return {country:entry?.name||value,continent:entry?.continent||UNKNOWN};
}
const sectorAliases:Record<string,string>={'information technology':'Technology','financial services':'Financials','financial':'Financials','health care':'Healthcare','consumer cyclical':'Consumer discretionary','consumer defensive':'Consumer staples','communication services':'Communication services','basic materials':'Materials','real estate':'Real estate','consumer discretionary':'Consumer discretionary','consumer staples':'Consumer staples'};
export function sectorName(raw:string|null){return blank(raw)?UNKNOWN:sectorAliases[raw!.trim().toLowerCase()]||raw!.trim();}
export function groups(rows:ExposureRow[],field:'continent'|'country'|'sector'|'industry'):ExposureGroup[]{
 const sums=new Map<string,number>();for(const row of rows)sums.set(row[field],(sums.get(row[field])||0)+row.valuePence);
 return [...sums].map(([name,valuePence])=>({name,valuePence})).filter(r=>r.valuePence>0).sort((a,b)=>b.valuePence-a.valuePence||a.name.localeCompare(b.name));
}
// Pure, provider-independent calculation. No inferred tickers, countries or dates.
export function snapshotHoldings(snapshot:Constituents|null|undefined){
 if(snapshot?.status!=='ready')return null;
 const rows=snapshot.allHoldings?.length?snapshot.allHoldings:snapshot.holdings;
 if(!Array.isArray(rows)||!rows.length)return null;
 const identities=new Set<string>();let sum=0;
 for(const h of rows){
  if(!h.name?.trim()||!Number.isFinite(h.weightPercent)||h.weightPercent<0||h.weightPercent>100)return null;
  const identity=h.isin?.trim().toUpperCase()||h.symbol?.trim().toUpperCase();
  if(identity){if(identities.has(identity))return null;identities.add(identity);}
  sum+=h.weightPercent;
 }
 return sum<=100.000001?rows:null;
}
// Pence are apportioned once per position; every position reconciles exactly.
export function buildExposure(positions:ExposurePosition[],snapshots:ExposureSnapshots['snapshots'],portfolioPence:number,now=Date.now(),classifications:ExposureSnapshots['classifications']={}){
 const rows:ExposureRow[]=[];
 for(const p of positions){
  if(!Number.isSafeInteger(p.valuePence)||p.valuePence<=0)continue;
  const snapshot=snapshots[p.id];
  const base={holdingId:p.id,holdingName:p.name,accountName:p.accountName,source:snapshot?.source||'Recorded holding',asOf:snapshot?.holdingsAsOf||null,retrievedAt:snapshot?.retrievedAt||null,stale:!!snapshot&&(snapshot.stale||now-Date.parse(snapshot.holdingsAsOf||snapshot.retrievedAt)>90*86400000)};
  const unknown=(valuePence:number,reason:string)=>rows.push({...base,name:p.name,symbol:null,valuePence,sector:UNKNOWN,industry:UNKNOWN,country:UNKNOWN,continent:UNKNOWN,basis:'Unavailable',reason});
  if(p.type==='share'){
   const classification=p.symbol?classifications[p.symbol]:null;
   const geo=countryInfo(classification?.country||null);
   rows.push({...base,name:p.name,symbol:p.symbol||null,isin:p.isin||null,direct:true,valuePence:p.valuePence,sector:sectorName(classification?.sector||null),industry:blank(classification?.industry)?UNKNOWN:classification!.industry!,...geo,basis:classification?.country?'EODHD company registration':'Unavailable',source:classification?.source||base.source,asOf:classification?.asOf||null,retrievedAt:classification?.retrievedAt||null,stale:!!classification&&now-Date.parse(classification.retrievedAt)>30*86400000,reason:classification?null:'Company classification not yet available'});continue;
  }
  if(!['etf','fund','investment_trust'].includes(p.type)||snapshot?.status!=='ready'){unknown(p.valuePence,p.type==='cash'?'Cash allocation':p.type==='share'?'Company classification not yet available':'No saved underlying holdings');continue;}
  const holdings=snapshotHoldings(snapshot);
  if(!holdings){unknown(p.valuePence,'Holdings weights need review');continue;}
  const weight=holdings.reduce((sum,h)=>sum+h.weightPercent,0);
  const exact=holdings.map(h=>p.valuePence*h.weightPercent/100);
  const values=exact.map(Math.floor);const target=Math.min(p.valuePence,Math.round(p.valuePence*weight/100));
  let pennies=target-values.reduce((a,b)=>a+b,0);
  for(const {i} of exact.map((v,i)=>({i,f:v-Math.floor(v)})).sort((a,b)=>b.f-a.f)){if(pennies--<=0)break;values[i]++;}
  holdings.forEach((h,i)=>{if(!values[i])return;const geo=countryInfo(h.country);rows.push({...base,name:h.name,symbol:h.symbol,isin:h.isin||null,direct:false,valuePence:values[i],sector:sectorName(h.sector),industry:blank(h.industry)?UNKNOWN:h.industry!,...geo,basis:h.countryBasis||'Source-reported country',reason:null});});
  if(target<p.valuePence)unknown(p.valuePence-target,'Remaining fund allocation is not classified');
 }
 const assigned=rows.reduce((sum,r)=>sum+r.valuePence,0);
 const residual=Math.max(0,portfolioPence-assigned);
 if(residual)rows.push({holdingId:'',holdingName:'Account remainder',accountName:'Investment accounts',name:'Cash / unassigned account balance',symbol:null,valuePence:residual,sector:UNKNOWN,industry:UNKNOWN,country:UNKNOWN,continent:UNKNOWN,basis:'Unavailable',source:'Recorded account',asOf:null,retrievedAt:null,stale:false,reason:'Account balance outside individual holdings'});
 const totalPence=assigned+residual;
 return {rows,totalPence,reconciliationWarning:assigned>portfolioPence,sectorClassifiedPence:rows.filter(r=>r.sector!==UNKNOWN).reduce((s,r)=>s+r.valuePence,0),geographyClassifiedPence:rows.filter(r=>r.continent!==UNKNOWN).reduce((s,r)=>s+r.valuePence,0)};
}
