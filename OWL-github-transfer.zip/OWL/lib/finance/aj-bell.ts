import { allocate, decimal, newHolding, supportsHoldings, units, type AccountDraft, type HoldingDraft, type HoldingType, type InstrumentSearchResult } from './model';

export const normalizeExchange=(v:string)=>({LSE:'LN',XLON:'LN',L:'LN',NASDAQ:'US',NYSE:'US'}[v.toUpperCase()]||v.toUpperCase());
export type ImportRow={line:number;name:string;ticker:string;isin:string;exchange:string;quantity:string;unitPrice:string;valuePence:number|null;priceCurrency:string;valueCurrency:string;priceDate:string;portfolio:string;instrumentCode:string;type:HoldingType;errors:string[];warnings:string[];duplicate:boolean};
export type ImportPreview={rows:ImportRow[];columns:string[];portfolio:string;valuationDate:string;totalPence:number|null};
export type ReviewedRow={row:ImportRow;include:boolean;confirmed:boolean;type:HoldingType;match?:InstrumentSearchResult|HoldingDraft;targetId?:string};

export function portfolioKind(label:string):string {
  const value=label.toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  if(['lifetime isa','stocks shares lifetime isa','stocks shares lisa','lisa'].includes(value))return 'stocks_lisa';
  if(['isa','stocks shares isa','stocks and shares isa'].includes(value))return 'stocks_isa';
  if(['gia','general investment account','dealing account'].includes(value))return 'gia';
  if(['sipp','self invested personal pension'].includes(value))return 'sipp';
  if(value==='direct investments')return 'direct';
  return 'portfolio';
}

export function automaticRows(preview:ImportPreview,draft:AccountDraft,catalog:HoldingDraft[]):ReviewedRow[] {
  return preview.rows.map(row=>{
    const targets=draft.holdings.filter(h=>sameInstrument(row,h));
    const known=catalog.filter(h=>sameInstrument(row,h));
    const identities=new Set(known.map(h=>[h.instrumentId,h.type,h.ticker,h.isin,normalizeExchange(h.exchange)].join('|')));
    const match=targets.length===1?targets[0]:identities.size===1?known[0]:undefined;
    const ambiguous=targets.length>1;
    return {row:ambiguous?{...row,errors:[...row.errors,'Multiple saved holdings have this identifier. Combine them in the account before importing.']}:row,include:true,confirmed:!row.errors.length&&!row.duplicate&&!ambiguous,type:match?.type||row.type,match,targetId:targets.length===1?targets[0].id:undefined};
  });
}

export function automaticMatch(review:ReviewedRow,candidates:InstrumentSearchResult[]):ReviewedRow {
  const r=review.row;
  // A unique identifier on the stated exchange is enough; a company name or
  // an unscoped ticker is not. Ambiguous lookups remain unclassified.
  if(!r.exchange||(review.match&&review.type!=='other'))return review;
  const exact=candidates.filter(c=>normalizeExchange(c.exchange)===normalizeExchange(r.exchange)&&(r.isin?c.isin===r.isin:c.ticker.toUpperCase()===r.ticker));
  if(exact.length!==1)return review;
  return {...review,match:exact[0],type:exact[0].type};
}

export function finishAutomaticImport(draft:AccountDraft,preview:ImportPreview,rows:ReviewedRow[],name:string,createPortfolio=false,useStatementTotal=false):AccountDraft {
  if(!name.trim())throw new Error('Give this portfolio a name.');
  if(rows.some(r=>r.row.errors.length||r.row.duplicate))throw new Error('The CSV contains invalid or duplicate rows. Correct them in the file before importing.');
  if(createPortfolio&&preview.totalPence===null)throw new Error('A reliable portfolio total could not be read from this CSV.');
  const result=mergeImport(draft,rows);
  result.name=name.trim();
  if(createPortfolio){result.kind=portfolioKind(preview.portfolio);result.category=result.kind==='sipp'?'pension':'investment';}
  if((createPortfolio||useStatementTotal)&&preview.totalPence!==null){result.value=decimal(preview.totalPence);if(preview.valuationDate)result.valuationDate=preview.valuationDate;}
  return result;
}

export function readCsv(input:string):string[][] {
  if(input.length>1_000_000)throw new Error('Use a CSV smaller than 1 MB.');
  const text=input.replace(/^\uFEFF/,'');
  const rows:string[][]=[];let row:string[]=[];let field='';let quoted=false;let closed=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(quoted){if(c==='"'){if(text[i+1]==='"'){field+='"';i++;}else{quoted=false;closed=true;}}else field+=c;continue;}
    if(c==='"'){if(field||closed)throw new Error('Invalid quotes in the CSV. Export the statement again.');quoted=true;continue;}
    if(c===','||c==='\n'||c==='\r'){
      row.push(field.trim());field='';closed=false;
      if(c!==','){if(c==='\r'&&text[i+1]==='\n')i++;if(row.some(Boolean))rows.push(row);row=[];}
      if(rows.length>550)throw new Error('Use no more than 500 statement rows.');
    }else {if(closed&&!/\s/.test(c))throw new Error('Unexpected text after a quoted CSV field.');if(!closed)field+=c;}
  }
  if(quoted)throw new Error('The CSV ends inside a quoted field. Paste the complete statement.');
  row.push(field.trim());if(row.some(Boolean))rows.push(row);
  return rows;
}
function numberText(raw:string,places:number):string {
  const v=raw.trim().replace(/^£\s*/,'');
  if(!new RegExp(`^(?:\\d+|\\d{1,3}(?:,\\d{3})+)(?:\\.\\d{1,${places}})?$`).test(v))throw new Error('Invalid number');
  const result=v.replaceAll(',','');
  if(!Number.isFinite(Number(result))||Number(result)>10_000_000_000)throw new Error('Number too large');
  return result;
}
function dateText(raw:string):string {
  if(!raw)return '';
  let value=raw;
  const m=/^(\d{1,2})-([A-Za-z]{3})-(\d{2}|\d{4})$/.exec(raw);
  if(m){const month=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'].indexOf(m[2].toLowerCase())+1;value=`${m[3].length===2?'20'+m[3]:m[3]}-${String(month).padStart(2,'0')}-${m[1].padStart(2,'0')}`;}
  const d=new Date(value+'T00:00:00Z');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(value)||!Number.isFinite(d.getTime())||d.toISOString().slice(0,10)!==value)throw new Error('Invalid date');
  return value;
}
function rowKey(r:ImportRow):string {
  if(r.type==='cash')return 'cash:'+r.valueCurrency;
  if(r.isin)return `isin:${r.isin}:${r.exchange}`;
  if(r.instrumentCode)return 'code:'+r.instrumentCode;
  if(r.ticker)return `ticker:${r.ticker}:${r.exchange}`;
  return 'name:'+r.name.toLowerCase();
}
export function parseAjBell(input:string):ImportPreview {
  const records=readCsv(input);const key=(s:string)=>s.toLowerCase().replace(/[\s_()]/g,'');
  const headerIndex=records.findIndex(r=>r.some(c=>key(c)==='investment')&&r.some(c=>key(c)==='value£'));
  if(headerIndex<0||headerIndex>20)throw new Error('Use an AJ Bell portfolio CSV with Investment, Quantity and Value (£) columns. The account overview export does not contain individual holdings.');
  const header=records[headerIndex];const names=header.map(key);
  if(new Set(names).size!==names.length)throw new Error('The CSV has duplicate column headings.');
  if(!names.includes('quantity')||!names.includes('price'))throw new Error('This portfolio format is missing Quantity or Price.');
  const index=(...labels:string[])=>names.findIndex(n=>labels.map(key).includes(n));
  const col={name:index('Investment'),quantity:index('Quantity'),price:index('Price'),value:index('Value (£)'),ticker:index('Ticker'),isin:index('ISIN'),exchange:index('Exchange'),priceCurrency:index('Market currency','Currency'),valueCurrency:index('Valuation currency'),date:index('Date'),portfolio:index('Portfolio')};
  const rows:ImportRow[]=records.slice(headerIndex+1).map((record,i)=>{
    const cell=(n:number)=>n<0?'':record[n]||'';
    const rawName=cell(col.name);const suffix=/\s*\(([A-Za-z]+):([^()]+)\)\s*$/.exec(rawName);
    const fund=suffix?.[1].toUpperCase()==='FUND';const cash=/^Cash\s+GBP$/i.test(rawName);
    const errors:string[]=[];const warnings:string[]=[];
    const r:ImportRow={line:headerIndex+i+2,name:rawName.replace(/\s*\(([A-Za-z]+):([^()]+)\)\s*$/,''),ticker:fund?'':cell(col.ticker).toUpperCase()||suffix?.[2].toUpperCase()||'',isin:cell(col.isin).toUpperCase(),exchange:fund||cash?'':normalizeExchange(cell(col.exchange)||suffix?.[1]||''),quantity:'',unitPrice:'',valuePence:null,priceCurrency:cell(col.priceCurrency)||'',valueCurrency:cell(col.valueCurrency)||'GBP',priceDate:'',portfolio:cell(col.portfolio),instrumentCode:fund?(cell(col.ticker)||suffix?.[2]||'').toUpperCase():'',type:cash?'cash':fund?'fund':'other',errors,warnings,duplicate:false};
    if(!rawName||r.name.length>120)errors.push('Missing or overly long investment name.');
    if(record.length>header.length)errors.push('Extra columns: check commas and quotes.');
    if(r.valueCurrency!=='GBP')errors.push('Value must be in GBP. This importer does not convert currencies.');
    try{r.valuePence=units(numberText(cell(col.value),2));}catch{errors.push('Enter a valid GBP value in the source CSV.');}
    for(const [field,column,label] of [['quantity',col.quantity,'quantity'],['unitPrice',col.price,'price']] as const){if(cell(column)){try{r[field]=numberText(cell(column),8);}catch{errors.push(`Invalid ${label}.`);}}}
    if(!r.quantity&&!cash)warnings.push('Quantity is missing.');
    if(!r.priceCurrency)warnings.push('Price currency is missing.');
    if(r.priceCurrency&&!/^[A-Z]{3}$|^GBp$/.test(r.priceCurrency))errors.push('Unrecognised price currency.');
    if(r.isin&&!/^[A-Z]{2}[A-Z0-9]{9}\d$/.test(r.isin))errors.push('ISIN must contain 12 characters.');
    if(r.ticker.length>30||r.instrumentCode.length>30||r.exchange.length>20)errors.push('Identifier is too long.');
    if(!fund&&suffix&&cell(col.ticker)&&suffix[2].toUpperCase()!==cell(col.ticker).toUpperCase())errors.push('Ticker disagrees with the investment name.');
    try{r.priceDate=dateText(cell(col.date));if(r.priceDate>new Date().toISOString().slice(0,10))errors.push('Valuation date is in the future.');}catch{errors.push('Invalid valuation date.');}
    if(r.quantity&&r.unitPrice&&['GBP','GBX','GBp'].includes(r.priceCurrency)&&r.valuePence!==null){
      const expected=Number(r.quantity)*Number(r.unitPrice)*(r.priceCurrency==='GBP'?100:1);
      if(Math.abs(Math.round(expected)-r.valuePence)>2)warnings.push('Quantity × price differs from the reported value. Review the statement; the GBP value will be used.');
    }
    return r;
  });
  if(!rows.length)throw new Error('The statement has no holdings.');
  if(rows.length>500)throw new Error('Use no more than 500 statement rows.');
  const counts=new Map<string,number>();for(const r of rows)counts.set(rowKey(r),(counts.get(rowKey(r))||0)+1);
  for(const r of rows)r.duplicate=(counts.get(rowKey(r))||0)>1;
  const portfolios=[...new Set(rows.map(r=>r.portfolio).filter(Boolean))];
  if(portfolios.length>1)throw new Error('This file contains multiple portfolios. Export one account at a time.');
  const dates=[...new Set(rows.map(r=>r.priceDate).filter(Boolean))];
  return {rows,columns:header,portfolio:portfolios[0]||'',valuationDate:dates.length===1?dates[0]:'',totalPence:rows.every(r=>r.valuePence!==null&&!r.duplicate&&!r.errors.length)?rows.reduce((s,r)=>s+r.valuePence!,0):null};
}

export function sameInstrument(row:ImportRow,h:HoldingDraft):boolean {
  if(row.type==='cash')return h.type==='cash'&&/^(Cash GBP|Uninvested cash)$/i.test(h.name);
  if(row.isin&&h.isin)return row.isin===h.isin&&normalizeExchange(row.exchange)===normalizeExchange(h.exchange);
  if(row.instrumentCode&&h.details.instrumentCode)return row.instrumentCode===h.details.instrumentCode;
  return !!row.ticker&&!!row.exchange&&row.ticker===h.ticker.toUpperCase()&&normalizeExchange(row.exchange)===normalizeExchange(h.exchange);
}

// Applying a preview changes only the draft. Saving remains an explicit account
// operation, guarded by the existing account version and user ownership checks.
export function mergeImport(draft:AccountDraft,rows:ReviewedRow[]):AccountDraft {
  if(!supportsHoldings(draft))throw new Error('Choose an investment account or a pension with investment holdings.');
  const selected=rows.filter(r=>r.include);
  if(!selected.length)throw new Error('Select at least one row.');
  const keys=new Set<string>();const targets=new Set<string>();
  const calculated=allocate(draft);
  const holdings=draft.holdings.map((h,i)=>({...h,amount:decimal(calculated.values[i])}));
  for(const review of selected){
    const r=review.row;
    if(r.errors.length||!review.confirmed||r.valuePence===null)throw new Error(`Review row ${r.line} before importing.`);
    const key=rowKey(r);if(keys.has(key))throw new Error('Select only one row for each duplicate holding.');keys.add(key);
    if(review.targetId){if(targets.has(review.targetId))throw new Error('Two rows update the same holding. Select only one.');targets.add(review.targetId);}
    const target=review.targetId?holdings.findIndex(h=>h.id===review.targetId):-1;
    if(!review.targetId&&holdings.some(h=>sameInstrument(r,h)))throw new Error(`Select the existing holding for row ${r.line} instead of creating a duplicate.`);
    if(review.targetId&&target<0)throw new Error('An existing holding changed. Open a fresh preview.');
    const base=target>=0?holdings[target]:newHolding();
    const match=review.match;
    const keepIdentity=target>=0&&sameInstrument(r,base);
    if(!match&&!keepIdentity){base.instrumentId='';base.assetClass='';base.source='';}
    const next:HoldingDraft={...base,name:r.name,type:review.type,amount:decimal(r.valuePence),ticker:match?.ticker||r.ticker||(keepIdentity?base.ticker:''),isin:match?.isin||r.isin||(keepIdentity?base.isin:''),exchange:match?.exchange||r.exchange||(keepIdentity?base.exchange:''),instrumentId:match?('instrumentId' in match?match.instrumentId:match.id):base.instrumentId,assetClass:match?.assetClass||base.assetClass,source:match?.source||base.source,details:{...base.details,quantity:r.quantity,unitPrice:r.unitPrice,priceCurrency:r.priceCurrency,priceDate:r.priceDate,instrumentCode:r.instrumentCode||base.details.instrumentCode}};
    if(target>=0)holdings[target]=next;else holdings.push(next);
  }
  if(holdings.length>100)throw new Error('An account can contain up to 100 holdings.');
  // An imported cash row is explicit. Any leftover balance is unassigned, so
  // previously implicit account cash cannot be counted again.
  return {...draft,mode:'value',holdings,remainder:selected.some(r=>r.type==='cash')?'unassigned':draft.remainder};
}
