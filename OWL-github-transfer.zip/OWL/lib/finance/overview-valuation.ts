import {ownedValue,summary,supportsHoldings,type Account,type Holding} from './model';
import type {TrackingResponse} from './tracker';

// Display values only: never write a market valuation into the editor's
// statement fields or use a changed market total to invent residual cash.
export function overviewValuation(accounts:Account[],tracking:TrackingResponse|null){
 const accountPrices=new Map((tracking?.accounts||[]).map(a=>[a.id,a]));
 const holdingPrices=new Map((tracking?.holdings||[]).map(h=>[h.id,h]));
 const accountValue=(a:Account)=>accountPrices.get(a.id)?.latestPence??ownedValue(a);
 const holdingValue=(h:Pick<Holding,'id'|'valuePence'>)=>holdingPrices.get(h.id)?.valuePence??h.valuePence;
 const totals=summary(accounts);
 totals.assets=accounts.filter(a=>a.category!=='debt').reduce((n,a)=>n+accountValue(a),0);
 totals.debts=accounts.filter(a=>a.category==='debt').reduce((n,a)=>n+accountValue(a),0);
 totals.net=totals.assets-totals.debts;
 totals.investedAccounts=accounts.filter(supportsHoldings).reduce((n,a)=>n+accountValue(a),0);
 return {totals,accountValue,holdingValue,accountPrices};
}
