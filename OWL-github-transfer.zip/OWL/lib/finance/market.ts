export const chartRanges=['1D','1W','1M','3M','YTD','1Y','5Y','MAX'] as const;
export type ChartRange=typeof chartRanges[number];
export type Listing={symbol:string;name:string;ticker:string;exchange:string;currency:string;isin:string;type:string};
export type PricePoint={time:string;close:number;volume:number|null};
export type MarketQuote={price:number;open:number|null;previousClose:number|null;high:number|null;low:number|null;volume:number|null;time:string;kind:'delayed'|'end-of-day'};
export type MarketStats={high52:number|null;low52:number|null;averageVolume:number|null;marketCap:number|null;marketCapCurrency:string|null;dividendYield:number|null;expenseRatio:number|null;updatedAt:string|null};
export type MarketDetail={
 status:'ready'|'setup_required'|'select_listing'|'unmatched';
 priceSource?:string;chartSource?:string;
 candidates?:Listing[];listing?:Listing;quote?:MarketQuote|null;
 points?:PricePoint[];range?:ChartRange;interval?:string;chartNote?:string;
 stats?:MarketStats;warnings?:string[];fetchedAt?:string;
 constituents?:import('./constituents').Constituents;
};

export function priceText(value:number|null|undefined,currency:string){
 if(value==null||!Number.isFinite(value))return 'Unavailable';
 const decimals=value!==0&&Math.abs(value)<1?4:2;
 const formatted=new Intl.NumberFormat('en-GB',{minimumFractionDigits:decimals,maximumFractionDigits:decimals}).format(value);
 // GBp is case-sensitive and means pence, never pounds.
 return ['GBp','GBX'].includes(currency)?`${formatted}p`:`${formatted} ${currency}`;
}
