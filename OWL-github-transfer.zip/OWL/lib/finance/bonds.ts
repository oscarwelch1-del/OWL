import { today, units, type HoldingDetails } from './model';

const periods = {monthly:12, quarterly:4, semiannually:2, annually:1} as const;
export type BondProjection = {annualPence:number; couponPence:number; couponsRemaining:number; totalCouponPence:number; redemptionPence:number; nextCoupon:string|null; matured:boolean};

export function projectBond(d:HoldingDetails, asOf=today()):BondProjection|null {
  if(!d.nominalValue || d.couponRate==='' || !d.maturityDate || d.redemptionValue==='')return null;
  const maturity=new Date(d.maturityDate+'T00:00:00Z');
  const now=new Date(asOf+'T00:00:00Z');
  if(!Number.isFinite(maturity.getTime()) || maturity.toISOString().slice(0,10)!==d.maturityDate || !Number.isFinite(now.getTime()))return null;
  if(!/^\d{1,3}(\.\d{1,4})?$/.test(d.couponRate) || Number(d.couponRate)>100)return null;
  const rate=Number(d.couponRate);
  const frequency=periods[d.couponFrequency as keyof typeof periods];
  if(rate>0 && !frequency)return null;
  let nominal:number, redemption:number;
  try {nominal=units(d.nominalValue);redemption=units(d.redemptionValue);}catch{return null;}
  const annualPence=Math.round(nominal*rate/100);
  const couponPence=rate===0?0:Math.round(nominal*rate/100/frequency);
  let couponsRemaining=0;let nextCoupon:string|null=null;
  if(rate>0 && d.maturityDate>asOf){
    // Regular full coupons, counted backwards from maturity. Calendar dates
    // retain the maturity day, clamped for months with fewer days.
    const months=12/frequency;
    for(let i=0;i<2400;i++){
      const first=new Date(Date.UTC(maturity.getUTCFullYear(),maturity.getUTCMonth()-i*months,1));
      const end=new Date(Date.UTC(first.getUTCFullYear(),first.getUTCMonth()+1,0)).getUTCDate();
      const date=new Date(Date.UTC(first.getUTCFullYear(),first.getUTCMonth(),Math.min(maturity.getUTCDate(),end))).toISOString().slice(0,10);
      if(date<=asOf)break;
      if(i===2399)return null;
      couponsRemaining++;nextCoupon=date;
    }
  }
  return {annualPence,couponPence,couponsRemaining,totalCouponPence:couponPence*couponsRemaining,redemptionPence:redemption,nextCoupon,matured:d.maturityDate<=asOf};
}
