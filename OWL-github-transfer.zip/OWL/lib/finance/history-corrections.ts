import {dayOf,type Revision} from './tracker';

// Remove means correcting a recorded position out of the entire displayed
// history. Keep source revisions untouched for audit; never erase price series.
// Account deletion is a separate action and retains its existing semantics.
export function correctedHoldingHistory(input:Revision[]):{revisions:Revision[];from:string|null}{
 const last=new Map<string,Revision>();
 for(const r of [...input].sort((a,b)=>a.recordedAt-b.recordedAt||a.seq-b.seq))last.set(r.accountId,r);
 const active=new Map([...last].filter(([,r])=>r.state!==null).map(([id,r])=>[id,new Set(r.state!.holdings.map(h=>h.id))]));
 let from:string|null=null;
 const revisions=input.map(r=>{
  const ids=active.get(r.accountId);if(!ids||!r.state)return r;
  const removed=r.state.holdings.filter(h=>!ids.has(h.id));if(!removed.length)return r;
  const valuePence=r.state.valuePence-removed.reduce((n,h)=>n+h.valuePence,0);
  if(valuePence<0)throw new Error('Historical allocation cannot be reconciled.');
  const date=dayOf(r.recordedAt);if(!from||date<from)from=date;
  return {...r,state:{...r.state,valuePence,holdings:r.state.holdings.filter(h=>ids.has(h.id))}};
 });
 return {revisions,from};
}
