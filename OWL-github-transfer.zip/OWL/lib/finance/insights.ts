import {groups,UNKNOWN,type ExposurePosition,type ExposureRow} from './exposure';
import {ownership} from './ownership';

// Review thresholds, not recommendations or a suitability/risk score.
export const INSIGHT_THRESHOLDS={holding:25,security:10,topTen:50,sector:40,country:60} as const;
export function portfolioInsights(positions:ExposurePosition[],rows:ExposureRow[],total:number){
 const positive=positions.filter(p=>Number.isSafeInteger(p.valuePence)&&p.valuePence>0);
 const owned=ownership(rows,total);
 const largest=positive.filter(p=>p.type!=='cash').sort((a,b)=>b.valuePence-a.valuePence||a.id.localeCompare(b.id))[0]||null;
 const country=groups(rows,'country').find(g=>g.name!==UNKNOWN)||null;
 const sector=groups(rows,'sector').find(g=>g.name!==UNKNOWN)||null;
 const cash=positive.filter(p=>p.type==='cash').reduce((s,p)=>s+p.valuePence,0);
 const unclassified=(field:'country'|'sector')=>rows.filter(r=>r[field]===UNKNOWN).reduce((s,r)=>s+r.valuePence,0);
 const overlaps=owned.groups.filter(g=>g.overlap);
 const warnings:{label:string;value:number;threshold:number}[]=[];
 const check=(label:string,value:number,threshold:number)=>{if(total>0&&value/total*100>=threshold)warnings.push({label,value,threshold});};
 if(largest)check(largest.name,largest.valuePence,INSIGHT_THRESHOLDS.holding);
 if(owned.groups[0])check(owned.groups[0].name+' (combined exposure)',owned.groups[0].valuePence,INSIGHT_THRESHOLDS.security);
 check('Top 10 identified holdings',owned.top(10),INSIGHT_THRESHOLDS.topTen);
 if(sector)check(sector.name+' sector',sector.valuePence,INSIGHT_THRESHOLDS.sector);
 if(country)check(country.name,country.valuePence,INSIGHT_THRESHOLDS.country);
 return {largest,company:owned.groups[0]||null,topTen:owned.top(10),count:owned.groups.length,country,sector,cash,sectorUnknown:unclassified('sector'),countryUnknown:unclassified('country'),identified:owned.identifiedPence,overlap:overlaps[0]||null,overlapCount:overlaps.length,warnings};
}
