import {snapshotHoldings,type ExposurePosition,type ExposureRow,type ExposureSnapshots} from './exposure';

const isinOf=(s:string|null|undefined)=>/^[A-Z]{2}[A-Z0-9]{9}\d$/.test((s||'').trim().toUpperCase())?s!.trim().toUpperCase():null;
// Provider symbols in saved public snapshots use Yahoo convention; direct
// positions arrive with the tracker's exchange-qualified listing identity.
export function symbolOf(row:ExposureRow){
 const s=(row.symbol||'').trim().toUpperCase();if(!s)return null;
 const aliases:Record<string,string>={L:'LSE',LN:'LSE',XLON:'LSE',DE:'XETRA',GY:'XETRA',XPAR:'PA',FP:'PA',XAMS:'AS',NA:'AS',AX:'AU',SWX:'SW',TSX:'TO'};
 const dot=s.lastIndexOf('.');
 if(dot>0){const code=s.slice(0,dot),exchange=aliases[s.slice(dot+1)]||s.slice(dot+1);if(/^[A-Z0-9][A-Z0-9._-]*$/.test(code)&&['US','LSE','XETRA','PA','AS','SW','HK','AU','TO','TW','TWO','OL','ST','CO','HE','MI','MC','NZ','T','SI'].includes(exchange))return `${exchange==='US'?code.replaceAll('-','.'):code}.${exchange}`;}
 if(!row.direct&&row.source!=='EODHD'&&/^[A-Z][A-Z0-9-]{0,15}$/.test(s))return s.replaceAll('-','.')+'.US';
 return null;
}
export type OwnershipGroup={id:string;name:string;identifier:string;valuePence:number;directPence:number;fundPence:number;contributions:ExposureRow[];fundCount:number;overlap:boolean};
export function ownership(rows:ExposureRow[],totalPence:number){
 const securities=rows.filter(r=>r.direct||r.reason===null);
 const aliases=new Map<string,Set<string>>();
 for(const r of securities){const isin=isinOf(r.isin),symbol=symbolOf(r);if(isin&&symbol){const ids=aliases.get(symbol)||new Set<string>();ids.add(isin);aliases.set(symbol,ids);}}
 const groups=new Map<string,OwnershipGroup>();const unresolved:ExposureRow[]=[];
 for(const r of securities){
  const isin=isinOf(r.isin),symbol=symbolOf(r),mapped=symbol?aliases.get(symbol):undefined;
  if(!isin&&(!symbol||(mapped&&mapped.size>1))){unresolved.push(r);continue;}
  const identifier=isin||(mapped?.size===1?[...mapped][0]:symbol)!;
  const id=(isin||mapped?.size===1?'isin:':'symbol:')+identifier;
  let group=groups.get(id);if(!group){group={id,name:r.name,identifier,valuePence:0,directPence:0,fundPence:0,contributions:[],fundCount:0,overlap:false};groups.set(id,group);}
  group.valuePence+=r.valuePence;group[r.direct?'directPence':'fundPence']+=r.valuePence;group.contributions.push(r);
 }
 const ranked=[...groups.values()].sort((a,b)=>b.valuePence-a.valuePence||a.identifier.localeCompare(b.identifier));
 for(const g of ranked){g.fundCount=new Set(g.contributions.filter(r=>!r.direct).map(r=>r.holdingId)).size;g.overlap=g.fundCount>1||(g.fundCount>0&&g.directPence>0);}
 const identifiedPence=ranked.reduce((n,g)=>n+g.valuePence,0);
 return {groups:ranked,unresolved,identifiedPence,unknownPence:Math.max(0,totalPence-identifiedPence),top:(n:number)=>ranked.slice(0,n).reduce((s,g)=>s+g.valuePence,0),overlapPence:ranked.filter(g=>g.overlap).reduce((s,g)=>s+g.valuePence,0)};
}
export function fundCoverage(positions:ExposurePosition[],snapshots:ExposureSnapshots['snapshots'],now=Date.now()){
 return positions.filter(p=>['etf','fund','investment_trust'].includes(p.type)).map(p=>{
  const s=snapshots[p.id],rows=snapshotHoldings(s),weight=rows?.reduce((n,h)=>n+h.weightPercent,0)||0;
  const completeness=!s||s.status!=='ready'?'Missing':!rows?'Needs review':weight>=99.995&&(!s.reportedCount||rows.length>=s.reportedCount)?'Full allocation':'Partial';
  const asOf=s?.holdingsAsOf||null;const age=asOf?(now-Date.parse(asOf+'T00:00:00Z'))/86400000:null;
  const freshness=s?.stale?'Refresh failed':age===null||!Number.isFinite(age)?'Holdings date unknown':age<0?'Date needs review':age>90?'Older than 90 days':'Dated within 90 days';
  return {...p,completeness,freshness,weight,count:rows?.length||0,reportedCount:s?.reportedCount||null,asOf,retrievedAt:s?.retrievedAt||null,source:s?.source||'No saved source',sectorWeight:rows?.filter(h=>h.sector&&!/^(unknown|n\/a|unavailable)$/i.test(h.sector)).reduce((n,h)=>n+h.weightPercent,0)||0,countryWeight:rows?.filter(h=>h.country&&!/^(unknown|n\/a|unavailable)$/i.test(h.country)).reduce((n,h)=>n+h.weightPercent,0)||0,action:completeness==='Missing'?'Open holding and refresh its holdings':completeness==='Needs review'?'Refresh and review inconsistent source weights':freshness==='Older than 90 days'||freshness==='Refresh failed'?'Check for a newer report':completeness==='Partial'?'Seek a fuller holdings report':!asOf?'Verify the report date':'No coverage action needed'};
 });
}
