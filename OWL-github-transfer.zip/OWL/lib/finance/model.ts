import { z } from 'zod';

export const categories = [
  {id:'investment',label:'Investments',description:'ISAs, LISAs and dealing accounts',color:'#d4ef99'},
  {id:'cash',label:'Cash & savings',description:'Bank accounts and cash ISAs',color:'#79c4c1'},
  {id:'pension',label:'Pensions',description:'Workplace, personal and defined-benefit pensions',color:'#a2adf0'},
  {id:'property',label:'Property',description:'A property or other real-estate holding',color:'#dbb37c'},
  {id:'other',label:'Other',description:'Anything else you want to record',color:'#c791b8'},
  {id:'debt',label:'Debt',description:'Mortgages, credit cards and loans',color:'#eea398'},
  {id:'income',label:'Income',description:'Money you receive after tax',color:'#e5c77a'},
] as const;
export type Category = typeof categories[number]['id'];
export const kinds:Record<Category, {id:string;label:string}[]> = {
 investment:[{id:'stocks_isa',label:'Stocks & shares ISA'},{id:'stocks_lisa',label:'Stocks & shares LISA'},{id:'gia',label:'General investment account'},{id:'direct',label:'Investments held directly'},{id:'portfolio',label:'Investment portfolio'}],
 cash:[{id:'current',label:'Current account'},{id:'savings',label:'Savings account'},{id:'cash_isa',label:'Cash ISA'},{id:'cash_lisa',label:'Cash LISA'},{id:'fixed_savings',label:'Fixed-term savings'},{id:'premium_bonds',label:'Premium Bonds'},{id:'physical_cash',label:'Physical cash'}],
 pension:[{id:'workplace_dc',label:'Workplace pension (defined contribution)'},{id:'sipp',label:'SIPP'},{id:'personal_pension',label:'Personal pension'},{id:'defined_benefit',label:'Defined benefit pension'}],
 property:[{id:'property',label:'Property'}],
 other:[{id:'custom',label:'Other'}],
  debt:[{id:'mortgage',label:'Mortgage'},{id:'credit_card',label:'Credit card'},{id:'personal_loan',label:'Personal loan'},{id:'car_finance',label:'Car finance'},{id:'student_loan',label:'Student loan'},{id:'overdraft',label:'Overdraft'},{id:'bnpl',label:'Buy now, pay later'},{id:'other_debt',label:'Other debt'}],
 income:[{id:'salary',label:'Salary'},{id:'freelance',label:'Freelance / self-employed income'},{id:'rental_income',label:'Rental income'},{id:'pension_income',label:'Pension income'},{id:'benefits',label:'Benefits'},{id:'other_income',label:'Other income'}],
};
export const holdingTypes = [{id:'etf',label:'ETF'},{id:'fund',label:'Fund'},{id:'investment_trust',label:'Investment trust'},{id:'share',label:'Individual share'},{id:'bond',label:'Bond'},{id:'cash',label:'Cash'},{id:'other',label:'Other investment'}] as const;
export type HoldingType=typeof holdingTypes[number]['id'];
export type InstrumentSearchResult={id:string;name:string;ticker:string;exchange:string;isin:string;type:'etf'|'fund'|'share'|'investment_trust';assetClass:'etf'|'stock';source:'eodhd'};
export type Frequency='weekly'|'monthly'|'quarterly'|'semiannually'|'annually'|'irregular'|'none';
export type PensionContributionMethod='net_pay'|'relief_at_source'|'salary_sacrifice'|'unknown';
export type AccountDetails={interestRate:string;interestFrequency:Frequency;paymentAmount:string;paymentFrequency:Frequency;nextPaymentDate:string;fixedUntil:string;employeeContribution:string;employerContribution:string;contributionFrequency:Frequency;pensionContributionMethod:PensionContributionMethod;grossAnnual:string;netAnnual:string;netAmount:string;incomeFrequency:Frequency;taxYear:string};
export type HoldingDetails={dividendYield:string;dividendFrequency:Frequency;couponRate:string;couponFrequency:Frequency;nominalValue:string;yieldToMaturity:string;maturityDate:string;redemptionValue:string;quantity:string;unitPrice:string;priceCurrency:string;priceDate:string;instrumentCode:string};
export type HoldingDraft={id:string;name:string;type:HoldingType;ticker:string;isin:string;amount:string;instrumentId:string;exchange:string;assetClass:''|'stock'|'etf';source:string;details:HoldingDetails};
export type AccountDraft={id:string;version:number;name:string;category:Category;kind:string;provider:string;value:string;ownership:string;valuationDate:string;mode:'percent'|'value';remainder:'unassigned'|'cash';notes:string;details:AccountDetails;holdings:HoldingDraft[]};
export type Holding = HoldingDraft & {valuePence:number};
export type Account = Omit<AccountDraft,'holdings'> & {valuePence:number;ownershipBps:number;updatedAt:number;holdings:Holding[]};
export const supportsHoldings=(a:Pick<AccountDraft,'category'|'kind'>)=>a.category==='investment'||(a.category==='pension'&&a.kind!=='defined_benefit');
export const isIncome=(a:Pick<AccountDraft,'kind'|'category'>)=>a.category==='income'||a.kind==='defined_benefit';
export const ownershipApplies=(a:Pick<AccountDraft,'category'>)=>a.category==='property'||a.category==='other';
export const money=(pence:number)=>new Intl.NumberFormat('en-GB',{style:'currency',currency:'GBP',minimumFractionDigits:pence%100?2:0,maximumFractionDigits:2}).format(pence/100);
export const decimal=(units:number)=>(units/100).toFixed(2);
export const percent=(value:number,total:number)=>total>0?(value/total*100).toFixed(2)+'%':'—';
export const today=()=>new Date().toISOString().slice(0,10);
export function units(value:string):number {
 if(!/^\d{1,13}(\.\d{1,2})?$/.test(value.trim()))throw new Error('Use a positive number with up to two decimal places.');
 const [whole,fraction='']=value.trim().split('.');
 const result=Number(whole)*100+Number(fraction.padEnd(2,'0'));
 if(!Number.isSafeInteger(result)||result>1_000_000_000_000)throw new Error('The amount is too large.');
 return result;
}
export const blankAccountDetails=():AccountDetails=>({interestRate:'',interestFrequency:'none',paymentAmount:'',paymentFrequency:'none',nextPaymentDate:'',fixedUntil:'',employeeContribution:'',employerContribution:'',contributionFrequency:'monthly',pensionContributionMethod:'unknown',grossAnnual:'',netAnnual:'',netAmount:'',incomeFrequency:'monthly',taxYear:''});
export const blankHoldingDetails=():HoldingDetails=>({dividendYield:'',dividendFrequency:'none',couponRate:'',couponFrequency:'none',nominalValue:'',yieldToMaturity:'',maturityDate:'',redemptionValue:'',quantity:'',unitPrice:'',priceCurrency:'',priceDate:'',instrumentCode:''});
// Repair binary floating-point residue only; meaningful excess precision still
// fails the normal validation instead of being silently rounded away.
export function canonicalUnitPrice(value:string):string {
 if(!/^\d+\.\d{9,}$/.test(value))return value;
 const n=Number(value),rounded=Number(n.toFixed(8));
 return Number.isFinite(n)&&Math.abs(n-rounded)<=Number.EPSILON*Math.max(1,Math.abs(n))*4?rounded.toFixed(8).replace(/\.?0+$/,''):value;
}
// Return only editable schema fields; legacy repair metadata stays out of forms.
export function editableHoldingDetails(value:Partial<HoldingDetails>):HoldingDetails {const defaults=blankHoldingDetails();return Object.fromEntries(Object.entries(defaults).map(([key,fallback])=>[key,key==='unitPrice'?canonicalUnitPrice(value.unitPrice??''):value[key as keyof HoldingDetails]??fallback])) as HoldingDetails;}
export const newHolding=():HoldingDraft=>({id:crypto.randomUUID(),name:'',type:'etf',ticker:'',isin:'',amount:'',instrumentId:'',exchange:'',assetClass:'',source:'',details:blankHoldingDetails()});
export const newAccount=(category:Category='investment'):AccountDraft=>({id:crypto.randomUUID(),version:0,name:'',category,kind:category==='income'?'other_income':category==='debt'?'other_debt':kinds[category][0].id,provider:'',value:'',ownership:'100',valuationDate:today(),mode:'percent',remainder:'unassigned',notes:'',details:blankAccountDetails(),holdings:[]});
export function allocate(a:Pick<AccountDraft,'value'|'mode'|'holdings'>) {
 const total=units(a.value);
 const entered=a.holdings.map(h=>units(h.amount));
 const sum=entered.reduce((s,v)=>s+v,0);
 if(a.mode==='value') {
  if(sum>total)throw new Error('Holdings exceed the account value. Reduce a holding or increase the total.');
  return {values:entered,assigned:sum,remaining:total-sum,allocationBps:total?Math.round(sum/total*10000):0};
 }
 if(sum>10000)throw new Error('Holdings exceed 100% of this account. Reduce an allocation to continue.');
 // Largest-remainder apportionment preserves pennies and closes exactly at 100%.
 const numerators=entered.map(v=>BigInt(total)*BigInt(v));
 const values=numerators.map(v=>Number(v/10000n));
 const assigned=Number((BigInt(total)*BigInt(sum)+5000n)/10000n);
 let extra=assigned-values.reduce((s,v)=>s+v,0);
 const order=numerators.map((v,i)=>({i,f:Number(v%10000n)})).sort((a,b)=>b.f-a.f);
 for(const item of order){if(extra<=0)break;values[item.i]++;extra--;}
 return {values,assigned,remaining:total-assigned,allocationBps:sum};
}
const frequencySchema=z.enum(['weekly','monthly','quarterly','semiannually','annually','irregular','none']);
const accountDetailsSchema=z.object({interestRate:z.string().max(10),interestFrequency:frequencySchema,paymentAmount:z.string().max(20),paymentFrequency:frequencySchema,nextPaymentDate:z.string().max(10),fixedUntil:z.string().max(10),employeeContribution:z.string().max(20),employerContribution:z.string().max(20),contributionFrequency:frequencySchema,pensionContributionMethod:z.enum(['net_pay','relief_at_source','salary_sacrifice','unknown']).default('unknown'),grossAnnual:z.string().max(20),netAnnual:z.string().max(20),netAmount:z.string().max(20).default(''),incomeFrequency:frequencySchema,taxYear:z.string().max(10)}).strict();
const holdingDetailsSchema=z.object({dividendYield:z.string().max(10),dividendFrequency:frequencySchema,couponRate:z.string().max(10),couponFrequency:frequencySchema,nominalValue:z.string().max(20),yieldToMaturity:z.string().max(10),maturityDate:z.string().max(10),redemptionValue:z.string().max(20).default(''),quantity:z.string().max(24).default(''),unitPrice:z.string().max(24).default('').transform(canonicalUnitPrice),priceCurrency:z.string().max(3).default(''),priceDate:z.string().max(10).default(''),instrumentCode:z.string().max(30).default(''),quantitySource:z.string().max(100).optional()}).strict().transform(({quantitySource,...details})=>details);
const holdingSchema=z.object({id:z.string().uuid(),name:z.string().trim().min(1,'Give each holding a name.').max(120),type:z.enum(['etf','fund','investment_trust','share','bond','cash','other']),ticker:z.string().trim().max(30),isin:z.string().trim().max(12).refine(v=>!v||/^[A-Za-z]{2}[A-Za-z0-9]{9}\d$/.test(v),'Use a 12-character ISIN, or leave it blank.'),amount:z.string().max(20),instrumentId:z.string().trim().max(40),exchange:z.string().trim().max(20),assetClass:z.enum(['','stock','etf']),source:z.string().trim().max(30),details:holdingDetailsSchema}).strict();
export const accountSchema=z.object({id:z.string().uuid(),version:z.number().int().min(0),name:z.string().trim().min(1,'Give this account or asset a name.').max(100),category:z.enum(['investment','cash','pension','property','other','debt','income']),kind:z.string().max(40),provider:z.string().trim().max(100),value:z.string().max(20),ownership:z.string().max(10),valuationDate:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),mode:z.enum(['percent','value']),remainder:z.enum(['unassigned','cash']),notes:z.string().trim().max(1000),details:accountDetailsSchema,holdings:z.array(holdingSchema).max(100)}).strict();
export function validateAccount(input:unknown):AccountDraft {
 const result=accountSchema.safeParse(input);
 if(!result.success)throw new Error(result.error.issues[0].message);
 const a=result.data;
 if(a.category==='other')a.kind='custom';
 // Property is intentionally one category. Keep older saved subtype values
 // readable while normalising them to the single current kind.
 if(a.category==='property')a.kind='property';
 if(a.category==='income'){
  if(!a.details.netAmount)throw new Error('Enter the amount you receive after tax.');
  units(a.details.netAmount);a.value=a.details.netAmount;
  if(!['monthly','annually'].includes(a.details.incomeFrequency))throw new Error('Choose monthly or annual income.');
 }
 if(!kinds[a.category].some(k=>k.id===a.kind))throw new Error('Choose an account type within this category.');
 units(a.value);const ownership=units(a.ownership);
 if(ownership<=0||ownership>10000)throw new Error('Ownership must be greater than 0% and no more than 100%.');
 if(!ownershipApplies(a)&&ownership!==10000)throw new Error('Enter only your own balance for this account.');
 const d=new Date(a.valuationDate+'T00:00:00Z');
 if(!Number.isFinite(d.getTime())||d.toISOString().slice(0,10)!==a.valuationDate||a.valuationDate>today()||a.valuationDate<'1900-01-01')throw new Error('Enter a valid valuation date, no later than today.');
 if(new Set(a.holdings.map(h=>h.id)).size!==a.holdings.length)throw new Error('Duplicate holding identifiers. Please reload the account.');
 if(!supportsHoldings(a)&&(a.holdings.length||a.remainder!=='unassigned'))throw new Error('This category does not contain investment holdings.');
 const numericFields=[['interest rate',a.details.interestRate],['payment amount',a.details.paymentAmount],['employee contribution',a.details.employeeContribution],['employer contribution',a.details.employerContribution],['gross annual income',a.details.grossAnnual],['net annual income',a.details.netAnnual]] as const;
 for(const [label,value] of numericFields){if(value&&(!/^\d{1,13}(\.\d{1,4})?$/.test(value.trim())||Number(value)<0))throw new Error(`Enter a valid ${label}.`);}
 if(a.details.interestRate&&Number(a.details.interestRate)>100)throw new Error('Interest rate cannot exceed 100%.');
 const dateFields=[['next payment date',a.details.nextPaymentDate],['fixed-rate end date',a.details.fixedUntil]] as const;
 for(const [label,value] of dateFields){if(value){const date=new Date(value+'T00:00:00Z');if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==value)throw new Error(`Enter a valid ${label}.`);}}
 for(const h of a.holdings){const values=[['dividend yield',h.details.dividendYield],['coupon rate',h.details.couponRate],['yield to maturity',h.details.yieldToMaturity]] as const;for(const [label,value] of values){if(value&&(!/^\d{1,3}(\.\d{1,4})?$/.test(value.trim())||Number(value)<0||Number(value)>100))throw new Error(`Enter a valid ${label}.`);}if(h.details.nominalValue&&(!/^\d{1,13}(\.\d{1,2})?$/.test(h.details.nominalValue)||Number(h.details.nominalValue)<0))throw new Error('Enter a valid bond nominal value.');if(h.details.maturityDate){const date=new Date(h.details.maturityDate+'T00:00:00Z');if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==h.details.maturityDate)throw new Error('Enter a valid bond maturity date.');}}
 for(const h of a.holdings){
  const d=h.details;
  for(const [label,value] of [['quantity',d.quantity],['unit price',d.unitPrice]]){if(value&&(!/^\d{1,13}(\.\d{1,8})?$/.test(value)||!Number.isFinite(Number(value))))throw new Error(`Enter a valid ${label} with up to eight decimal places.`);}
  if(d.redemptionValue)units(d.redemptionValue);
  if(d.priceCurrency&&!/^[A-Z]{3}$|^GBp$|^GBX$/.test(d.priceCurrency))throw new Error('Use a three-letter price currency.');
  if(d.priceDate){const date=new Date(d.priceDate+'T00:00:00Z');if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==d.priceDate||d.priceDate>today())throw new Error('Enter a valid price date, no later than today.');}
 }
 allocate(a);
 return {...a,holdings:a.holdings.map(h=>({...h,ticker:h.ticker.toUpperCase(),isin:h.isin.toUpperCase()}))};
}
export function ownedValue(a:Account) {return isIncome(a)?0:Number((BigInt(a.valuePence)*BigInt(a.ownershipBps)+5000n)/10000n);}
export function summary(accounts:Account[]) {
 const assets=accounts.filter(a=>a.category!=='debt').reduce((s,a)=>s+ownedValue(a),0);
 const debts=accounts.filter(a=>a.category==='debt').reduce((s,a)=>s+ownedValue(a),0);
 const investedAccounts=accounts.filter(supportsHoldings).reduce((s,a)=>s+ownedValue(a),0);
 const pensionIncome=accounts.filter(a=>a.category==='pension'&&a.kind==='defined_benefit').reduce((s,a)=>s+a.valuePence,0);
 return {assets,debts,net:assets-debts,investedAccounts,pensionIncome};
}

// Old gross figures never stand in for take-home income. Existing net annual
// entries retain their exact amount, with an annual period, until edited.
export function incomeDetails(details:AccountDetails):AccountDetails {
 if(details.netAmount||!details.netAnnual)return details;
 return {...details,netAmount:details.netAnnual,incomeFrequency:'annually'};
}
export function incomeText(a:Account):string {
 const d=incomeDetails(a.details);
 return d.netAmount?`${money(units(d.netAmount))} / ${d.incomeFrequency==='monthly'?'month':'year'}`:'After-tax amount needed';
}
