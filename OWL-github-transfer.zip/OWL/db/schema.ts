import { sqliteTable, text, integer, index, uniqueIndex } from 'drizzle-orm/sqlite-core';

export const users = sqliteTable('users', {
  id: text('id').primaryKey(),
  username: text('username').notNull(),
  displayName: text('display_name').notNull(),
  passwordHash: text('password_hash').notNull(),
  createdAt: integer('created_at').notNull(),
}, t => [uniqueIndex('idx_users_username').on(t.username)]);

export const sessions = sqliteTable('sessions', {
  tokenHash: text('token_hash').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, {onDelete:'cascade'}),
  platformUserId: text('platform_user_id').notNull(),
  createdAt: integer('created_at').notNull(),
  expiresAt: integer('expires_at').notNull(),
}, t => [index('idx_sessions_user_id').on(t.userId),index('idx_sessions_expires_at').on(t.expiresAt)]);

export const loginLimits = sqliteTable('login_limits', {
  bucket: text('bucket').primaryKey(),
  attempts: integer('attempts').notNull(),
  resetAt: integer('reset_at').notNull(),
});

export const marketConnections = sqliteTable('market_connections', {
  userId:text('user_id').primaryKey().references(()=>users.id,{onDelete:'cascade'}),
  encryptedToken:text('encrypted_token').notNull(),
  updatedAt:integer('updated_at').notNull(),
});

export const accounts = sqliteTable('accounts', {
  id:text('id').primaryKey(),
  userId:text('user_id').notNull().references(()=>users.id,{onDelete:'cascade'}),
  name:text('name').notNull(), category:text('category').notNull(), kind:text('kind').notNull(),
  provider:text('provider').notNull(), currency:text('currency').notNull().default('GBP'),
  valuePence:integer('value_pence').notNull(), ownershipBps:integer('ownership_bps').notNull(),
  valuationDate:text('valuation_date').notNull(), mode:text('mode').notNull(), remainder:text('remainder').notNull(),
  notes:text('notes').notNull(), version:integer('version').notNull(), writeToken:text('write_token').notNull(),
  updatedAt:integer('updated_at').notNull(),
  detailsJson:text('details_json').notNull().default('{}'),
},t=>[index('idx_accounts_user_id').on(t.userId)]);

export const holdings = sqliteTable('holdings', {
  id:text('id').primaryKey(), accountId:text('account_id').notNull().references(()=>accounts.id,{onDelete:'cascade'}),
  name:text('name').notNull(), type:text('type').notNull(), ticker:text('ticker').notNull(), isin:text('isin').notNull(),
  amount:text('amount').notNull(), valuePence:integer('value_pence').notNull(), position:integer('position').notNull(),
  instrumentId:text('instrument_id'), exchange:text('exchange'), assetClass:text('asset_class'), source:text('source'),
  detailsJson:text('details_json').notNull().default('{}'),
},t=>[index('idx_holdings_account_id').on(t.accountId)]);

export const marketListings = sqliteTable('market_listings', {
  holdingId:text('holding_id').primaryKey().references(()=>holdings.id,{onDelete:'cascade'}),
  listingJson:text('listing_json').notNull(),
  selectedAt:integer('selected_at').notNull(),
});

export const portfolioSnapshots = sqliteTable('portfolio_snapshots', {
  id:text('id').primaryKey(),
  userId:text('user_id').notNull().references(()=>users.id,{onDelete:'cascade'}),
  snapshotDate:text('snapshot_date').notNull(),
  assetsPence:integer('assets_pence').notNull(),
  debtPence:integer('debt_pence').notNull(),
  netPence:integer('net_pence').notNull(),
  createdAt:integer('created_at').notNull(),
},t=>[index('idx_snapshots_user_date').on(t.userId,t.snapshotDate)]);

// Account revisions are captured in the same transaction as the account write.
// Deleted accounts remain in history; deleting a user removes all their data.
export const trackingRevisions = sqliteTable('tracking_revisions', {
  seq:integer('seq').primaryKey({autoIncrement:true}),
  userId:text('user_id').notNull().references(()=>users.id,{onDelete:'cascade'}),
  accountId:text('account_id').notNull(),
  recordedAt:integer('recorded_at').notNull(),
  stateJson:text('state_json'),
},t=>[index('idx_tracking_revisions_user_account').on(t.userId,t.accountId,t.seq)]);

export const trackingDays = sqliteTable('tracking_days', {
  id:text('id').primaryKey(),
  userId:text('user_id').notNull().references(()=>users.id,{onDelete:'cascade'}),
  day:text('day').notNull(),
  snapshotJson:text('snapshot_json').notNull(),
  updatedAt:integer('updated_at').notNull(),
},t=>[uniqueIndex('idx_tracking_days_user_day').on(t.userId,t.day)]);

export const trackingSeries = sqliteTable('tracking_series', {
  id:text('id').primaryKey(),
  userId:text('user_id').notNull().references(()=>users.id,{onDelete:'cascade'}),
  symbol:text('symbol').notNull(),
  dataJson:text('data_json').notNull(),
  attemptedDay:text('attempted_day').notNull(),
  error:text('error').notNull().default(''),
},t=>[uniqueIndex('idx_tracking_series_user_symbol').on(t.userId,t.symbol)]);

export const trackingRuns = sqliteTable('tracking_runs', {
  userId:text('user_id').primaryKey().references(()=>users.id,{onDelete:'cascade'}),
  startedAt:integer('started_at').notNull(),
  leaseUntil:integer('lease_until').notNull().default(0),
  leaseToken:text('lease_token').notNull().default(''),
  budgetDate:text('budget_date').notNull().default(''),
  budgetUsed:integer('budget_used').notNull().default(0),
  lastRefresh:integer('last_refresh'),
},t=>[]);

// Append verified observations; later fund changes never replace older lists.
// Public comparison prices are separate from user portfolio/tracker history.
export const comparisonPrices=sqliteTable('comparison_prices',{
 symbol:text('symbol').primaryKey(),
 dataJson:text('data_json'),
 checkedAt:integer('checked_at').notNull().default(0),
 retryAfter:integer('retry_after').notNull().default(0),
 error:text('error').notNull().default(''),
});

export const fundConstituentSnapshots=sqliteTable('fund_constituent_snapshots',{
 id:text('id').primaryKey(),
 userId:text('user_id').notNull().references(()=>users.id,{onDelete:'cascade'}),
 listingKey:text('listing_key').notNull(),
 symbol:text('symbol').notNull(),
 dataHash:text('data_hash').notNull(),
 dataJson:text('data_json').notNull(),
 retrievedAt:integer('retrieved_at').notNull(),
},t=>[index('idx_fund_snapshots_user_listing_date').on(t.userId,t.listingKey,t.retrievedAt)]);

// Coverage checks include negative results so uncovered symbols are not retried
// on every visit. Classification values always come from EODHD fundamentals.
export const exposureMetadata=sqliteTable('exposure_metadata',{
 id:text('id').primaryKey(),
 userId:text('user_id').notNull().references(()=>users.id,{onDelete:'cascade'}),
 symbol:text('symbol').notNull(),
 kind:text('kind').notNull(),
 dataJson:text('data_json'),
 checkedAt:integer('checked_at').notNull(),
 retryAfter:integer('retry_after').notNull(),
},t=>[index('idx_exposure_metadata_user_kind').on(t.userId,t.kind)]);
