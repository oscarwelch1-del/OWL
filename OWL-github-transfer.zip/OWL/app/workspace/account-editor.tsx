'use client';
import { useEffect,useRef,useState } from 'react';
import { ArrowLeft,ArrowRight,Plus,Trash2,LoaderCircle,Check,Info,Search,X,CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Sheet,SheetContent,SheetHeader,SheetTitle,SheetDescription } from '@/components/ui/sheet';
import { Select,SelectTrigger,SelectValue,SelectContent,SelectItem } from '@/components/ui/select';
import { Tabs,TabsList,TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup,RadioGroupItem } from '@/components/ui/radio-group';
import { Progress } from '@/components/ui/progress';
import { AlertDialog,AlertDialogContent,AlertDialogHeader,AlertDialogTitle,AlertDialogDescription,AlertDialogFooter,AlertDialogCancel,AlertDialogAction } from '@/components/ui/alert-dialog';
import { categories,kinds,holdingTypes,newAccount,newHolding,supportsHoldings,ownershipApplies,isIncome,allocate,units,decimal,money,validateAccount,today,incomeDetails,type AccountDraft,type Category,type HoldingDraft,type InstrumentSearchResult } from '@/lib/finance/model';
import FinancialDetails from './financial-details';
import HoldingDetails from './holding-details';
import PensionHoldingDetails from './pension-holding-details';
import CsvImport from './csv-import';
import {editHoldingBalance,removeHolding} from '@/lib/finance/holding-balance';

export function Choice({id,value,onChange,options,disabled=false}:{id:string;value:string;onChange:(v:string)=>void;options:readonly {id:string;label:string}[];disabled?:boolean}) {
 return <Select value={value} onValueChange={onChange} disabled={disabled}><SelectTrigger id={id} className="finance-select"><SelectValue /></SelectTrigger><SelectContent position="popper">{options.map(o=><SelectItem key={o.id} value={o.id}>{o.label}</SelectItem>)}</SelectContent></Select>;
}
function Field({label,id,children,hint}:{label:string;id:string;children:React.ReactNode;hint?:string}){return <div className="entry-field"><Label htmlFor={id}>{label}</Label>{children}{hint&&<p className="field-hint">{hint}</p>}</div>;}

export default function AccountEditor({initial,onClose,onSave,catalog=[]}:{initial:AccountDraft;catalog?:HoldingDraft[];onClose:()=>void;onSave:(draft:AccountDraft)=>Promise<void>}) {
 const [draft,setDraft]=useState<AccountDraft>(()=>({...structuredClone(initial),kind:initial.category==='other'?'custom':initial.kind,details:initial.category==='income'?incomeDetails(initial.details):initial.details}));
 const [stage,setStage]=useState<'category'|'details'|'holdings'>(initial.version?'details':'category');
 const editorScroll=useRef<HTMLDivElement>(null);const [newHoldingIds,setNewHoldingIds]=useState<string[]>([]);
 const [importOpen,setImportOpen]=useState(false);
 const [busy,setBusy]=useState(false);const [error,setError]=useState('');const [discard,setDiscard]=useState(false);
 const [searching,setSearching]=useState<string|null>(null);const [searchQuery,setSearchQuery]=useState<Record<string,string>>({});const [searchResults,setSearchResults]=useState<Record<string,InstrumentSearchResult[]>>({});const [searchErrors,setSearchErrors]=useState<Record<string,string>>({});
 const dirty=JSON.stringify(initial)!==JSON.stringify(draft);
 const balanced=useRef(draft);
 const startingTotal=useRef(initial.value);
 const patch=(change:Partial<AccountDraft>)=>{setDraft(d=>{
  let next={...d,...change};
  try{
   if(change.holdings&&next.mode==='value'&&!('value' in change)){
    next={...next,value:initial.version===0?decimal(Math.max(units(startingTotal.current||'0'),change.holdings.reduce((n,h)=>n+units(h.amount.trim().replace(/\.$/,'')||'0'),0))):editHoldingBalance(balanced.current,change.holdings).value};
   }
   // Invalid partial input must not become the next calculation baseline.
   if(next.mode==='value')editHoldingBalance(next,next.holdings);
   balanced.current=next;
   if('value' in change)startingTotal.current=next.value;
  }catch{/* Keep the last valid balance while an amount is incomplete. */}
  return next;
 });setError('');};
 function deleteHolding(id:string){
  try{patch(removeHolding(draft,id));}catch{setError('Finish the holding amounts before removing a holding.');}
 }
 useEffect(()=>{const warn=(e:BeforeUnloadEvent)=>{if(dirty){e.preventDefault();e.returnValue='';}};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);},[dirty]);
 let calculated:ReturnType<typeof allocate>|null=null;let allocationError='';
 try{calculated=allocate(draft);}catch(e){allocationError=e instanceof Error?e.message:'Check your holding values.';}
 function close(){if(busy)return;if(dirty)setDiscard(true);else onClose();}
 function choose(category:Category){setDraft({...newAccount(category),id:initial.id});setStage('details');}
 function updateHolding(id:string,values:Partial<HoldingDraft>){
  const identityEdited=!('instrumentId' in values)&&(['ticker','isin','type','exchange'] as const).some(key=>key in values);
  const nextValues:Partial<HoldingDraft>=identityEdited?{...values,instrumentId:'',assetClass:'',source:''}:values;
  patch({holdings:draft.holdings.map(h=>h.id===id?{...h,...nextValues}:h)});
 }
 function addHolding(){
  const holding=newHolding();
  setNewHoldingIds(ids=>[...ids,holding.id]);
  patch({holdings:[holding,...draft.holdings]});
  requestAnimationFrame(()=>editorScroll.current?.scrollTo({top:0,behavior:'smooth'}));
 }
 async function searchHolding(h:HoldingDraft){
  const query=(searchQuery[h.id]||h.ticker||h.isin).trim();
  if(!query){setSearchErrors(s=>({...s,[h.id]:'Enter a ticker or ISIN first.'}));return;}
  setSearching(h.id);setSearchErrors(s=>({...s,[h.id]:''}));setSearchResults(s=>({...s,[h.id]:[]}));
  try{
   const response=await fetch(`/api/instruments/search?q=${encodeURIComponent(query)}${h.exchange?'&exchange='+encodeURIComponent(h.exchange):''}`,{cache:'no-store'});const data=await response.json() as {results?:InstrumentSearchResult[];error?:string};
   if(!response.ok)throw new Error(data.error||'Instrument lookup failed.');
   const results=Array.isArray(data.results)?data.results:[];setSearchResults(s=>({...s,[h.id]:results}));
   if(!results.length)setSearchErrors(s=>({...s,[h.id]:'No matching stock or ETF was found. You can enter it manually.'}));
  }catch(e){setSearchErrors(s=>({...s,[h.id]:e instanceof Error?e.message:'Instrument lookup failed. You can enter it manually.'}));}
  finally{setSearching(null);}
 }
 function chooseInstrument(id:string,result:InstrumentSearchResult){
  updateHolding(id,{name:result.name,type:result.type,ticker:result.ticker,isin:result.isin,instrumentId:result.id,exchange:result.exchange,assetClass:result.assetClass,source:result.source});
  setSearchResults(s=>({...s,[id]:[]}));setSearchErrors(s=>({...s,[id]:''}));setSearchQuery(s=>({...s,[id]:result.ticker}));
 }
 function clearInstrument(id:string){updateHolding(id,{instrumentId:'',exchange:'',assetClass:'',source:''});setSearchResults(s=>({...s,[id]:[]}));}
 function switchMode(mode:'percent'|'value') {
  if(mode===draft.mode)return;
  if(!draft.holdings.length){patch({mode});return;}
  try{
   const c=allocate(draft);const total=units(draft.value);
   if(!total&&mode==='percent')throw new Error('Enter an account value above £0 before converting to percentages.');
   let bps=draft.holdings.map((_,i)=>total?Math.floor(c.values[i]/total*10000):0);
   let remaining=total?Math.round(c.assigned/total*10000)-bps.reduce((s,v)=>s+v,0):0;
   const order=c.values.map((v,i)=>({i,r:total?(v/total*10000)%1:0})).sort((a,b)=>b.r-a.r);
   for(const x of order){if(remaining<=0)break;bps[x.i]++;remaining--;}
   patch({mode,holdings:draft.holdings.map((h,i)=>({...h,amount:decimal(mode==='value'?c.values[i]:bps[i])}))});
  }catch(e){setError(e instanceof Error?e.message:'Complete each holding before switching.');}
 }
 function next(){try{validateAccount({...draft,holdings:[],remainder:'unassigned'});setError('');setStage('holdings');}catch(e){setError(e instanceof Error?e.message:'Check your details.');}}
 async function save(){try{const clean=validateAccount(draft);const newIds=new Set(newHoldingIds);const persisted={...clean,holdings:[...clean.holdings.filter(h=>!newIds.has(h.id)),...clean.holdings.filter(h=>newIds.has(h.id))]};setError('');setBusy(true);await onSave(persisted);onClose();}catch(e){setError(e instanceof Error?e.message:'Unable to save. Please try again.');setBusy(false);}}
 const DetailsComponent=draft.category==='pension'?PensionHoldingDetails:HoldingDetails;
 const allocation=calculated?calculated.allocationBps/100:0;
 const title=stage==='category'?'What would you like to add?':stage==='holdings'?'Add your actual investments.':initial.version?'Edit your entry.':'Start with the details.';
 return <><Sheet open onOpenChange={open=>{if(!open)close();}}><SheetContent className="account-sheet" onOpenAutoFocus={e=>e.preventDefault()}><SheetHeader className="editor-header"><span className="eyebrow">{initial.version?'UPDATE YOUR FINANCIAL PICTURE':'BUILD YOUR FINANCIAL PICTURE'}</span><SheetTitle>{title}</SheetTitle><SheetDescription>{stage==='category'?'Choose a category. You can add as many entries as you need.':stage==='holdings'?`${draft.name} · ${money(units(draft.value))} · GBP`:'Use the latest values from your account or statement. All amounts are in GBP.'}</SheetDescription></SheetHeader>
 {stage!=='category'&&<div className="editor-steps"><span className={stage==='details'?'active-step':''}><b>1</b> Account details</span>{supportsHoldings(draft)&&<><span className="step-line"/><span className={stage==='holdings'?'active-step':''}><b>2</b> Holdings & allocation</span></>}</div>}
 <div ref={editorScroll} className="editor-scroll">{stage==='category'?<div className="category-picker">{categories.map(c=><button key={c.id} onClick={()=>choose(c.id)} className="category-choice"><span className="category-stripe" style={{background:c.color}}/><strong>{c.label}</strong><span>{c.description}</span><ArrowRight size={18}/></button>)}</div>:stage==='details'?<div className="details-form">
 {draft.category==='pension'?<div className="editor-form-grid"><Field label="Category" id="category"><Input id="category" value="Pensions" readOnly/></Field><Field label="Pension type" id="kind"><Choice id="kind" value={draft.kind} disabled={!!initial.version} onChange={kind=>patch({kind,holdings:[],remainder:'unassigned'})} options={kinds.pension}/></Field></div>:(draft.category==='investment'||draft.category==='cash')&&<Field label={draft.category==='cash'?'Account designation':'Account type'} id="kind"><Choice id="kind" value={draft.kind} onChange={kind=>patch({kind})} options={kinds[draft.category]}/></Field>}
 <Field label={draft.category==='income'?'Income name':draft.category==='debt'?'Debt name':draft.category==='pension'?'Pension name':ownershipApplies(draft)?'Asset name':'Account name'} id="account-name"><Input id="account-name" value={draft.name} onChange={e=>patch({name:e.target.value})} maxLength={100} placeholder={draft.category==='income'?'e.g. Employment income':draft.category==='pension'?'e.g. Workplace pension':'Give this entry a name'}/></Field>
 {draft.category==='income'?<div className="editor-form-grid"><Field label="Amount after tax (£)" id="net-amount"><Input id="net-amount" inputMode="decimal" value={draft.details.netAmount} onChange={e=>patch({value:e.target.value||'0',details:{...draft.details,netAmount:e.target.value}})} placeholder="e.g. 2400.00" maxLength={16}/></Field><Field label="Frequency" id="income-frequency"><Choice id="income-frequency" value={draft.details.incomeFrequency} onChange={v=>patch({details:{...draft.details,incomeFrequency:v as 'monthly'|'annually'}})} options={[{id:'monthly',label:'Monthly'},{id:'annually',label:'Annually'}]}/></Field></div>:<div className="editor-form-grid"><Field label={isIncome(draft)?'Estimated annual pension income (£)':draft.category==='debt'?'Outstanding balance — your share (£)':ownershipApplies(draft)?'Full asset value (£)':draft.category==='cash'?'Current balance (£)':'Current account value (£)'} id="account-value" hint={isIncome(draft)?'The expected annual income from this defined-benefit scheme, not a pension pot value.':''}><Input id="account-value" inputMode="decimal" value={draft.value} onChange={e=>patch({value:e.target.value})} placeholder="0.00" maxLength={16}/></Field><Field label={isIncome(draft)?'Estimate date':'Valuation date'} id="valuation-date"><Input id="valuation-date" type="date" max={today()} min="1900-01-01" value={draft.valuationDate} onChange={e=>patch({valuationDate:e.target.value})}/></Field></div>}
 {ownershipApplies(draft)&&<Field label="Your ownership (%)" id="ownership" hint="Only your share is included in net worth."><Input id="ownership" inputMode="decimal" value={draft.ownership} onChange={e=>patch({ownership:e.target.value})}/></Field>}
 {draft.category==='property'&&<div className="form-tip"><Info size={17}/><p>Enter the property’s value before deducting any mortgage. Add your share of the mortgage separately under Debt.</p></div>}
 {draft.category==='pension'&&isIncome(draft)&&<div className="form-tip"><Info size={17}/><p>This records future annual pension income. It is shown separately and is not added to your assets or net worth.</p></div>}{draft.category==='pension'&&!isIncome(draft)&&<div className="form-tip"><Info size={17}/><p>This is the current value of a defined-contribution pension pot. Contributions are recorded separately below and are not added to income.</p></div>}
 {initial.version>0&&supportsHoldings(draft)&&<p className="field-hint">{draft.mode==='percent'?'Changing the account value scales the £ value of your percentage holdings.':'Your holding amounts stay fixed when you change the account value.'}</p>}
 {draft.category!=='income'&&<Field label="Notes (optional)" id="notes"><Textarea id="notes" value={draft.notes} onChange={e=>patch({notes:e.target.value})} maxLength={1000} placeholder="Anything useful to remember about this entry."/></Field>}<FinancialDetails draft={draft} patch={patch}/>
 </div>:<div className={`holdings-form ${draft.category==='pension'?'pension-holdings':''}`}>{supportsHoldings(draft)&&<div className="import-entry"><Button variant="outline" onClick={()=>setImportOpen(true)}>Import AJ Bell CSV</Button><span>Upload or paste, then review your holdings.</span></div>}<div className="holding-toolbar"><div><Label>Enter holdings as</Label><Tabs value={draft.mode} onValueChange={m=>switchMode(m as 'percent'|'value')}><TabsList><TabsTrigger value="percent">% of this account</TabsTrigger><TabsTrigger value="value">{draft.category==='pension'?'£ value':'Quantity & £ value'}</TabsTrigger></TabsList></Tabs></div><Button variant="outline" disabled={draft.holdings.length>=100} onClick={addHolding}><Plus/>Add holding</Button></div><p className="field-hint">Matched stocks and ETFs fill their identifiers automatically. Bonds and unsupported assets can be entered manually; choose Bond to reveal coupon and maturity fields.</p>
 {!draft.holdings.length&&<div className="holdings-empty"><Plus size={24}/><h3>What’s inside this account?</h3><p>Add an ETF, fund, share, bond or other investment. You can also save the balance now and fill in holdings later.</p><Button variant="outline" onClick={addHolding}>Add your first holding</Button></div>}
 {draft.holdings.map((h,i)=><div className="holding-entry" key={h.id}><div className="holding-entry-heading"><span>HOLDING {String(i+1).padStart(2,'0')}</span><Button size="icon-sm" variant="ghost" aria-label={`Remove holding ${i+1}`} onClick={()=>deleteHolding(h.id)}><Trash2 size={16}/></Button></div>
 {(h.type==='etf'||h.type==='share'||h.type==='investment_trust')&&<div className="instrument-lookup"><div className="lookup-label"><Label htmlFor={`lookup-${h.id}`}>Find by ticker or ISIN</Label><span>Stocks and ETFs only</span></div><div className="lookup-row"><Input id={`lookup-${h.id}`} value={searchQuery[h.id]??h.ticker} onChange={e=>setSearchQuery(s=>({...s,[h.id]:e.target.value}))} onKeyDown={e=>{if(e.key==='Enter'){e.preventDefault();void searchHolding(h);}}} placeholder="e.g. VWRL or US0378331005" maxLength={30}/><Button type="button" variant="outline" onClick={()=>void searchHolding(h)} disabled={searching===h.id}>{searching===h.id?<LoaderCircle className="animate-spin"/>:<Search size={16}/>} {searching===h.id?'Searching…':'Find instrument'}</Button></div>{h.instrumentId&&<div className="selected-instrument"><CheckCircle2 size={16}/><span><strong>Matched: {h.name}</strong><small>{h.ticker}{h.exchange?` · ${h.exchange}`:''}{h.instrumentId?` · FIGI ${h.instrumentId}`:''}</small></span><Button type="button" size="icon-sm" variant="ghost" aria-label="Clear matched instrument" onClick={()=>clearInstrument(h.id)}><X size={15}/></Button></div>}{searchErrors[h.id]&&<p className="lookup-error" role="status">{searchErrors[h.id]}</p>}{(searchResults[h.id]||[]).length>0&&<div className="instrument-results">{(searchResults[h.id]||[]).map(result=><button type="button" key={`${result.id}-${result.exchange}`} onClick={()=>chooseInstrument(h.id,result)}><strong>{result.name}</strong><small>{result.ticker}{result.exchange?` · ${result.exchange}`:''} · {result.type==='etf'?'ETF':'Share'}{result.isin?` · ${result.isin}`:''}</small></button>)}</div>}</div>}
 <Field label={h.type==='bond'?'Bond name':'Investment name'} id={`name-${h.id}`}><Input id={`name-${h.id}`} value={h.name} onChange={e=>updateHolding(h.id,{name:e.target.value})} maxLength={120} placeholder={h.type==='bond'?'e.g. UK Treasury Gilt 4.25% 2034':'e.g. Vanguard FTSE All-World UCITS ETF'}/></Field><div className="editor-form-grid">{!h.instrumentId&&<Field label="Investment type" id={`type-${h.id}`}><Choice id={`type-${h.id}`} value={h.type} onChange={v=>updateHolding(h.id,{type:v as HoldingDraft['type']})} options={holdingTypes}/></Field>}<Field label={draft.mode==='percent'?'% of this account':'Value (£)'} id={`amount-${h.id}`}><Input id={`amount-${h.id}`} inputMode="decimal" value={h.amount} onChange={e=>updateHolding(h.id,{amount:e.target.value})} placeholder="0.00" maxLength={16}/></Field></div><details className="holding-identifiers-disclosure"><summary>Identifiers{h.ticker?` · ${h.ticker}`:h.details.instrumentCode?` · ${h.details.instrumentCode}`:''}</summary><div className="holding-identifiers"><Field label="Ticker (optional)" id={`ticker-${h.id}`}><Input id={`ticker-${h.id}`} value={h.ticker} onChange={e=>{setSearchQuery(s=>({...s,[h.id]:e.target.value}));updateHolding(h.id,{ticker:e.target.value});}} placeholder="e.g. VWRL.L" maxLength={30}/></Field><Field label="ISIN (optional)" id={`isin-${h.id}`}><Input id={`isin-${h.id}`} value={h.isin} onChange={e=>{setSearchQuery(s=>({...s,[h.id]:e.target.value}));updateHolding(h.id,{isin:e.target.value});}} placeholder="12-character identifier" maxLength={12}/></Field><Field label="Exchange" id={`exchange-${h.id}`}><Input id={`exchange-${h.id}`} value={h.exchange} onChange={e=>updateHolding(h.id,{exchange:e.target.value.toUpperCase()})} placeholder="e.g. LN for London" maxLength={20}/></Field>{h.details.instrumentCode&&<Field label="Fund code from statement" id={`fund-code-${h.id}`}><Input id={`fund-code-${h.id}`} value={h.details.instrumentCode} readOnly/></Field>}</div></details><div className="holding-equivalent"><span>{draft.mode==='percent'?'Calculated value':'Of this account'}</span><strong>{calculated?(draft.mode==='percent'?money(calculated.values[i]):units(draft.value)?(calculated.values[i]/units(draft.value)*100).toFixed(2)+'%':'—'):'—'}</strong></div>{['share','etf','fund','investment_trust'].includes(h.type)&&<details className="holding-identifiers-disclosure"><summary>Units for daily valuation (optional)</summary><div className="editor-form-grid"><Field label="Quantity (if known)" id={`quantity-${h.id}`}><Input id={`quantity-${h.id}`} inputMode="decimal" value={h.details.quantity} onChange={e=>updateHolding(h.id,{details:{...h.details,quantity:e.target.value,priceDate:new Date().toISOString().slice(0,10)}})} placeholder="Units or shares" maxLength={24}/></Field><Field label="Units as at" id={`units-date-${h.id}`}><Input id={`units-date-${h.id}`} type="date" value={h.details.priceDate||draft.valuationDate} max={new Date().toISOString().slice(0,10)} onChange={e=>updateHolding(h.id,{details:{...h.details,priceDate:e.target.value}})}/></Field><p className="field-hint">Units and their date enable daily tracking. Without units, the recorded value is kept; no quantity is inferred.</p></div></details>}<DetailsComponent holding={h} onChange={details=>updateHolding(h.id,{details})}/></div>)}
 {draft.holdings.length>0&&<Button className="add-another" variant="outline" disabled={draft.holdings.length>=100} onClick={addHolding}><Plus/>Add another holding</Button>}
 <div className="allocation-review"><div className="allocation-heading"><strong>Account allocation</strong><span>{calculated?allocation.toFixed(2)+'%':'Check entries'}</span></div><Progress value={Math.min(100,allocation)} aria-label="Account allocation"/>{allocationError?<p className="allocation-warning">{allocationError}</p>:<><p className="field-hint">{initial.version?'In £ mode, holding value edits change the total by the same amount. Removing a holding also removes it from chart history; record sales or switches separately.':'Holdings allocate the starting account value. The total increases if they exceed it.'}</p><p><strong>Account total: {money(units(draft.value))}</strong></p><p>{money(calculated!.assigned)} assigned · {money(calculated!.remaining)} remaining</p>{calculated!.remaining>0&&<><Label className="remainder-label">What does the remaining balance represent?</Label><RadioGroup value={draft.remainder} onValueChange={v=>patch({remainder:v as AccountDraft['remainder']})} className="remainder-options"><div><RadioGroupItem id="unassigned" value="unassigned"/><Label htmlFor="unassigned">Holdings still to add</Label></div><div><RadioGroupItem id="remaining-cash" value="cash"/><Label htmlFor="remaining-cash">Uninvested cash</Label></div></RadioGroup><p className="field-hint">The total account value is counted once, including this balance.</p></>}{calculated!.remaining===0&&<p className="allocation-complete"><Check size={16}/>Your account is fully allocated.</p>}</>}</div></div>}
 {error&&<div className="editor-error" role="alert"><p>{error}</p>{error.includes('session expired')&&<a href="/" target="_blank" rel="noopener noreferrer">Sign in in a new tab, then retry here</a>}</div>}
 </div>
 {stage!=='category'&&<div className="editor-footer"><Button variant="ghost" disabled={busy} onClick={()=>{setError('');if(stage==='holdings')setStage('details');else if(!initial.version)setStage('category');else close();}}><ArrowLeft/>{stage==='holdings'?'Details':initial.version?'Cancel':'Categories'}</Button>{stage==='details'&&supportsHoldings(draft)?<Button onClick={next}>Next: holdings<ArrowRight/></Button>:<Button onClick={save} disabled={busy}>{busy?<LoaderCircle className="animate-spin"/>:<Check/>}{busy?'Saving…':'Save entry'}</Button>}</div>}
 </SheetContent></Sheet>{importOpen&&<CsvImport draft={draft} catalog={catalog} onClose={()=>setImportOpen(false)} onApply={updated=>{patch(updated);setImportOpen(false);}}/>}<AlertDialog open={discard} onOpenChange={setDiscard}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Discard your changes?</AlertDialogTitle><AlertDialogDescription>Your unsaved entries will be lost. Saved accounts will stay unchanged.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Keep editing</AlertDialogCancel><AlertDialogAction onClick={onClose}>Discard changes</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog></>;
}
