import FuturePage from '../future-page';
export const dynamic = 'force-dynamic';
export default function Page(){return <FuturePage title="Journal / Personal plan" description="A space for your own notes, goals and decisions."/>;}
