import Link from 'next/link';
import { Brand } from '../brand';
import Navigation from './navigation';

export default function FuturePage({title, description}:{title:string; description:string}) {
  return <div className="finance-app"><header className="finance-header"><Brand/><Navigation/></header>
    <main className="finance-main future-page"><span className="eyebrow">OWL WORKSPACE</span><h1>{title}</h1>
      <p>{description}</p><span className="future-label">Coming later</span><Link className="back-overview" href="/workspace">Back to overview</Link>
    </main></div>;
}
