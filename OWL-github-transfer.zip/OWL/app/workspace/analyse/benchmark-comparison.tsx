'use client';
import {useEffect,useRef,useState} from 'react';
import {CartesianGrid,Line,LineChart,ResponsiveContainer,Tooltip,XAxis,YAxis} from 'recharts';
import {RefreshCw} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {money} from '@/lib/finance/model';
import {comparisonRanges,UK_BENCHMARK,type ComparisonRange,type ComparisonResponse} from '@/lib/finance/comparison';

const percentage=(n:number|null)=>n===null?'—':`${n>=0?'+':''}${n.toFixed(2)}%`;
export default function BenchmarkComparison({revision}:{revision:string}){
 const [range,setRange]=useState<ComparisonRange>('1M'),[result,setResult]=useState<ComparisonResponse|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const abort=useRef<AbortController|null>(null);
 useEffect(()=>{abort.current?.abort();setResult(null);setBusy(false);setError('');return()=>abort.current?.abort();},[revision]);
 async function run(){
  abort.current?.abort();const controller=new AbortController();abort.current=controller;setBusy(true);setError('');setResult(null);
  try{const response=await fetch(`/api/market/comparison?country=GB&range=${range}`,{method:'POST',cache:'no-store',signal:controller.signal});const body=await response.json();if(!response.ok)throw new Error(body.error||'Comparison unavailable.');if(!controller.signal.aborted)setResult(body);}
  catch(e){if(!controller.signal.aborted)setError(e instanceof Error?e.message:'Unable to load comparison.');}
  finally{if(!controller.signal.aborted)setBusy(false);}
 }
 return <section className="benchmark-panel" aria-labelledby="benchmark-title">
  <div className="exposure-heading"><div><span className="eyebrow">HYPOTHETICAL COMPARISON</span><h3 id="benchmark-title">Today’s UK basket vs {UK_BENCHMARK.name}</h3></div><span className="benchmark-badge">Price return · GBP</span></div>
  <p>What if you had held today’s known UK company mix throughout this period? Today’s weights are used at the start, with no rebalancing. This is not your actual investment return.</p>
  <div className="exposure-toolbar"><div className="tracker-ranges" aria-label="Comparison period">{(Object.keys(comparisonRanges) as ComparisonRange[]).map(r=><button key={r} aria-pressed={range===r} disabled={busy} onClick={()=>{setRange(r);setResult(null);}}>{r}</button>)}</div><Button onClick={()=>void run()} disabled={busy}><RefreshCw size={15} className={busy?'animate-spin':''}/>{busy?'Fetching history…':'Run comparison'}</Button></div>
  <p className="exposure-caption">Runs only when requested. Saved prices are reused for up to six hours. No EODHD calls. Initial coverage: up to 20 London-listed companies with verified GBP prices.</p>
  {error&&<p role="alert" className="page-error">{error}</p>}
  {busy&&<p role="status">Checking the benchmark and company histories. First-time comparisons can take a little longer.</p>}
  {result&&<>
   <p className="benchmark-coverage">{result.coveragePercent.toFixed(1)}% of known UK exposure included · {money(result.includedPence)} of {money(result.knownUkPence)} · {result.included.length} companies</p>
   {result.unknownGeographyPence>0&&<p className="exposure-caption">A further {money(result.unknownGeographyPence)} of your overall investments has unclassified geography and could include UK exposure. Direct shares without classifications are also excluded.</p>}
   {result.messages.map(message=><p key={message} className="tracker-notice" role="status">{message}</p>)}
   {result.status==='ready'&&<><div className="benchmark-stats"><div><small>Hypothetical basket</small><strong>{percentage(result.basketReturnPercent)}</strong></div><div><small>{UK_BENCHMARK.name}</small><strong>{percentage(result.benchmarkReturnPercent)}</strong></div><div><small>Difference</small><strong>{result.differencePp===null?'—':`${result.differencePp>=0?'+':''}${result.differencePp.toFixed(2)} pp`}</strong></div></div>
   <p className="exposure-caption">Both start at 100 · {result.actualFrom} to {result.actualThrough} · {result.points.length} common closing dates</p>
   <div className="benchmark-chart" role="img" aria-label="Hypothetical UK basket and FTSE 100 price returns, both rebased to 100"><ResponsiveContainer width="100%" height="100%"><LineChart data={result.points} accessibilityLayer margin={{top:15,right:12,left:0,bottom:8}}><CartesianGrid stroke="#303c32" strokeDasharray="3 5" vertical={false}/><XAxis dataKey="date" tickFormatter={d=>new Date(d+'T12:00:00Z').toLocaleDateString('en-GB',{day:'numeric',month:'short'})} minTickGap={45} tick={{fill:'#a5b29e',fontSize:12}}/><YAxis domain={['auto','auto']} tick={{fill:'#a5b29e',fontSize:12}} width={48} tickFormatter={v=>Number(v).toFixed(0)}/><Tooltip formatter={(v)=>Number(v).toFixed(2)} contentStyle={{background:'#111914',border:'1px solid #526344',color:'#e6f1e0'}}/><Line type="linear" dataKey="basket" name="Hypothetical UK basket" stroke="#d4ef99" strokeWidth={2.5} dot={false} isAnimationActive={false}/><Line type="linear" dataKey="benchmark" name="FTSE 100" stroke="#79c4c1" strokeWidth={2} dot={false} isAnimationActive={false}/></LineChart></ResponsiveContainer></div>
   <div className="benchmark-legend"><span><i/>Hypothetical UK basket</span><span><i/>FTSE 100</span></div></>}
   {(result.included.length>0||result.excluded.length>0)&&<details className="exposure-detail"><summary>Included weights and excluded holdings</summary><div className="analysis-table-wrap"><table className="analysis-table"><thead><tr><th>Company</th><th>Held through / reason</th><th>Simulation weight</th><th>Price return</th></tr></thead><tbody>{result.included.map(m=><tr key={m.symbol}><td>{m.name}<small>{m.symbol}</small></td><td>{m.heldThrough.join(', ')}</td><td>{m.weightPercent.toFixed(2)}%</td><td>{percentage(m.returnPercent)}</td></tr>)}{result.excluded.map((m,i)=><tr key={`${m.symbol}-${i}`}><td>{m.name}<small>{m.symbol||'No identifier'}</small></td><td>{m.reason}</td><td>Excluded · {money(m.valuePence)}</td><td>—</td></tr>)}</tbody></table></div></details>}
   {result.points.length>0&&<details className="exposure-detail"><summary>Daily comparison values</summary><div className="analysis-table-wrap benchmark-daily"><table className="analysis-table"><thead><tr><th>Date</th><th>Hypothetical basket</th><th>FTSE 100</th></tr></thead><tbody>{result.points.map(p=><tr key={p.date}><td>{p.date}</td><td>{p.basket.toFixed(2)}</td><td>{p.benchmark.toFixed(2)}</td></tr>)}</tbody></table></div></details>}
   <p className="exposure-caption">Fund report dates used: {result.snapshotDates.join(', ')||'None available'}. Price source: {result.priceSource}. These snapshots may be newer than the simulated period.</p>
  </>}
  <details className="exposure-detail"><summary>How to interpret this comparison</summary><p>The FTSE 100 tracks large UK-listed companies; it may be a poor match for a small-company portfolio. Country follows the saved source’s company or exchange location, not UK revenue.</p><p>Both sides exclude dividends, fees and tax. Stock splits are accounted for. Companies with insufficient history are excluded for the whole run; included weights are rescaled to 100%. Common dates are used for both lines and missing closes are not invented.</p><p>Historical fund trades, gearing, discounts to NAV and your purchase dates are not reconstructed. Choosing today’s surviving holdings creates hindsight and survivorship bias. This is a way to explore the current mix, not evidence of the return your funds earned or a forecast.</p><p>For actual historical geographic performance we need dated ownership and fund-composition records. Saving those over time will improve future analysis, but reports still cannot reveal every trade between publication dates.</p><a href={UK_BENCHMARK.sourceUrl} target="_blank" rel="noreferrer">FTSE benchmark definitions</a></details>
 </section>;
}
