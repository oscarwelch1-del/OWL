'use client';
import {useEffect,useMemo,useState} from 'react';
import {PieChart,Pie,Cell,ResponsiveContainer,Tooltip} from 'recharts';
import {RefreshCw,ArrowLeft} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {money} from '@/lib/finance/model';
import {buildExposure,groups,continents,UNKNOWN,type ExposurePosition,type ExposureSnapshots} from '@/lib/finance/exposure';
import world from '@/lib/finance/world-map.json';
import './exposure.css';
import InsightsPanel from './insights-panel';
import OwnershipPanel from './ownership-panel';

const palette=['#d4ef99','#79c4c1','#a2adf0','#dbb37c','#c791b8','#e5c77a','#74ac8d','#bca2dd','#dfad99','#7eadd6','#b9c7a4'];
const pct=(n:number,total:number)=>total?`${(n/total*100).toFixed(1)}%`:'—';
const date=(s:string|null)=>s?new Date(s.length===10?s+'T12:00:00Z':s).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}):'Not supplied';
export default function ExposurePanel({positions,portfolioPence,refreshKey,stalePriceCount,unavailableCount,onOpen}:{stalePriceCount:number;unavailableCount:number;positions:ExposurePosition[];portfolioPence:number;refreshKey:string;onOpen:(id:string)=>void}){
 const [saved,setSaved]=useState<ExposureSnapshots|null>(null),[error,setError]=useState(''),[loading,setLoading]=useState(true),[refreshing,setRefreshing]=useState(false),[revision,setRevision]=useState(0);
 const [tab,setTab]=useState<'geography'|'sectors'>('geography');
 const [continent,setContinent]=useState<string|null>(null),[country,setCountry]=useState<string|null>(null),[sector,setSector]=useState<string|null>(null),[industry,setIndustry]=useState<string|null>(null),[visible,setVisible]=useState(30);
 const positionsKey=positions.map(p=>[p.id,p.symbol,p.type].join(':')).sort().join('|');
 useEffect(()=>{const abort=new AbortController();setLoading(true);setError('');
  const load=async()=>{
   try{
    const response=await fetch('/api/market/exposure',{cache:'no-store',signal:abort.signal});
    const first=await response.json();if(!response.ok)throw new Error(first.error||'Unable to load saved exposure.');
    if(abort.signal.aborted)return;setSaved(first as ExposureSnapshots);setLoading(false);
    if(!positions.length)return;
    setRefreshing(true);
    let refreshAfter=0;
    for(let i=0;i<8&&!abort.signal.aborted;i++){
     const query=refreshAfter?'?after='+refreshAfter:revision?'?refresh=1':'';
     const next=await fetch('/api/market/exposure'+query,{method:'POST',signal:abort.signal});
     const body=await next.json();if(!next.ok)throw new Error(body.error||'Unable to refresh EODHD coverage.');
     refreshAfter=body.refreshAfter||0;
     if(abort.signal.aborted)return;setSaved(body as ExposureSnapshots);
     if(!body.remaining||body.message)break;
    }
   }catch(e){if(!abort.signal.aborted)setError(e instanceof Error?e.message:'Unable to refresh EODHD coverage.');}
   finally{if(!abort.signal.aborted){setLoading(false);setRefreshing(false);}}
  };void load();
  return()=>abort.abort();
 },[revision,positionsKey]);
 const exposure=useMemo(()=>buildExposure(positions,saved?.snapshots||{},portfolioPence,Date.now(),saved?.classifications||{}),[positions,saved,portfolioPence]);
 const regions=useMemo(()=>groups(exposure.rows,'continent'),[exposure]);
 const sectors=useMemo(()=>groups(exposure.rows,'sector'),[exposure]);
 const selected=exposure.rows.filter(r=>tab==='geography'?(!continent||r.continent===continent)&&(!country||r.country===country):(!sector||r.sector===sector)&&(!industry||r.industry===industry));
 const slices=sector?groups(exposure.rows.filter(r=>r.sector===sector),'industry'):sectors;
 const selectedTotal=selected.reduce((s,r)=>s+r.valuePence,0);
 const classified=tab==='geography'?exposure.geographyClassifiedPence:exposure.sectorClassifiedPence;
 const chooseRegion=(name:string)=>{setContinent(name);setCountry(null);setVisible(30);};
 const chooseSector=(name:string)=>{setSector(name);setIndustry(null);setVisible(30);};
 const reset=()=>{setContinent(null);setCountry(null);setSector(null);setIndustry(null);setVisible(30);};
 return <section className="analysis-panel exposure-panel" aria-labelledby="exposure-title">
  <InsightsPanel positions={positions} rows={exposure.rows} total={exposure.totalPence} stalePriceCount={stalePriceCount} unavailableCount={unavailableCount} ready={!!saved} onOpen={onOpen}/>
  <div className="exposure-heading"><div><span className="eyebrow">LOOK THROUGH YOUR HOLDINGS</span><h2 id="exposure-title">Your portfolio, beneath the surface.</h2></div><Button variant="outline" disabled={loading||refreshing} onClick={()=>setRevision(r=>r+1)}><RefreshCw size={15} className={loading||refreshing?'animate-spin':''}/>{loading||refreshing?'Updating…':'Check EODHD coverage'}</Button></div>
  <div className="exposure-toolbar"><div className="tracker-metric-switch" aria-label="Exposure view"><button aria-pressed={tab==='geography'} onClick={()=>{setTab('geography');reset();}}>Geography</button><button aria-pressed={tab==='sectors'} onClick={()=>{setTab('sectors');reset();}}>Sectors & industries</button></div><span>{pct(classified,exposure.totalPence)} classified · {money(exposure.totalPence)} analysed</span></div>
  {error&&<p className="page-error" role="alert">{error} {saved?'Showing previously loaded data.':'Try reloading saved data.'}</p>}
  {saved?.message&&<p className="tracker-notice">{saved.message}</p>}
  {!!saved?.issues?.length&&<details className="exposure-detail"><summary>EODHD holdings checks · {saved.issues.length} unresolved</summary>{saved.issues.map(issue=><p key={issue.symbol}><strong>{issue.symbol}</strong>: {issue.message} <small>Checked {date(issue.checkedAt)}</small></p>)}</details>}
  {refreshing&&<p role="status">Checking EODHD for fund holdings and company classifications…</p>}
  {!saved&&loading?<p role="status">Loading your saved holdings…</p>:!saved?<p>Exposure is unavailable until saved data can be loaded.</p>:<>
  <div className="exposure-layout">
   <div className="exposure-visual">
    {tab==='geography'?<><svg className="exposure-map" viewBox="0 0 720 300" role="group" aria-label="Select a continent to explore reported country exposure">
     {continents.map(name=>{const value=regions.find(r=>r.name===name)?.valuePence||0;return <g key={name} role="button" tabIndex={0} aria-label={`${name}: ${pct(value,exposure.totalPence)} classified exposure`} aria-pressed={continent===name} onClick={()=>chooseRegion(name)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();chooseRegion(name);}}} className={continent===name?'selected':''} style={{fill:value?'#8daa62':'#303b34',opacity:continent&&continent!==name?0.45:1}}><title>{name}: {pct(value,exposure.totalPence)}</title>{world.filter(c=>c.continent===name).map(c=><path key={c.name} d={c.path}/>)}</g>;})}
    </svg><p className="exposure-caption">Select a continent on the map or below. Map: Natural Earth.</p></>:<><div className="exposure-donut" aria-label={sector?`Industries within ${sector}`:'Sector allocations'}>{exposure.totalPence>0?<ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={slices.map(s=>({...s,value:s.valuePence}))} dataKey="value" nameKey="name" innerRadius="58%" outerRadius="85%" paddingAngle={1} isAnimationActive={false} onClick={entry=>{if(!entry.name)return;if(sector)setIndustry(entry.name);else chooseSector(entry.name);}}>{slices.map((s,i)=><Cell key={s.name} fill={s.name===UNKNOWN?'#49554d':palette[i%palette.length]} stroke="#172019"/>)}</Pie><Tooltip formatter={(value)=>money(Number(value))} contentStyle={{background:'#111914',border:'1px solid #526344',color:'#e6f1e0'}} itemStyle={{color:'#e6f1e0'}}/></PieChart></ResponsiveContainer>:<p>No investments to analyse yet.</p>}</div><p className="exposure-caption">{sector?`Industries within ${sector}.`:'Select a sector to see its industries.'} Buttons provide the same controls as the chart.</p></>}
   </div>
   <div className="exposure-breakdown"><h3>{tab==='geography'?'Reported country exposure':sector?`${sector} · industries`:'Sector allocation'}</h3><p>Percentages of your total analysed investments.</p>
    {(tab==='geography'?[...continents.map(name=>({name,valuePence:regions.find(r=>r.name===name)?.valuePence||0})),{name:UNKNOWN,valuePence:regions.find(r=>r.name===UNKNOWN)?.valuePence||0}]:slices).map((item,i)=><button key={item.name} className="exposure-allocation" aria-pressed={tab==='geography'?continent===item.name:sector?industry===item.name:sector===item.name} onClick={()=>{if(tab==='geography')chooseRegion(item.name);else if(sector)setIndustry(item.name);else chooseSector(item.name);}}><span><i style={{background:item.name===UNKNOWN?'#49554d':palette[i%palette.length]}}/>{item.name}</span><strong>{pct(item.valuePence,exposure.totalPence)}</strong><small>{money(item.valuePence)}</small></button>)}
   </div>
  </div>
  <p className="exposure-note">{tab==='geography'?'Company country comes from EODHD registration where available; fund constituents use the provider’s reported country. This is not revenue exposure.':'Sectors and industries use EODHD fields where available.'} Unclassified includes missing data, undisclosed fund holdings, cash and unassigned balances. Partial lists keep their original weights.</p>
  {exposure.reconciliationWarning&&<p className="tracker-notice">Holding values exceed the tracker total. The breakdown uses the sum of holdings; refresh prices to reconcile the two views.</p>}
  {(continent||sector)&&<div className="exposure-selection"><Button variant="ghost" onClick={reset}><ArrowLeft size={15}/>All investments</Button><h3>{country||continent||industry||sector}</h3><span>{money(selectedTotal)} · {pct(selectedTotal,exposure.totalPence)} of investments</span></div>}
  {tab==='geography'&&continent&&<div className="exposure-chips"><button aria-pressed={!country} onClick={()=>{setCountry(null);}}>All countries</button>{groups(exposure.rows.filter(r=>r.continent===continent),'country').map(c=><button key={c.name} aria-pressed={country===c.name} onClick={()=>{setCountry(c.name);setVisible(30);}}>{c.name} · {pct(c.valuePence,exposure.totalPence)}</button>)}</div>}
  <details className="exposure-detail" open={!!continent||!!sector}><summary>{continent||sector?'Contributing holdings':'Explore contributing holdings'} · {selected.length} allocations</summary>
  {selected.length?<><div className="analysis-table-wrap"><table className="analysis-table exposure-table"><thead><tr><th>Company / allocation</th><th>Held through</th><th>Classification</th><th className="analysis-right">Attributed value</th><th>Data source</th></tr></thead><tbody>{[...selected].sort((a,b)=>b.valuePence-a.valuePence).slice(0,visible).map((r,i)=><tr key={`${r.holdingId}-${r.symbol}-${i}`}><td><strong>{r.name}</strong><small>{r.symbol||r.reason||'Identifier unavailable'}</small></td><td>{r.holdingId?<button className="tracker-holding-link" onClick={()=>onOpen(r.holdingId)}>{r.holdingName}</button>:r.holdingName}<small>{r.accountName}</small></td><td>{r.country}<small>{r.sector} · {r.industry}</small><small>{r.basis}</small></td><td className="analysis-right">{money(r.valuePence)}<small>{pct(r.valuePence,exposure.totalPence)}</small></td><td>{r.source}<small>Holdings date: {date(r.asOf)}</small><small>Retrieved: {date(r.retrievedAt)}{r.stale?' · older snapshot':''}</small></td></tr>)}</tbody></table></div>{selected.length>visible&&<Button variant="outline" onClick={()=>setVisible(v=>v+50)}>Show more allocations</Button>}</>:<p>No classified holdings are available for this selection. Missing classifications remain in Unclassified.</p>}
  </details>
  <OwnershipPanel rows={exposure.rows} total={exposure.totalPence} positions={positions} snapshots={saved.snapshots} onOpen={onOpen}/>
  </>}
 </section>;
}
