'use client';
import {useMemo} from 'react';
import {money} from '@/lib/finance/model';
import {portfolioInsights} from '@/lib/finance/insights';
import type {ExposurePosition,ExposureRow} from '@/lib/finance/exposure';
import './insights.css';

export default function InsightsPanel({positions,rows,total,stalePriceCount,unavailableCount,ready,onOpen}:{positions:ExposurePosition[];rows:ExposureRow[];total:number;stalePriceCount:number;unavailableCount:number;ready:boolean;onOpen:(id:string)=>void}){
 const data=useMemo(()=>portfolioInsights(positions,rows,total),[positions,rows,total]);
 const pct=(value:number)=>total>0?`${(value/total*100).toFixed(1)}%`:'—';
 const exposure=(value:number|undefined)=>ready&&value!==undefined?pct(value):'—';
 return <section className="insights-panel" aria-labelledby="insights-title">
  <div className="exposure-heading"><div><h2 id="insights-title">Portfolio insights</h2><p>Across your investment accounts and pensions · {money(total)}</p></div><span>Calculated from your holdings</span></div>
  {!total?<p>Add investments to see portfolio insights.</p>:<>
  <div className="insights-grid">
   <article><span>Largest direct holding</span><strong>{data.largest?pct(data.largest.valuePence):'—'}</strong>{data.largest?<button className="tracker-holding-link" onClick={()=>onOpen(data.largest!.id)}>{data.largest.name}</button>:<p>No invested positions</p>}<small>{data.largest?`${data.largest.accountName} · ${money(data.largest.valuePence)}`:'Excludes cash'} · one account position</small></article>
   <article><span>Largest underlying exposure</span><strong>{exposure(data.company?.valuePence)}</strong><p>{ready?data.company?.name||'No identified holdings yet':'Loading coverage…'}</p><small>Direct shares + reported fund holdings</small></article>
   <article><span>Top 10 concentration</span><strong>{exposure(data.topTen)}</strong><p>{ready?money(data.topTen):'Loading coverage…'}</p><small>Up to ten identified securities / full portfolio</small></article>
   <article><span>Largest country exposure</span><strong>{exposure(data.country?.valuePence)}</strong><p>{ready?data.country?.name||'Not classified':'Loading coverage…'}</p><small>Company registration / reported country</small></article>
   <article><span>Largest sector exposure</span><strong>{exposure(data.sector?.valuePence)}</strong><p>{ready?data.sector?.name||'Not classified':'Loading coverage…'}</p><small>Reported classifications</small></article>
   <article><span>Recorded cash</span><strong>{pct(data.cash)}</strong><p>{money(data.cash)}</p><small>Explicit cash holdings; excludes unassigned balances and cash inside funds</small></article>
   <article><span>Identified company / security holdings</span><strong>{ready?data.count.toLocaleString('en-GB'):'—'}</strong><p>{ready?`${pct(data.identified)} of portfolio linked to identifiers`:'Loading coverage…'}</p><small>Share classes counted separately; includes any reported fund or bond constituents</small></article>
   <article><span>Prices needing attention</span><strong>{stalePriceCount}</strong><p>Stale market prices</p><small>{unavailableCount} additional holding{unavailableCount===1?'':'s'} with unavailable prices, using recorded values</small><a href="#pricing-coverage">Review pricing coverage</a></article>
  </div>
  </>}
 </section>;
}
