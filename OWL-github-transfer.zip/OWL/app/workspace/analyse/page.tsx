'use client';
export const dynamic = 'force-dynamic';
import {useCallback,useEffect,useMemo,useRef,useState} from 'react';
import Link from 'next/link';
import {ArrowUpRight,ChartNoAxesCombined,ChevronDown,LockKeyhole,RefreshCw} from 'lucide-react';
import {CartesianGrid,Line,LineChart,ResponsiveContainer,Tooltip,XAxis,YAxis} from 'recharts';
import {Button} from '@/components/ui/button';
import {Skeleton} from '@/components/ui/skeleton';
import {money,type Account,type Holding} from '@/lib/finance/model';
import {dayOf,shiftDay,dailyPercentage,type TrackingResponse} from '@/lib/finance/tracker';
import Navigation from '../navigation';
import HoldingDetail from '../holding-detail';
import {Brand} from '../../brand';
import ExposurePanel from './exposure-panel';

type Point=TrackingResponse['points'][number];
const ranges=[['1W',7],['1M',31],['3M',93],['1Y',366],['5Y',1827],['All',Infinity]] as const;
const date=(day:string)=>new Date(day+'T12:00:00Z').toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'});
const shortDate=(day:string)=>new Date(day+'T12:00:00Z').toLocaleDateString('en-GB',{day:'numeric',month:'short',timeZone:'UTC'});
const compact=(pence:number)=>new Intl.NumberFormat('en-GB',{style:'currency',currency:'GBP',notation:'compact',maximumFractionDigits:1}).format(pence/100);
const signed=(pence:number)=>`${pence>0?'+':''}${money(pence)}`;
async function request<T>(path:string,method='GET',signal?:AbortSignal):Promise<T>{
 const response=await fetch(path,{method,cache:'no-store',signal});
 const data=await response.json();if(!response.ok)throw new Error(data.error||'Unable to load your portfolio.');return data;
}
function chartBars(points:Point[]){
 const interval=points.length<=124?'Daily':points.length<=730?'Weekly':'Monthly';
 if(interval==='Daily')return {bars:points,interval};
 const groups=new Map<string,Point>();
 for(const point of points){const key=interval==='Monthly'?point.date.slice(0,7):shiftDay(point.date,-((new Date(point.date+'T12:00Z').getUTCDay()+6)%7));groups.set(key,point);}
 const retained=new Map([...groups.values(),...points.filter(p=>p.accountChanges||p.accountCount===0||Object.keys(p.anomalies||{}).length)].map(p=>[p.date,p]));return {bars:[...retained.values()].sort((a,b)=>a.date.localeCompare(b.date)),interval};
}
function ChartTooltip({active,payload,metric}:{active?:boolean;payload?:{payload:Point}[];metric:'portfolioPence'|'netPence'}){
 const point=payload?.[0]?.payload;if(!active||!point)return null;
 return <div className="tracker-tooltip"><span>{date(point.date)}{point.provisional?' · provisional':''}</span><strong>{money(point[metric])}</strong>{metric==='portfolioPence'&&<><small>Market priced: {money(point.marketPence)}</small><small>Recorded values: {money(point.recordedPence)}</small></>}{point.carriedCount>0&&<small>{point.carriedCount} holding{point.carriedCount===1?'':'s'} using an earlier close</small>}{point.unavailableCount>0&&<small>{point.unavailableCount} holding{point.unavailableCount===1?'':'s'} using recorded values</small>}{point.adjustments?.map(label=><small key={label}>{label}</small>)}{point.stale&&<small>Awaiting a newer close</small>}{point.anomalies?.[metric]!==undefined&&<small>Unexplained move: {point.anomalies[metric]!.toFixed(1)}% — check valuation</small>}</div>;
}

export default function Page(){
 const [data,setData]=useState<TrackingResponse|null>(null),[accounts,setAccounts]=useState<Account[]>([]);
 const [error,setError]=useState(''),[busy,setBusy]=useState(true),[range,setRange]=useState('1M');
 const [metric,setMetric]=useState<'portfolioPence'|'netPence'>('portfolioPence');
 const [selection,setSelection]=useState<{holding:Holding;account:Account}|null>(null);
 const running=useRef(false);const abort=useRef<AbortController|null>(null);
 const load=useCallback(async()=>{
  if(running.current)return;running.current=true;setBusy(true);setError('');
  const controller=new AbortController();abort.current=controller;
  try{
   const [initial,finance]=await Promise.all([request<TrackingResponse>('/api/finance/tracker','GET',controller.signal),request<{accounts:Account[]}>('/api/finance/accounts','GET',controller.signal)]);
   if(controller.signal.aborted)return;
   setData(initial);setAccounts(finance.accounts);
   for(let i=0;i<12;i++){
    const updated=await request<TrackingResponse>('/api/finance/tracker','POST',controller.signal);if(controller.signal.aborted)return;setData(updated);
    if(updated.refreshing){await new Promise(resolve=>setTimeout(resolve,1500));continue;}
    if(!updated.pending)break;
   }
  }catch(e){if(!controller.signal.aborted)setError(e instanceof Error?e.message:'Unable to update your portfolio.');}
  finally{if(abort.current===controller){running.current=false;if(!controller.signal.aborted)setBusy(false);}}
 },[]);
 useEffect(()=>{
  void load();const timer=setInterval(()=>{if(document.visibilityState==='visible')void load();},600000);
  const visible=()=>{if(document.visibilityState==='visible')void load();};document.addEventListener('visibilitychange',visible);
  return()=>{abort.current?.abort();clearInterval(timer);document.removeEventListener('visibilitychange',visible);running.current=false;};
 },[load]);
 const points=useMemo(()=>{const raw=data?.points||[];const first=raw.findIndex(p=>(metric==='portfolioPence'?p.investmentAccountCount:p.accountCount)!==0);const all=first<0?[]:raw.slice(first);const days=ranges.find(r=>r[0]===range)![1];const end=all.at(-1)?.date;if(!end||!Number.isFinite(days))return all;return all.filter(p=>p.date>=shiftDay(end,1-days));},[data,range,metric]);
 const {bars:sampled,interval}=useMemo(()=>chartBars(points),[points]);
 const bars=useMemo(()=>{let segment=0;return sampled.map((point,i)=>{const hasValue=(metric==='portfolioPence'?point.investmentAccountCount:point.accountCount)!==0;if(i&&(point.accountChanges||!hasValue))segment++;return {...point,segment,plotValue:hasValue?point[metric]:null};});},[sampled,metric]);
 const segments=[...new Set(bars.map(p=>p.segment))];
 const chartDomain=useMemo<[number,number]|['auto','auto']>(()=>{
  const values=bars.map(point=>point.plotValue).filter((value):value is number=>Number.isFinite(value));
  if(!values.length)return ['auto','auto'];
  const low=Math.min(...values),high=Math.max(...values),spread=high-low;
  // The previous zero-based axis made normal daily movements look flat when
  // the portfolio was large. Keep a small, honest margin around the observed
  // values so price changes remain visible without exaggerating them.
  const padding=Math.max(spread*0.12,Math.abs(high||low)*0.002,100);
  return [metric==='netPence'?low-padding:Math.max(0,low-padding),high+padding];
 },[bars,metric]);
 const latest=data?.points.at(-1);const first=points[0],last=points.at(-1);
 const previousDay=data&&latest?data.points.at(-2):undefined;
 const dailyPercent=latest?.provisional?null:dailyPercentage(latest,previousDay,metric);
 const hasAdjustment=points.some(point=>point.accountChanges);

 const change=!hasAdjustment&&first&&last&&points.length>1?last[metric]-first[metric]:null;
 const value=metric==='portfolioPence'?(data?.currentPortfolioPence??latest?.portfolioPence??data?.recordedPortfolioPence):latest?.netPence;
 const valuationAlerts=points.filter(p=>p.anomalies?.[metric]!==undefined);
 const accountHoldings=useMemo(()=>new Map(accounts.flatMap(a=>a.holdings).map(h=>[h.id,h])),[accounts]);
 const holdings=[...(data?.holdings||[])].sort((a,b)=>Number(b.status==='unavailable')-Number(a.status==='unavailable')||b.valuePence-a.valuePence);
 const marketCount=holdings.filter(h=>h.status==='priced'||h.status==='carried').length;
 const reviewCount=holdings.filter(h=>h.status==='unavailable').length;
 function openHolding(id:string){for(const account of accounts){const holding=account.holdings.find(h=>h.id===id);if(holding){setSelection({account,holding});break;}}}

 return <div className="finance-app"><header className="finance-header"><Brand/><Navigation/><div className="header-account"><span className="private-label"><LockKeyhole size={14}/>Private</span><span className="user-avatar">O</span></div></header>
 <main className="finance-main analysis-main"><div className="finance-title-row"><div><span className="eyebrow">ANALYSE / DAILY TRACKING</span><h1>Your portfolio, day by day<span>.</span></h1><p>A growing record of your investments, valued in pounds.</p></div><Button variant="outline" onClick={()=>void load()} disabled={busy}><RefreshCw size={16} className={busy?'animate-spin':''}/>{busy?'Updating…':'Update prices'}</Button></div>
 {error&&<div className="page-error" role="alert"><p>{error}</p><Button variant="outline" onClick={()=>void load()} disabled={busy}>Try again</Button>{/session|sign.in/i.test(error)&&<Link href="/">Sign in again</Link>}</div>}
 {!data&&busy?<div className="analysis-loading"><Skeleton className="h-[460px] w-full"/><Skeleton className="h-24 w-full"/></div>:data&&<>
 <section className="analysis-panel tracker-panel" aria-label="Portfolio history"><div className="tracker-topline"><div className="tracker-metric-switch" aria-label="Chart value"><button aria-pressed={metric==='portfolioPence'} onClick={()=>setMetric('portfolioPence')}>Investments</button><button aria-pressed={metric==='netPence'} onClick={()=>setMetric('netPence')}>Net worth</button></div><span className="tracker-currency">GBP · {latest?'Daily valuations':'Tracking started'}</span></div>
 <div className="tracker-headline"><div><span className="tracker-value-label">{latest?`Valuation calculated for ${date(latest.date)}${latest.provisional?' · today may update':''}`:metric==='portfolioPence'?'Recorded starting value':'Awaiting the first daily valuation'}</span><strong>{value==null?'—':money(value)}</strong><p className="valuation-price-date">{data.oldestPriceDate?`Underlying market closes: ${date(data.oldestPriceDate)}${data.newestPriceDate!==data.oldestPriceDate&&data.newestPriceDate?` – ${date(data.newestPriceDate)}`:''}`:'Using recorded values until quote units and prices are verified'}</p><p>{hasAdjustment?'Holdings changed during this period; a comparable return is unavailable.':change!=null&&!valuationAlerts.length?<><span className={change<0?'tracker-negative':'tracker-positive'}>{signed(change)}</span> change in value over this period</>:latest?'One daily valuation saved. The history grows from here.':`Tracking from ${date(dayOf(Date.parse(data.startedAt)))}`}{dailyPercent!==null&&<><br/><span className={dailyPercent<0?'tracker-negative':'tracker-positive'}>{dailyPercent>=0?'+':''}{dailyPercent.toFixed(2)}%</span> on {latest?date(latest.date):'the latest day'}</>}</p></div><div className="tracker-ranges" aria-label="Chart period">{ranges.map(([label])=><button key={label} aria-pressed={range===label} onClick={()=>setRange(label)}>{label}</button>)}</div></div>
 {bars.length?<div className="tracker-chart" role="img" aria-label={`${interval} ${metric==='portfolioPence'?'investment portfolio':'net worth'} values in GBP from ${date(points[0].date)} to ${date(points.at(-1)!.date)}. Exact daily values are in the table below.`}><ResponsiveContainer width="100%" height="100%"><LineChart data={bars} margin={{top:35,right:35,bottom:6,left:5}} accessibilityLayer><CartesianGrid stroke="#303a32" strokeDasharray="3 5" vertical={false}/><XAxis dataKey="date" tickFormatter={shortDate} minTickGap={44} tick={{fill:'#9baa9b',fontSize:11}} tickLine={false} axisLine={false} dy={8}/><YAxis tickFormatter={compact} tick={{fill:'#9baa9b',fontSize:11}} width={68} tickLine={false} axisLine={false} domain={chartDomain}/><Tooltip content={<ChartTooltip metric={metric}/>} cursor={{fill:'#d4ef9910'}}/>{segments.map(segment=><Line key={segment} type="linear" dataKey={p=>p.segment===segment?p.plotValue:null} stroke="#d4ef99" strokeWidth={2.5} dot={bars.length<=31?{r:3,fill:'#d4ef99',strokeWidth:0}:false} activeDot={{r:5}} isAnimationActive={false} connectNulls={false}/>)}</LineChart></ResponsiveContainer></div>:<div className="tracker-first-day"><ChartNoAxesCombined size={29}/><h2>Your history starts here.</h2><p>The first daily value is saved when a completed market close is available. Future visits fill in missed days from your saved holdings and available closing prices.</p>{!accounts.length&&<Link href="/workspace">Add or import your first portfolio <ArrowUpRight size={15}/></Link>}</div>}
 <div className="tracker-chart-footer"><div className="tracker-legend"><span><i/>{metric==='portfolioPence'?'Total investment value':'Net worth'}</span></div><span>{interval==='Daily'?'One value per calendar day':`${interval} observations · last daily value in each period`}</span></div>
 <p className="tracker-footnote">{metric==='portfolioPence'?'Investment accounts and defined-contribution pensions. ':'Assets less debt. '}The calculation date is separate from the dates of the underlying market closes. Blank periods have no accounts to value; account changes break the line. Value changes include money added, withdrawals and account edits. Daily percentages are withheld when entries changed or prices are missing or stale. Dividends and interest are included only when recorded in your balances.</p></section>

 {valuationAlerts.length>0&&<div className="page-error" role="alert"><strong>Check the valuation: unexplained daily movement</strong>{valuationAlerts.map(p=><p key={p.date}>{date(p.date)}: {p.anomalies![metric]!.toFixed(1)}% without a recorded account or holdings adjustment. This exceeds the {data.anomalyThresholdPercent||20}% alert threshold; it is not a verified investment return.</p>)}</div>}
 {latest?.stale&&<div className="tracker-notice" role="status"><strong>Prices need refreshing</strong><p>The latest available closes are older than the expected completed weekday session. The flat line uses carried-forward prices.</p></div>}

 <div className="tracker-status-row"><span><i className={reviewCount?'tracker-status-amber':'tracker-status-green'}/>{marketCount} holding{marketCount===1?'':'s'} linked to closing prices{reviewCount?` · ${reviewCount} need attention`:''}</span><span>{busy?'Checking saved prices…':data.lastRefresh?`Last completed check ${new Date(data.lastRefresh).toLocaleString('en-GB',{dateStyle:'medium',timeStyle:'short',timeZone:'Europe/London'})}`:'Ready to update'} · catches up when OWL is open</span></div>
 {!data.connection&&<div className="tracker-notice"><strong>Connect EODHD for market data.</strong><p>Add a ticker and exchange to each holding, then connect EODHD to update closing prices, fund holdings and exposure.</p></div>}
 {data.messages.length>0&&<div className="tracker-notice" role="status">{data.messages.map(message=><p key={message}>{message}</p>)}</div>}
 <details id="pricing-coverage" className="analysis-panel tracker-details"><summary><span><strong>Pricing coverage</strong><small>{reviewCount?`${reviewCount} holding${reviewCount===1?'':'s'} using recorded values`:'See the source and date behind each holding'}</small></span><ChevronDown size={18}/></summary>{holdings.length?<div className="analysis-table-wrap"><table className="analysis-table tracker-table"><thead><tr><th>Holding</th><th>Pricing</th><th>Price date</th><th className="analysis-right">Latest available value</th></tr></thead><tbody>{holdings.map(h=><tr key={h.id}><td><button className="tracker-holding-link" onClick={()=>openHolding(h.id)}>{h.name}<ArrowUpRight size={13}/></button><small>{h.accountName}{h.symbol?` · ${h.symbol}`:''}</small></td><td><span className={`tracker-tag tracker-tag-${h.status}`}>{h.status==='priced'?'Closing price':h.status==='carried'?'Earlier close':h.status==='manual'?'Manual':'Needs attention'}</span><small>{h.reason}</small>{h.source!=='manual'&&<small>Source: {h.source==='yahoo'?'Legacy Yahoo history · awaiting EODHD refresh':'EODHD'}</small>}{h.fxDate&&<small>FX: {date(h.fxDate)}</small>}</td><td>{h.priceDate?date(h.priceDate):'—'}</td><td className="analysis-right">{money(h.valuePence)}</td></tr>)}</tbody></table></div>:<p className="analysis-muted">Import a portfolio to see its holdings here.</p>}<Link className="tracker-overview-link" href="/workspace">Manage accounts and quantities <ArrowUpRight size={14}/></Link></details>
 {points.length>0&&<details className="analysis-panel tracker-details"><summary><span><strong>Daily values</strong><small>{points.length} recorded day{points.length===1?'':'s'} in this period</small></span><ChevronDown size={18}/></summary><div className="analysis-table-wrap tracker-daily-table"><table className="analysis-table"><thead><tr><th>Date</th><th className="analysis-right">Investments</th><th className="analysis-right">Day change</th><th className="analysis-right">Net worth</th><th>Record status</th></tr></thead><tbody>{[...points].reverse().map(p=>{const index=data.points.findIndex(row=>row.date===p.date);const pct=p.provisional?null:dailyPercentage(p,index>0?data.points[index-1]:undefined);return <tr key={p.date}><td>{date(p.date)}</td><td className="analysis-right">{money(p.portfolioPence)}</td><td className={`analysis-right ${pct!==null&&pct<0?'tracker-negative':pct!==null?'tracker-positive':''}`}>{pct===null?'—':`${pct>=0?'+':''}${pct.toFixed(2)}%`}</td><td className="analysis-right">{money(p.netPence)}</td><td>{p.accountChanges?(p.adjustments?.join('; ')||'Account adjustment — return unavailable'):p.anomalies?.[metric]!==undefined?'Unexplained move — review valuation':p.stale?'Awaiting a newer close':p.provisional?'Today · provisional':p.unavailableCount?'Includes recorded holding values':p.carriedCount?'Includes earlier closes':'Daily valuation'}</td></tr>})}</tbody></table></div></details>}
 <p className="tracker-source">Daily closing prices, GBP exchange rates and stock splits come from EODHD. Saved Yahoo history is replaced when EODHD verifies the same range. Prices are checked while OWL is open; unavailable values keep their last recorded date. Tracking starts when OWL first records your portfolio; earlier performance is not reconstructed.</p>
 </>}
 {data&&<ExposurePanel stalePriceCount={data.holdings.filter(h=>h.stale&&h.status!=='unavailable').length} unavailableCount={reviewCount} positions={data.holdings.map(h=>({id:h.id,name:h.name,accountName:h.accountName,valuePence:h.valuePence,symbol:h.symbol,isin:accountHoldings.get(h.id)?.isin,type:accountHoldings.get(h.id)?.type||'other'}))} portfolioPence={data.currentPortfolioPence??data.recordedPortfolioPence} refreshKey={`${data.lastRefresh||''}:${selection?.holding.id||''}`} onOpen={openHolding}/>}
 <footer className="finance-footer"><span><LockKeyhole size={13}/>Your private workspace</span><span>OWL · Portfolio tracking</span></footer></main>
 {selection&&<HoldingDetail {...selection} onClose={()=>{setSelection(null);void load();}}/>}</div>;
}
