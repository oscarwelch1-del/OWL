import FuturePage from '../future-page';
export const dynamic = 'force-dynamic';
export default function Page(){return <FuturePage title="Sandbox" description="A space to explore hypothetical scenarios and their possible effects."/>;}
