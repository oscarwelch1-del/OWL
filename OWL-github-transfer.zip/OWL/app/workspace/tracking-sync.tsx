'use client';
import {useEffect} from 'react';

// The server owns the daily quota and refresh lease, including across tabs.
export default function TrackingSync(){
 useEffect(()=>{
  const controller=new AbortController();let busy=false;
  async function update(){
   if(busy||document.visibilityState==='hidden')return;
   busy=true;
   try{for(let i=0;i<4;i++){const response=await fetch('/api/finance/tracker',{method:'POST',signal:controller.signal});if(!response.ok)break;const data=await response.json();if(!data.pending||data.refreshing)break;}}
   catch{/* Analyse exposes errors without interrupting account entry. */}
   finally{busy=false;}
  }
  void update();const timer=setInterval(()=>void update(),600000);
  const onVisible=()=>void update();document.addEventListener('visibilitychange',onVisible);
  return()=>{controller.abort();clearInterval(timer);document.removeEventListener('visibilitychange',onVisible);};
 },[]);
 return null;
}
