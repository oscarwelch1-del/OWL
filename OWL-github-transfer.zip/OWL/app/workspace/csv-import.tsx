'use client';
import { useEffect, useRef, useState } from 'react';
import { Check, LoaderCircle, Upload } from 'lucide-react';
import { Dialog,DialogContent,DialogHeader,DialogTitle,DialogDescription,DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Table,TableHeader,TableRow,TableHead,TableBody,TableCell } from '@/components/ui/table';
import { parseAjBell,automaticRows,automaticMatch,finishAutomaticImport,portfolioKind,type ImportPreview,type ReviewedRow } from '@/lib/finance/aj-bell';
import { money,holdingTypes,kinds,validateAccount,type AccountDraft,type HoldingDraft,type InstrumentSearchResult } from '@/lib/finance/model';

type Props={draft:AccountDraft;catalog:HoldingDraft[];createPortfolio?:boolean;existingNames?:string[];onClose:()=>void;onApply:(draft:AccountDraft)=>void|Promise<void>};
export default function CsvImport({draft,catalog,createPortfolio=false,existingNames=[],onClose,onApply}:Props) {
  const [name,setName]=useState(draft.name);const [raw,setRaw]=useState('');
  const [preview,setPreview]=useState<ImportPreview|null>(null);const [rows,setRows]=useState<ReviewedRow[]>([]);
  const [error,setError]=useState('');const [busy,setBusy]=useState(false);const [saving,setSaving]=useState(false);const [useTotal,setUseTotal]=useState(false);
  const controller=useRef<AbortController|null>(null);const generation=useRef(0);
  useEffect(()=>()=>{generation.current++;controller.current?.abort();},[]);
  function close(){if(saving)return;generation.current++;controller.current?.abort();onClose();}
  async function inspect(text=raw){
    const current=++generation.current;controller.current?.abort();setError('');setUseTotal(false);
    let parsed:ImportPreview;
    try{parsed=parseAjBell(text);}catch(e){setPreview(null);setRows([]);setBusy(false);setError(e instanceof Error?e.message:'Unable to read the CSV.');return;}
    const prepared=automaticRows(parsed,draft,catalog);setPreview(parsed);setRows(prepared);setBusy(true);
    const control=new AbortController();controller.current=control;
    const timeout=setTimeout(()=>control.abort(),30000);
    // Enrichment is optional and bounded. The statement remains importable if
    // the lookup is unavailable, ambiguous, or has no coverage for this asset.
    const work=prepared.filter(r=>(!r.match||r.type==='other')&&r.row.type==='other'&&r.row.exchange&&(r.row.isin||r.row.ticker)&&!r.row.errors.length&&!r.row.duplicate).slice(0,20);
    try{
      for(let i=0;i<work.length&&!control.signal.aborted;i+=4){
        await Promise.all(work.slice(i,i+4).map(async review=>{
          const row=review.row;
          try{
            let matched=review;
            for(const identifier of [row.isin,row.ticker].filter((value,index,list)=>value&&list.indexOf(value)===index)){
              const response=await fetch(`/api/instruments/search?q=${encodeURIComponent(identifier)}&exchange=${encodeURIComponent(row.exchange)}`,{cache:'no-store',signal:control.signal});
              if(!response.ok)continue;
              const data=await response.json();
              if(generation.current!==current||control.signal.aborted)return;
              matched=automaticMatch(review,Array.isArray(data.results)?data.results as InstrumentSearchResult[]:[]);
              if(matched.match)break;
            }
            setRows(previous=>previous.map(r=>r.row.line===row.line?matched:r));
          }catch{/* Leave the source identifiers and values intact. */}
        }));
      }
    }finally{clearTimeout(timeout);if(generation.current===current)setBusy(false);}
  }
  async function upload(file:File|undefined){
    if(!file)return;const current=++generation.current;controller.current?.abort();setBusy(true);setError('');
    if(file.size>1_000_000){setPreview(null);setRows([]);setError('Use a CSV smaller than 1 MB.');setBusy(false);return;}
    try{const text=await file.text();if(generation.current!==current)return;setRaw(text);await inspect(text);}
    catch{if(generation.current===current){setError('Unable to read that file. Try pasting the contents.');setBusy(false);}}
  }
  async function apply(){
    try{
      if(createPortfolio&&existingNames.some(n=>n.trim().toLowerCase()===name.trim().toLowerCase()))throw new Error('That portfolio name already exists. Use another name, or import from the existing portfolio’s editor to update it.');
      if(!preview)return;
      const updated=finishAutomaticImport(draft,preview,rows,name,createPortfolio,useTotal);
      setError('');setSaving(true);
      await onApply(createPortfolio?validateAccount(updated):updated);
    }catch(e){setError(e instanceof Error?e.message:'Unable to import. Your file and name are still here.');setSaving(false);}
  }
  const invalid=rows.some(r=>r.row.errors.length||r.row.duplicate)||rows.length>100;
  const updates=rows.filter(r=>r.targetId).length;const unknown=rows.filter(r=>r.type==='other').length;
  const detected=preview?portfolioKind(preview.portfolio):'';
  const kindLabel=detected==='portfolio'?'Account type not supplied':[...kinds.investment,...kinds.pension].find(k=>k.id===detected)?.label;
  return <Dialog open onOpenChange={open=>{if(!open)close();}}><DialogContent className="csv-dialog" onEscapeKeyDown={e=>{if(saving)e.preventDefault();}} onInteractOutside={e=>{if(saving)e.preventDefault();}}>
    <DialogHeader><DialogTitle>{createPortfolio?'Import a portfolio':'Import AJ Bell holdings'}</DialogTitle><DialogDescription>{createPortfolio?'Give it a name and add your CSV. The details will fill themselves in.':draft.name+' · Review the statement before applying its holdings.'}</DialogDescription></DialogHeader>
    <div className="csv-scroll">
      <div className="csv-inputs"><Label htmlFor="import-portfolio-name">What would you like to call this portfolio?</Label><Input id="import-portfolio-name" value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. My long-term investments" maxLength={100} disabled={saving}/></div>
      {!preview?<div className="csv-inputs csv-upload-section"><Label htmlFor="aj-bell-file">AJ Bell portfolio CSV</Label><Input id="aj-bell-file" type="file" accept=".csv,text/csv" disabled={busy||saving} onChange={e=>void upload(e.target.files?.[0])}/><details className="csv-paste-option"><summary>Or paste the CSV</summary><Label className="sr-only" htmlFor="aj-bell-paste">CSV contents</Label><Textarea id="aj-bell-paste" rows={8} value={raw} onChange={e=>setRaw(e.target.value)} disabled={busy||saving} placeholder="Investment,Quantity,Price,Value (£),…"/><Button disabled={busy||saving||!raw.trim()} onClick={()=>void inspect()}><Upload size={16}/>Read CSV</Button></details></div>:<>
        <div className="csv-source"><span>{kindLabel}{preview.valuationDate?' · '+preview.valuationDate:''}</span><Button variant="ghost" size="sm" disabled={busy||saving} onClick={()=>{generation.current++;controller.current?.abort();setPreview(null);setRows([]);setError('');}}>Choose another CSV</Button></div>
        <div className="csv-total"><strong>{createPortfolio?'Portfolio total':'Statement total'}: {preview.totalPence!==null?money(preview.totalPence):'Check file'}</strong><span className="field-hint">{rows.length-updates} new holdings{updates?` · ${updates} updated holdings`:''} · Cash included once</span>
          {!createPortfolio&&<><p className="field-hint">Current account total: {money(Math.round(Number(draft.value)*100))}. Holdings outside this statement stay in the account.</p>{preview.totalPence!==null&&<div className="csv-confirm"><Checkbox id="csv-use-total" checked={useTotal} onCheckedChange={v=>setUseTotal(v===true)} disabled={saving}/><Label htmlFor="csv-use-total">Also update the account total and valuation date from this statement</Label></div>}</>}
        </div>
        {busy?<p className="csv-auto-status" role="status"><LoaderCircle size={16} className="animate-spin"/>Filling in instrument details…</p>:unknown>0?<p className="field-hint csv-auto-status">{unknown} holding{unknown===1?' has':'s have'} no verified type yet. The statement values and identifiers will still be imported.</p>:<p className="field-hint csv-auto-status">Your portfolio is ready to import.</p>}
        {invalid&&<p className="csv-warning" role="alert">{rows.length>100?'Use a statement with no more than 100 holdings.':'Invalid or duplicate rows found. Correct these in the CSV before importing; no rows have been saved.'}</p>}
        <Table className="csv-preview-table"><TableHeader><TableRow><TableHead>Holding</TableHead><TableHead>Quantity</TableHead><TableHead>Price</TableHead><TableHead className="text-right">Value (£)</TableHead></TableRow></TableHeader><TableBody>{rows.map(r=><TableRow key={r.row.line}><TableCell><strong>{r.row.name}</strong><small>{r.row.ticker?[r.row.ticker,r.row.exchange].filter(Boolean).join(' · '):r.row.instrumentCode?'Fund code '+r.row.instrumentCode:''}{r.row.isin?' · '+r.row.isin:''}</small><small>{r.type==='other'?'Type unavailable':holdingTypes.find(t=>t.id===r.type)?.label}{r.targetId?' · Update existing':''}</small>{r.row.duplicate&&<small className="csv-warning">Duplicate holding</small>}{[...r.row.errors,...r.row.warnings].map(message=><small className="csv-warning" key={message}>{message}</small>)}</TableCell><TableCell>{r.row.quantity||'—'}</TableCell><TableCell>{r.row.unitPrice||'—'} {r.row.priceCurrency}</TableCell><TableCell className="text-right">{r.row.valuePence===null?'Invalid':money(r.row.valuePence)}</TableCell></TableRow>)}</TableBody></Table>
        {!createPortfolio&&<p className="field-hint">Apply these holdings to your draft, then save the entry.</p>}
      </>}
    </div>
    {error&&<p className="form-error" role="alert">{error}</p>}
    <DialogFooter><Button variant="ghost" disabled={saving} onClick={close}>Cancel</Button><Button onClick={()=>void apply()} disabled={!preview||busy||saving||invalid||!name.trim()}>{saving?<LoaderCircle className="animate-spin"/>:<Check size={16}/>} {saving?'Saving…':createPortfolio?'Import portfolio':'Apply holdings'}</Button></DialogFooter>
  </DialogContent></Dialog>;
}
