'use client';
import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowUpRight, Check, KeyRound, LoaderCircle, RefreshCw } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { money, percent, type Account, type Holding } from '@/lib/finance/model';
import type {TrackingResponse} from '@/lib/finance/tracker';
import { chartRanges, priceText, type ChartRange, type MarketDetail } from '@/lib/finance/market';

type Connection={configured:boolean;managed:boolean;canConfigure:boolean};
async function request<T>(path:string,options:RequestInit={}):Promise<T>{
 const response=await fetch(path,{cache:'no-store',...options});const data=await response.json();
 if(!response.ok)throw new Error(data.error||'Unable to load market data.');return data;
}
const stamp=(value:string)=>value.length===10?new Date(value+'T12:00:00Z').toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'}):new Date(value).toLocaleString('en-GB',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',timeZone:'UTC'})+' UTC';
const count=(value:number|null|undefined)=>value==null?'Unavailable':new Intl.NumberFormat('en-GB',{maximumFractionDigits:0}).format(value);
const ratio=(value:number|null|undefined)=>value==null?'Unavailable':value.toFixed(2)+'%';
function Metric({label,children}:{label:string;children:ReactNode}){return <div className="market-metric"><dt>{label}</dt><dd>{children}</dd></div>;}

function TopHoldings({data,limit,onLimit,onRefresh,refreshing}:{data:MarketDetail['constituents'];limit:number;onLimit:(value:number)=>void;onRefresh:()=>void;refreshing:boolean}){
 if(!data||data.status==='not_applicable')return null;
 return <section className="market-stat-section" aria-label="Underlying fund holdings"><div className="market-section-heading"><h3>Top {data.status==='ready'?data.holdings.length:10} {data.listScope||'holdings'}</h3><div className="market-actions"><Button size="sm" variant="outline" onClick={onRefresh} disabled={refreshing}>{refreshing?<RefreshCw size={14} className="animate-spin"/>:<RefreshCw size={14}/>}Refresh</Button>{data.status==='ready'&&data.allHoldings&&data.allHoldings.length>10&&<div className="market-actions" aria-label="Number of holdings"><span className="market-caption">Show</span>{[5,10,25,50,100].filter(value=>value<=data.allHoldings!.length||value===10).map(value=><Button key={value} size="sm" variant={limit===value?'secondary':'ghost'} aria-pressed={limit===value} onClick={()=>onLimit(value)}>{value}</Button>)}</div>}</div></div>
 {data.status==='ready'?<>
 <p className="market-caption">{ratio(data.coveragePercent)} of fund assets · {ratio(data.otherPercent)} outside this list. Weights are the percentages reported by {data.source}.{data.reportedCount!=null?` Provider reports ${count(data.reportedCount)} holdings.`:''}{data.reportedCount!=null&&data.reportedCount>data.holdings.length&&!data.allHoldings?' The complete list was not supplied by this source.':''}</p>
 <div className="analysis-table-wrap"><table className="analysis-table"><thead><tr><th scope="col">Holding</th><th scope="col">Sector</th><th scope="col">Country</th><th scope="col" className="analysis-right">Fund weight</th></tr></thead><tbody>{data.holdings.map((h,i)=><tr key={(h.isin||h.symbol||h.name)+i}><td><strong>{h.name}</strong><small>{h.symbol||'Identifier unavailable'}</small></td><td>{h.sector||'Unavailable'}</td><td title={h.countryBasis}>{h.country||'Unavailable'}</td><td className="analysis-right">{ratio(h.weightPercent)}</td></tr>)}</tbody></table></div>
 <p className="market-caption">Holdings as of {data.holdingsAsOf?stamp(data.holdingsAsOf):'date unavailable'} · Source: {data.sourceUrl?<a href={data.sourceUrl} target="_blank" rel="noreferrer">{data.source}</a>:data.source} · {data.cached?'Saved snapshot retrieved':'Retrieved'} {stamp(data.retrievedAt)}.{data.providerUpdatedAt?` Provider record updated ${stamp(data.providerUpdatedAt)}.`:''}{data.stale?' Latest refresh unsuccessful.':''}</p>
 </>:<p className="market-caption">No verified underlying holdings available.</p>}
 <div className="market-caption" role="status">{data.warnings.map(message=><p key={message}>{message}</p>)}</div>
 </section>;
}

function ConnectionForm({connection,onChanged,onCancel}:{connection:Connection|null;onChanged:()=>void;onCancel:()=>void}){
 const [token,setToken]=useState('');const [busy,setBusy]=useState(false);const [error,setError]=useState('');
 async function save(event:FormEvent){
  event.preventDefault();setBusy(true);setError('');
  try{await request('/api/market/connection',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({token})});setToken('');onChanged();}
  catch(e){setError(e instanceof Error?e.message:'Unable to connect.');}finally{setBusy(false);}
 }
 async function disconnect(){
  setBusy(true);setError('');try{await request('/api/market/connection',{method:'DELETE'});setToken('');onChanged();}
  catch(e){setError(e instanceof Error?e.message:'Unable to disconnect.');}finally{setBusy(false);}
 }
 return <section className="market-connect"><KeyRound size={24}/><h3>{connection?.configured?'Your data connection':'Connect your market data'}</h3>
 <p>Use your own <a href="https://eodhd.com/" target="_blank" rel="noreferrer">EODHD API key <ArrowUpRight size={13}/></a> for closing prices, fund holdings and company classifications. Missing EODHD fields are shown as unavailable.</p>
 {connection?.managed?<p>This connection is managed in the site settings.</p>:connection?.canConfigure===false?<p>Secure key storage is temporarily unavailable.</p>:<form onSubmit={save}><Label htmlFor="market-api-key">EODHD API key</Label><Input id="market-api-key" type="password" value={token} onChange={e=>setToken(e.target.value)} autoComplete="off" autoCapitalize="none" spellCheck={false} minLength={8} maxLength={256} required disabled={busy} placeholder={connection?.configured?'Enter a replacement key':'Paste your API key'}/><p className="market-caption">Your key is encrypted before it is saved and used only by the server to request data.</p><div className="market-actions"><Button type="submit" disabled={busy||!token.trim()}>{busy?<LoaderCircle className="animate-spin"/>:<Check/>}{connection?.configured?'Replace key':'Connect data'}</Button>{connection?.configured&&<Button type="button" variant="outline" disabled={busy} onClick={disconnect}>Disconnect</Button>}</div></form>}
 {error&&<p role="alert" className="form-error">{error}</p>}{connection?.configured&&<Button variant="ghost" onClick={onCancel} disabled={busy}>Back to holding</Button>}
 </section>;
}

export default function HoldingDetail({holding,account,onClose}:{holding:Holding;account:Account;onClose:()=>void}){
 const [range,setRange]=useState<ChartRange>('1Y');const [data,setData]=useState<MarketDetail|null>(null);
 const [holdingLimit,setHoldingLimit]=useState(10);
 const [refreshingHoldings,setRefreshingHoldings]=useState(false);
 const [connection,setConnection]=useState<Connection|null>(null);const [manage,setManage]=useState(false);
 const [loading,setLoading]=useState(true);const [busy,setBusy]=useState(false);const [error,setError]=useState('');const [revision,setRevision]=useState(0);
 const path='/api/market/holdings/'+encodeURIComponent(holding.id);
 const [valuation,setValuation]=useState<TrackingResponse|null>(null);const [valuationError,setValuationError]=useState('');
 useEffect(()=>{const controller=new AbortController();setValuation(null);setValuationError('');request<TrackingResponse>('/api/finance/tracker',{signal:controller.signal}).then(v=>{if(!controller.signal.aborted)setValuation(v)}).catch(()=>{if(!controller.signal.aborted)setValuationError('Portfolio valuation is temporarily unavailable.')});return()=>controller.abort();},[holding.id,revision]);
 const position=valuation?.holdings.find(h=>h.id===holding.id);
 const portfolioTotal=valuation?.currentPortfolioPence??valuation?.points.at(-1)?.portfolioPence;

 useEffect(()=>{const controller=new AbortController();request<Connection>('/api/market/connection',{signal:controller.signal}).then(setConnection).catch(()=>{});return()=>controller.abort();},[revision]);
 useEffect(()=>{
  const controller=new AbortController();setLoading(true);setError('');setData(null);
  request<MarketDetail>(path+'?range='+range+'&limit='+holdingLimit,{signal:controller.signal}).then(value=>{if(!controller.signal.aborted)setData(value);}).catch(e=>{if(!controller.signal.aborted)setError(e instanceof Error?e.message:'Unable to load market data.');}).finally(()=>{if(!controller.signal.aborted)setLoading(false);});
  return()=>controller.abort();
 },[path,range,holdingLimit,revision]);
 const reload=()=>setRevision(v=>v+1);
 async function refreshHoldings(){
  setRefreshingHoldings(true);setError('');
  try{const fresh=await request<MarketDetail['constituents']>(path+'/constituents?limit='+holdingLimit+'&refresh=1');setData(previous=>previous?{...previous,constituents:fresh}:previous);}
  catch(e){setError(e instanceof Error?e.message:'Unable to refresh holdings.');}
  finally{setRefreshingHoldings(false);}
 }
 async function choose(symbol?:string){
  setBusy(true);setError('');try{
   await request(path+'/listing',{method:symbol?'PUT':'DELETE',...(symbol?{headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol})}:{})});reload();
  }catch(e){setError(e instanceof Error?e.message:'Unable to select this listing.');}finally{setBusy(false);}
 }
 const quote=data?.quote;const listing=data?.listing;const stats=data?.stats;const currency=listing?.currency||'';
 const change=quote?.previousClose!=null?quote.price-quote.previousClose:null;
 const fund=listing?.type==='ETF'||['etf','fund','investment_trust'].includes(holding.type);
 const ready=data?.status==='ready'&&!manage;
 return <Sheet open onOpenChange={open=>{if(!open)onClose();}}><SheetContent className="holding-detail-sheet">
  <SheetHeader className="market-header"><span className="eyebrow">INSIDE YOUR HOLDING</span><SheetTitle>{holding.name}</SheetTitle><SheetDescription>{account.name}{holding.ticker?' · '+holding.ticker:''}{holding.isin?' · '+holding.isin:''}</SheetDescription></SheetHeader>
  <div className="market-scroll">
   <div className="market-position"><div><span>Current holding value</span><strong>{position?money(position.valuePence):'—'}</strong></div><div><span>Of your investment portfolio</span><strong>{position&&portfolioTotal!==undefined?percent(position.valuePence,portfolioTotal):'—'}</strong></div><p>{valuationError||(!valuation?'Loading portfolio valuation…':position?.priceDate?`Market close ${stamp(position.priceDate)}${position.stale?' · awaiting a newer close':''}. Based on the same valuation as Analyse.`:position?'Recorded value · add units to enable market valuation.':'This holding is not included in the investment valuation.')}</p></div>
   <div className="market-section-heading"><h2>Market overview</h2><div className="market-actions"><Button size="sm" variant="ghost" onClick={()=>setManage(v=>!v)}><KeyRound size={14}/>Data connection</Button><Button size="icon" variant="ghost" disabled={loading||busy} aria-label="Refresh market data" onClick={reload}><RefreshCw size={16}/></Button></div></div>
   {error&&<div className="market-error" role="alert"><p>{error}</p><Button size="sm" variant="outline" onClick={reload}>Retry</Button>{error.includes('session expired')&&<a href="/">Sign in again</a>}</div>}
   {(manage||data?.status==='setup_required')?<ConnectionForm connection={connection} onChanged={()=>{setManage(false);reload();}} onCancel={()=>setManage(false)}/>:loading?<div className="market-loading" role="status"><LoaderCircle className="animate-spin"/><p>Loading verified market data…</p></div>:<>
    {data?.status==='select_listing'&&<section className="market-listings"><h3>Confirm your trading listing</h3><p>Choose the exchange and currency shown by your broker. We will remember it for this holding.</p><div>{data.candidates?.map(row=><button key={row.symbol} disabled={busy} onClick={()=>choose(row.symbol)}><span><strong>{row.name}</strong><small>{row.symbol} · {row.exchange} · {row.currency} · {row.type}</small>{row.isin&&<small>{row.isin}</small>}</span>{busy?<LoaderCircle size={18} className="animate-spin"/>:<ArrowUpRight size={18}/>}</button>)}</div></section>}
    {data?.status==='unmatched'&&<div className="market-empty"><h3>No verified market listing</h3><p>{data.warnings?.[0]||'Check the ticker and ISIN in your account editor.'}</p></div>}
    {ready&&<>
     <div className="market-listing-line"><span>{listing?.symbol} · {currency} · {listing?.type}</span><Button variant="ghost" size="sm" onClick={()=>choose()} disabled={busy}>Change listing</Button></div>
     <div className="market-price"><span className="market-caption">{quote?.kind==='end-of-day'?'Latest closing price':'Latest available price'}</span><strong>{priceText(quote?.price,currency)}</strong>{change!==null&&quote?.previousClose&&<span className={change>=0?'market-positive':'market-negative'}>{change>=0?'+':''}{priceText(change,currency)} ({change>=0?'+':''}{(change/quote.previousClose*100).toFixed(2)}%) <small>vs previous close</small></span>}<p>{quote?`${quote.kind==='end-of-day'?'End of day':'Delayed snapshot'} · ${stamp(quote.time)}`:'No valid quote is available for this listing.'}</p></div>
     <section className="market-chart-section" aria-label="Price history"><div className="market-chart-heading"><h3>Price history <span>{currency}</span></h3><div className="market-ranges" aria-label="Chart period">{chartRanges.map(r=><Button key={r} size="sm" variant={range===r?'secondary':'ghost'} aria-pressed={range===r} onClick={()=>setRange(r)}>{r==='MAX'?'All':r}</Button>)}</div></div>
     {!!data.points?.length?<><div className="market-chart"><ResponsiveContainer width="100%" height="100%"><LineChart accessibilityLayer data={data.points} margin={{top:12,right:10,left:0,bottom:4}}><CartesianGrid stroke="#303a33" vertical={false}/><XAxis dataKey="time" tickLine={false} axisLine={false} minTickGap={45} tick={{fill:'#aebaaa',fontSize:11}} tickFormatter={v=>{const d=new Date(v);return range==='1D'?d.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',timeZone:'UTC'}):d.toLocaleDateString('en-GB',{month:'short',...(range==='5Y'||range==='MAX'?{year:'2-digit'}:{day:'numeric'}),timeZone:'UTC'});}}/><YAxis domain={['auto','auto']} tickLine={false} axisLine={false} width={70} tick={{fill:'#aebaaa',fontSize:11}} tickFormatter={v=>new Intl.NumberFormat('en-GB',{maximumFractionDigits:2,notation:'compact'}).format(v)}/><Tooltip contentStyle={{background:'#1b241e',border:'1px solid #526047',borderRadius:8,color:'#edf3e6'}} labelFormatter={v=>stamp(String(v))} formatter={v=>[priceText(Number(v),currency),'Price']}/><Line type="linear" dataKey="close" stroke="#d4ef99" strokeWidth={2} dot={data.points.length===1?{r:4}:false} activeDot={{r:5,strokeWidth:0}} isAnimationActive={false} connectNulls={false}/></LineChart></ResponsiveContainer></div><p className="market-caption">{data.interval} · {stamp(data.points[0].time)} – {stamp(data.points[data.points.length-1].time)}</p></>:<div className="market-empty"><p>No history is available for this period. Try another range or check your data plan.</p></div>}
     <p className="market-caption">{data.chartNote||'Chart data is unavailable.'}{range==='1D'?' Prices are unadjusted. Times shown in UTC.':''}</p></section>
     <section className="market-stat-section"><h3>Trading figures</h3><p className="market-caption">Session figures relate to the dated quote above. Annual figures use the available daily history.</p><dl className="market-metrics"><Metric label="Open">{priceText(quote?.open,currency)}</Metric><Metric label="Previous close">{priceText(quote?.previousClose,currency)}</Metric><Metric label="Day high">{priceText(quote?.high,currency)}</Metric><Metric label="Day low">{priceText(quote?.low,currency)}</Metric><Metric label="Volume">{count(quote?.volume)}</Metric><Metric label="30-session avg. volume">{count(stats?.averageVolume)}</Metric><Metric label="52-week high">{priceText(stats?.high52,currency)}</Metric><Metric label="52-week low">{priceText(stats?.low52,currency)}</Metric></dl></section>
     <section className="market-stat-section"><h3>{fund?'Fund information':'Company information'}</h3><p className="market-caption">{stats?.updatedAt?'Provider update: '+stamp(stats.updatedAt):'No dated fundamentals available.'}</p><dl className="market-metrics">{fund?<><Metric label="Expense ratio">{ratio(stats?.expenseRatio)}</Metric><Metric label="Dividend yield">{ratio(stats?.dividendYield)}</Metric><Metric label="Estimated NAV">Unavailable</Metric><Metric label="Premium / discount to NAV">Unavailable</Metric></>:<><Metric label="Market capitalisation">{priceText(stats?.marketCap,stats?.marketCapCurrency||currency)}</Metric><Metric label="Dividend yield">{ratio(stats?.dividendYield)}</Metric></>}</dl>{fund&&<p className="market-caption">This feed does not provide a dated NAV for this holding. A premium or discount needs a NAV and market price in the same currency at a comparable time.</p>}</section>
     {fund&&<TopHoldings data={data.constituents} limit={holdingLimit} onLimit={setHoldingLimit} onRefresh={refreshHoldings} refreshing={refreshingHoldings}/>}
     {!!data.warnings?.length&&<div className="market-warnings" role="status">{data.warnings.map(message=><p key={message}>{message}</p>)}</div>}
     <p className="market-source">Prices: {data.priceSource||'EODHD'} · Chart: {data.chartSource||'EODHD'} · Retrieved {data.fetchedAt?stamp(data.fetchedAt):'—'}. Responses are cached; refreshing may return the same snapshot. All history means the history available from the displayed source.</p>
    </>}
   </>}
  </div>
 </SheetContent></Sheet>;
}
