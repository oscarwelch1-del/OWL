'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const pages = [
  ['/workspace', 'Overview'],
  ['/workspace/analyse', 'Analyse'],
  ['/workspace/journal', 'Journal / Personal plan'],
  ['/workspace/sandbox', 'Sandbox'],
] as const;

export default function Navigation() {
  const pathname = usePathname();
  return <nav className="owl-navigation" aria-label="Workspace">{pages.map(([href, label]) =>
    <Link key={href} href={href} aria-current={pathname === href ? 'page' : undefined}>{label}</Link>
  )}</nav>;
}
