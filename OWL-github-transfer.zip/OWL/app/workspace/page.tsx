import Workspace from './workspace';
import TrackingSync from './tracking-sync';
export const dynamic = 'force-dynamic';
// The Worker checks the session before this route and its RSC requests.
export default function Page() { return <><TrackingSync/><Workspace /></>; }
