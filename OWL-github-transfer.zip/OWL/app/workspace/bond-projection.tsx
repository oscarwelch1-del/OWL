import { projectBond } from '@/lib/finance/bonds';
import { money, today, type HoldingDetails } from '@/lib/finance/model';

export default function BondProjection({details}:{details:HoldingDetails}) {
  const p=projectBond(details);
  return <section className="bond-projection"><h3>Projected payments</h3>{p?<>
    <dl className="bond-figures">
      <div><dt>Each coupon</dt><dd>{money(p.couponPence)}</dd></div>
      <div><dt>Annual coupon income</dt><dd>{money(p.annualPence)}</dd></div>
      <div><dt>Future coupons</dt><dd>{p.couponsRemaining} · {money(p.totalCouponPence)}</dd></div>
      <div><dt>Expected redemption</dt><dd>{money(p.redemptionPence)}</dd></div>
      <div><dt>Maturity</dt><dd>{details.maturityDate}</dd></div>
      {p.nextCoupon&&<div><dt>Next assumed coupon</dt><dd>{p.nextCoupon}</dd></div>}
    </dl>
    {p.matured&&<p className="field-hint">Maturity has been reached. Confirm receipt yourself; these payments have not been added to cash.</p>}
    <p className="field-hint">Projection from {today()}, based on the entered terms and holding to maturity. Assumes fixed, full coupons on a regular schedule ending at maturity, with each payment rounded to pennies. Counts payments after today. Excludes tax, accrued interest, irregular first or last coupons, early redemption and missed payments. No market price is used.</p>
  </>:<p className="field-hint">Enter nominal value, coupon rate, a regular coupon frequency, maturity and redemption value to see a projection. Use 0% for a zero-coupon bond.</p>}</section>;
}
