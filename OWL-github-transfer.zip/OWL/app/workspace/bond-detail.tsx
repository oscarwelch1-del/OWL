import { Sheet,SheetContent,SheetHeader,SheetTitle,SheetDescription } from '@/components/ui/sheet';
import { money, type Holding, type Account } from '@/lib/finance/model';
import BondProjection from './bond-projection';
export default function BondDetail({holding,account,onClose}:{holding:Holding;account:Account;onClose:()=>void}){
  return <Sheet open onOpenChange={open=>{if(!open)onClose();}}><SheetContent className="holding-detail-sheet">
    <SheetHeader className="market-header"><span className="eyebrow">BOND TERMS</span><SheetTitle>{holding.name}</SheetTitle><SheetDescription>{account.name} · Held to maturity</SheetDescription></SheetHeader>
    <div className="market-scroll"><div className="market-position"><div><span>Your entered value</span><strong>{money(holding.valuePence)}</strong></div><div><span>Coupon rate</span><strong>{holding.details.couponRate!==''?holding.details.couponRate+'%':'Not entered'}</strong></div></div><BondProjection details={holding.details}/></div>
  </SheetContent></Sheet>;
}
