import Login from './login';
export const dynamic = 'force-dynamic';
export default function Home() { return <Login />; }
