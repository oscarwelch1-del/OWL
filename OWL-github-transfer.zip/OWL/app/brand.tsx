import { Layers2 } from 'lucide-react';
export function Brand() { return <div className="brand"><div className="brand-mark"><Layers2 size={23} strokeWidth={1.6} /></div><span>OWL<span className="brand-dot">.</span><small>INVESTMENT LAB</small></span></div>; }
