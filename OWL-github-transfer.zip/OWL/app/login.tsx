'use client';
import { useState } from 'react';
import { ArrowRight, Eye, EyeOff, LockKeyhole, LoaderCircle, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Brand } from './brand';
export default function Login() {
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [caps, setCaps] = useState(false);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (busy) return;
    setError(''); setBusy(true);
    const data = new FormData(event.currentTarget);
    try {
      const response = await fetch('/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, credentials:'same-origin', body:JSON.stringify({username:data.get('username'),password:data.get('password')}) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Unable to sign in. Please try again.');
      window.location.assign('/workspace');
    } catch (err) { setError(err instanceof Error ? err.message : 'Unable to connect. Please try again.'); setBusy(false); }
  }
  return <div className="login-shell">
    <aside className="identity-panel"><Brand /><div className="identity-message"><span className="eyebrow">YOUR PERSONAL INVESTMENT LAB</span><h1>A clearer view.<br /><span>A considered move.</span></h1><p>A private space to understand your wealth<br className="desktop-break" /> and explore what comes next.</p><div className="identity-rule" /><span className="identity-caption">Built around your bigger picture.</span></div><div className="identity-footer"><LockKeyhole size={15} /> Personal workspace <span>01 / PRIVATE ACCESS</span></div></aside>
    <main className="signin-panel"><div className="top-label"><ShieldCheck size={16} /><span>PRIVATE BETA</span></div><div className="login-content"><div className="login-symbol"><LockKeyhole size={24} strokeWidth={1.5} /></div><span className="eyebrow form-eyebrow">YOUR WORKSPACE AWAITS</span><h2>Welcome back.</h2><p className="form-description">Sign in to your personal investment lab.</p>
      <form onSubmit={submit} className="login-form"><div className="field"><Label htmlFor="username">Username</Label><Input id="username" name="username" placeholder="Enter your username" autoComplete="username" autoCapitalize="none" spellCheck={false} required maxLength={64} disabled={busy} /></div><div className="field"><Label htmlFor="password">Password</Label><div className="password-field"><Input id="password" name="password" type={visible ? 'text':'password'} placeholder="Enter your password" autoComplete="current-password" required maxLength={128} disabled={busy} onKeyUp={e => setCaps(e.getModifierState('CapsLock'))} onKeyDown={e => setCaps(e.getModifierState('CapsLock'))} aria-describedby={error ? 'login-error':undefined} /><Button type="button" variant="ghost" size="icon" className="reveal-password" aria-label={visible ? 'Hide password':'Show password'} aria-pressed={visible} onClick={() => setVisible(!visible)}>{visible ? <EyeOff />:<Eye />}</Button></div>{caps && <p className="caps-note">Caps Lock is on.</p>}</div>{error && <p role="alert" id="login-error" className="form-error">{error}</p>}<Button type="submit" className="signin-button" disabled={busy}>{busy ? <><LoaderCircle className="animate-spin" /> Signing in…</>:<>Sign in <ArrowRight size={18} /></>}</Button></form>
      <div className="access-note"><LockKeyhole size={15} /><p>Access is limited to your account.<br /><span>Public registration is closed.</span></p></div></div><footer className="signin-footer"><span>OSCAR / INVESTMENT LAB</span><span>Personal use only</span></footer></main></div>;
}
