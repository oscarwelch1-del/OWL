# Oscar · Investment Lab

Private, owner-only Sites application with login, saved accounts and holdings,
cash-flow schedules, income estimates, daily snapshots and stock/ETF market
detail panels. There is no public registration.

## Authentication

- Sites owner-only access is the outer boundary. Preserve it while testing.
- Application username is `oscar`. Initial credentials are provisioned from a
  secret containing a precomputed scrypt hash, never plaintext or a client bundle.
- scrypt uses N=32768, r=8, p=3, a random 16-byte salt and a 32-byte result.
  Verification uses a constant-time comparison. These are OWASP's 32 MiB scrypt
  baseline settings: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
- Initial account insertion is idempotent on first login and never overwrites
  an existing credential. Migrations contain schema only.
- Sessions are random 256-bit bearer tokens; only SHA-256 digests are stored.
  They expire after eight hours, are bound to the platform identity, rotate on
  sign-in and are revoked server-side on sign-out.
- Cookies use the __Host- prefix, Secure, HttpOnly, SameSite=Strict and Path=/.
- Mutations require the configured same origin. Queries use prepared statements.
- An atomic persistent account-level limiter permits ten attempts per 15 minutes.
- Every private page and API checks the session server-side. Future finance APIs
  must explicitly authenticate and scope queries by the authenticated user's ID.
- The test password requested by the owner is weak. Hashing does not strengthen
  the password itself. Keep the owner-only platform restriction and replace the
  test credential before storing financial data. This is not a security audit.

## Runtime configuration

`DB` is the D1 binding in `.openai/hosting.json`.
`APP_ORIGIN` is the exact deployed HTTPS origin.
`BOOTSTRAP_PASSWORD_HASH` is a secret in the documented encoded format.
Local `.env` contains equivalent keys and is ignored. No secrets belong in Git.
The initial secret can be removed after the account exists; saved users remain.

## Holding market detail

Click a saved investment in either holdings table. Connect an EODHD API key in
the panel, then confirm the provider's trading listing, exchange and currency.
Coverage and endpoints depend on the user's plan. No demo key or substitute
investment is used for real holdings. EODHD supplies instrument search, daily
prices, fund holdings, company classifications and benchmark history.

`MARKET_DATA_ENCRYPTION_KEY` must be a secret containing 32 random bytes in
base64. User API tokens are stored in D1 using AES-GCM with a fresh 12-byte IV
and authenticated user-specific context. The encryption key stays in runtime
configuration, outside D1. Losing or rotating it requires reconnecting saved
provider tokens. Optionally `EODHD_API_TOKEN` supplies a site-managed connection
instead. Neither token is returned by the application API.

- The 1D chart uses the latest available 5-minute session, not a live stream.
- 1W, 1M, 3M, YTD and 1Y use daily closes; 5Y uses weekly closes; All uses monthly
  closes across available provider history. Raw closes are explicitly labelled
  unadjusted for splits and dividends. Empty history is never interpolated.
- Quote failures fall back to a dated daily closing price. Quote, chart and
  fundamentals can succeed independently; absent numbers stay unavailable.
- The portfolio tracker migrates saved Yahoo price histories to EODHD when it
  can verify the matching range. Missing EODHD coverage remains dated and visible.
- Exposure checks EODHD for new direct shares and fund listings in bounded
  batches. EODHD fund holdings are shown only when their identity and weights
  can be validated. Missing underlying allocations remain unclassified.
- 52-week highs/lows require roughly a full year's observations; average volume
  requires 30 sessions. Fundamentals with conflicting identity are withheld.
- GBP and pence quote units remain distinct. No currency conversion is applied.
- NAV/premium fields for funds remain unavailable: this feed has no dated NAV
  contract. A future source needs comparable timestamps and currency units.
- Market prices never update manual GBP account valuations or allocations.
- Listings are revalidated against the provider before saving. Editing an
  account replaces its holdings and clears their saved listing selections.
- Cash and debt entries can store rates, payment/interest frequency, next dates
  and fixed-rate end dates. Pension entries can store employee and employer
  contributions. Income entries store gross and after-tax annual amounts.
- Bond holdings can store coupon, payment frequency, nominal value, yield to
  maturity and maturity date. Share and fund holdings can store a distribution
  yield and payment frequency.
- The private dashboard records a daily net-worth snapshot for future analysis.
  These calculations stay out of the overview screen; a snapshot is refreshed
  when the dashboard is opened and is not a broker feed or guaranteed market
  valuation.
- The Other category is intentionally a single flexible entry type.
- Provider JSON is bounded and cached per hashed credential (quotes 1 minute,
  intraday 15 minutes, daily history 1 hour, fundamentals 6 hours). API responses
  to the browser are no-store. Redirects, raw diagnostics and key logging are
  disabled. Session and origin checks run before provider access.

## Checks

`node --test tests/auth.test.mjs` uses Miniflare and an isolated D1 database to
check valid/invalid login, SQL injection, origin rejection, session rotation,
logout, expiry, user binding, concurrent throttling and storage failure.
The native Node scrypt implementation creates the test fixture, independently
checking interoperability with the Worker password implementation.

`node --test tests/market.test.mjs tests/market-api.test.mjs tests/instruments.test.mjs`
checks listing identity/currency, real D1 migrations and ownership, provider
error handling, encrypted token lifecycle, session/origin protection, chart
normalisation and unavailable-data behaviour. The market API tests use seeded
sessions and mocked provider responses, without exercising password guessing.

During this feature's validation, EODHD demo requests for AAPL.US history and
quotes and VTI.US fundamentals succeeded. Search and other exchanges need the
user's own key and were checked with mocks, not a paid production subscription.

Use the Sites build and hosting workflow for publishing. No browser QA has been
performed unless separately requested. Database access is server-only; password
hashing is not encryption of arbitrary future financial records.
