CREATE TABLE `exposure_metadata` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`symbol` text NOT NULL,
	`kind` text NOT NULL,
	`data_json` text,
	`checked_at` integer NOT NULL,
	`retry_after` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_exposure_metadata_user_kind` ON `exposure_metadata` (`user_id`,`kind`);