CREATE TABLE `accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`name` text NOT NULL,
	`category` text NOT NULL,
	`kind` text NOT NULL,
	`provider` text NOT NULL,
	`currency` text DEFAULT 'GBP' NOT NULL,
	`value_pence` integer NOT NULL,
	`ownership_bps` integer NOT NULL,
	`valuation_date` text NOT NULL,
	`mode` text NOT NULL,
	`remainder` text NOT NULL,
	`notes` text NOT NULL,
	`version` integer NOT NULL,
	`write_token` text NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_accounts_user_id` ON `accounts` (`user_id`);--> statement-breakpoint
CREATE TABLE `holdings` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`name` text NOT NULL,
	`type` text NOT NULL,
	`ticker` text NOT NULL,
	`isin` text NOT NULL,
	`amount` text NOT NULL,
	`value_pence` integer NOT NULL,
	`position` integer NOT NULL,
	FOREIGN KEY (`account_id`) REFERENCES `accounts`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_holdings_account_id` ON `holdings` (`account_id`);