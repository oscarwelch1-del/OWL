CREATE TABLE `fund_constituent_snapshots` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`listing_key` text NOT NULL,
	`symbol` text NOT NULL,
	`data_hash` text NOT NULL,
	`data_json` text NOT NULL,
	`retrieved_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_fund_snapshots_user_listing_date` ON `fund_constituent_snapshots` (`user_id`,`listing_key`,`retrieved_at`);