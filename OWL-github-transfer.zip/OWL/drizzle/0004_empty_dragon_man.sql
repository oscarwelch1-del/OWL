CREATE TABLE `portfolio_snapshots` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`snapshot_date` text NOT NULL,
	`assets_pence` integer NOT NULL,
	`debt_pence` integer NOT NULL,
	`net_pence` integer NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_snapshots_user_date` ON `portfolio_snapshots` (`user_id`,`snapshot_date`);--> statement-breakpoint
ALTER TABLE `accounts` ADD `details_json` text DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE `holdings` ADD `details_json` text DEFAULT '{}' NOT NULL;