CREATE TABLE `comparison_prices` (
	`symbol` text PRIMARY KEY NOT NULL,
	`data_json` text,
	`checked_at` integer DEFAULT 0 NOT NULL,
	`retry_after` integer DEFAULT 0 NOT NULL,
	`error` text DEFAULT '' NOT NULL
);
