CREATE TABLE `tracking_days` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`day` text NOT NULL,
	`snapshot_json` text NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_tracking_days_user_day` ON `tracking_days` (`user_id`,`day`);--> statement-breakpoint
CREATE TABLE `tracking_revisions` (
	`seq` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_id` text NOT NULL,
	`account_id` text NOT NULL,
	`recorded_at` integer NOT NULL,
	`state_json` text,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_tracking_revisions_user_account` ON `tracking_revisions` (`user_id`,`account_id`,`seq`);--> statement-breakpoint
CREATE TABLE `tracking_runs` (
	`user_id` text PRIMARY KEY NOT NULL,
	`started_at` integer NOT NULL,
	`lease_until` integer DEFAULT 0 NOT NULL,
	`lease_token` text DEFAULT '' NOT NULL,
	`budget_date` text DEFAULT '' NOT NULL,
	`budget_used` integer DEFAULT 0 NOT NULL,
	`last_refresh` integer,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `tracking_series` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`symbol` text NOT NULL,
	`data_json` text NOT NULL,
	`attempted_day` text NOT NULL,
	`error` text DEFAULT '' NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_tracking_series_user_symbol` ON `tracking_series` (`user_id`,`symbol`);