ALTER TABLE `holdings` ADD `instrument_id` text;--> statement-breakpoint
ALTER TABLE `holdings` ADD `exchange` text;--> statement-breakpoint
ALTER TABLE `holdings` ADD `asset_class` text;--> statement-breakpoint
ALTER TABLE `holdings` ADD `source` text;