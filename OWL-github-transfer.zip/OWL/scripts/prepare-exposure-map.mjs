// Mechanical conversion of Natural Earth's public-domain 110m country geometry.
// Usage: node scripts/prepare-exposure-map.mjs /path/to/ne_110m_admin_0_countries.geojson
import {readFileSync,writeFileSync} from 'node:fs';
const source=JSON.parse(readFileSync(process.argv[2],'utf8'));
const countries=source.features.filter(f=>f.properties.CONTINENT!=='Antarctica').map(f=>{
 const p=f.properties;
 const polygons=f.geometry.type==='Polygon'?[f.geometry.coordinates]:f.geometry.coordinates;
 const path=polygons.map(poly=>poly.map(ring=>ring.map(([x,y],i)=>`${i?'L':'M'}${((x+180)*2).toFixed(1)},${((85-y)*2).toFixed(1)}`).join(' ')+'Z').join(' ')).join(' ');
 return {name:p.ADMIN,continent:p.CONTINENT,aliases:[p.ADMIN,p.NAME,p.NAME_LONG,p.ISO_A2_EH,p.ISO_A3_EH].filter(s=>s&&s!=='-99'),path};
});
writeFileSync('lib/finance/world-map.json',JSON.stringify(countries));
