# OWL: valuation rules and data milestones — 15 September 2026

## Scope of this delivery

Fix holding deletion leaving phantom value; make add/edit/remove amount changes symmetric; recalculate today's chart from cached prices without waiting for a provider; repair the specifically reported Tesla remainder under exact state/version guards. Preserve prior account revisions and stored price history. Today is explicitly provisional. Do not claim that suppressed returns are a calculated, cash-flow-adjusted performance series.

## Account and holding rules

- Account total equals recorded holdings plus its explicit remaining recorded balance. Valuation replaces each holding's recorded value with its verified market value; never add it twice.
- New-account setup allocates its explicitly entered starting total before expanding it; CSV imports provide a complete account snapshot.
- When editing a saved account in pound-value mode, holding value changes change the account total by the same amount. Existing cash and remaining recorded balance are retained. The editor displays the resulting total before saving.
- Deleting a holding removes its recorded allocation; it does not create cash. Selling is a different event: stock decreases and actual net cash proceeds increase. Do not infer a sale, withdrawal, fee or contribution from deletion.
- Removing a percentage holding first freezes all allocations in pounds. Surviving holdings retain their exact penny values; the denominator changes without revaluing them.
- Value-only holdings contribute their recorded amount but have no inferred quantity. Verified quantities plus their as-of date enable market valuation. An explicitly accepted quantity estimate can be added later, with its price/FX/date and estimated status retained.
- A declared account total can still be entered explicitly. Imports are snapshots of holdings, not evidence of trading or external cash flows. The import/editor preview must make the resulting total visible.
- No negative cash is invented to force reconciliation. Unknown residual values are not assumed to be cash and must be shown separately in future exposure analysis.
- CSV snapshot imports remain version-checked and user-scoped. Duplicate holdings/uncertain identities need review.

## Prices, dates and history

- Price-based GBP value = quantity × raw close × quote-unit scale × GBP per currency unit. GBP and GBp/GBX are distinct. Apply verified splits once.
- Yahoo is primary for the daily tracker. EODHD is the fallback for this task. Fallback EODHD responses do not have the session-end evidence used by the Yahoo adapter, so only earlier-day closes are accepted.
- Preserve quote date, FX date, source, observed time, and whether the session is complete. Carry earlier closes over weekends/holidays; missing prices never become zero.
- Today uses current account revisions and cached prices immediately, even while a price refresh is in progress. Today remains provisional until UTC rollover; this does not mean all exchanges close at UTC midnight.
- Previous days use the account state recorded on each day, not today's quantities applied backwards. Ordinary edits take effect on the edit day. Removing a holding is explicitly a historical correction: exclude that position and its recorded allocation from every affected historical account state and rebuild chart snapshots, including dates outside the normal refresh window. Preserve original revisions and market prices. Whole-account deletion retains its existing semantics. A sale or switch must be recorded separately, never inferred from removal.
- Guard history writes with the revision sequence read by the calculation, so an older calculation cannot overwrite a newer account state.
- Prices can be refreshed without deleting earlier history. Today's point can be recalculated repeatedly; it is one date, not a new observation on every click.
- Background collection while the website is closed is NOT implemented. Current refreshes occur while OWL is open, with historical catch-up. Scheduling is a later milestone.

## Performance rules

A value chart answers “what was recorded as owned on each date?” and can jump when holdings are added. It is not itself an investment return chart.

Suppress performance on account-edit days or when comparable pricing is unavailable. This is a limitation, not a claim to have calculated adjusted returns. A return across edits needs external cash-flow amounts, effective times, and compatible valuations.

Future event categories: deposit, withdrawal, purchase, sale, fee, cash income, transfer, data correction. Keep this bookkeeping behind the interface. A purchase/sale within a portfolio is not an external flow; transfers between included accounts are not portfolio growth. Distinguish recorded cost basis from price movement since OWL began tracking.

Target a documented time-weighted return method once sufficiently timed flows/valuations exist. Separately consider money-weighted return for the investor's own cash experience. Do not call OWL GIPS-compliant: that requires more than adopting a calculation principle.

Reference: CFA Institute / GIPS standards, https://www.gipsstandards.org/wp-content/uploads/2021/03/2020_gips_standards_firms.pdf .

## Milestones and acceptance gates

1. BALANCE FOUNDATION — this delivery. Add £10,000, change to £5,000, remove it: return to original total with original cash intact. Include percentage holdings, fractional pennies, value-only holdings, stale editor saves, account deletion, and isolation between users. Verify chart corrections before a fresh market close and during provider failures.
2. PRICE COVERAGE AUDIT — next. Inventory each held listing and its expected quote currency/unit. Compare at least one published close and FX conversion manually for each supported venue. Report priced/manual/stale coverage separately. Distinguish fetch time from actual price date. Check split and corporate-action failures without overwriting history. Establish an unattended schedule and alerting only after this reconciliation passes.
3. SECURITY IDENTITIES — assign internal security and listing IDs. Never use bare ticker as the primary key. Record provider symbol mappings, exchange/MIC, currency/unit, ISIN/FIGI where available, listing validity dates, and evidence. Keep security identity separate from company identity: ADRs and share classes must not become duplicate companies or interchangeable listings. Conflicting mappings remain unresolved.
4. FUND/TRUST COVERAGE — inventory every current supported fund/trust (OEIC deferred). EODHD full `Holdings` responses are retained when supplied, with top-X served as a view; issuer and manager downloads still need verified adapters. Each gets a verified dated snapshot or a specific missing-data reason. Add adapters per issuer/manager report format; use public broker data where identity/date/weight validation passes. Reuse shared adapters rather than bespoke portfolio logic. Preserve the last verified snapshot on failure. Source changes never overwrite an older dated list.
5. CLASSIFICATION — add sector taxonomy/version, industry, headquarters country, domicile and fund-reported geography as separate fields with evidence and effective dates. Do not infer business geography from exchange, quote currency or an ISIN country prefix. Private companies can have names/IDs and classification even when no quoted ticker exists.
6. LOOK-THROUGH EXPOSURE — combine direct and indirect company exposures using dated weights. Show top-ten coverage and unknown remainder; never rescale ten holdings to imply 100% coverage. Store the weight denominator (NAV, total assets, equity sleeve, etc.). Trust gearing/discounts and fund-of-funds need explicit treatment. Initially label portfolio-value × reported weight as an allocation proxy where NAV/economic exposure differs.
7. ATTRIBUTION — retain historical weights/classifications before charting sector/geography performance. Do not apply today's top ten backwards and call it the user's historical return. Compare like-for-like benchmark currency, dates and price/total-return treatment. Distinguish known direct returns from estimated indirect attribution and unresolved data.

## Target data structure (incremental, not a wholesale rewrite today)

| Record | Essential fields |
| --- | --- |
| Company | internal ID, name, private/public status, dated classification references |
| Security | internal ID, company/fund ID, instrument type, share class, identifiers |
| Listing | security ID, exchange/MIC, ticker, quote currency, quote unit, valid dates |
| Provider mapping | listing ID, provider, provider symbol, validation status/evidence/date |
| Daily price | listing ID, session date, raw/adjusted type, value, currency/unit, source, fetched time, completeness |
| FX observation | base/quote currencies, session date, rate direction, source, fetched time |
| Corporate action | security/listing ID, effective date, type, ratio/amount, source |
| Position revision | user/account/security/listing IDs, quantity, quantity source/date, recorded GBP value/date, recorded time |
| Acquisition lot (later) | position ID, actual acquisition date, quantity, paid price, fees, currency and FX; unknown until supplied |
| Fund snapshot | fund ID, report date, retrieved time, source URL, scope, denominator, validation state |
| Constituent | snapshot ID, security/company ID or unresolved name, reported weight, identifiers/evidence |
| Classification observation | company ID, taxonomy/version, sector/industry, geography basis, value, effective/retrieved dates, source |
| Valuation | user/account/day, value, market/manual components, quote/FX dates, completeness, adjustment flag, input revision IDs |

“Initial price” must be explicit: actual acquisition price, statement unit price, and first observed OWL close are different fields. Never substitute one for another to report profit.

## Data collection contract

Fetch → preserve source metadata → validate identity, currency, dates and units → normalize → save verified observation → derive valuations/exposures. On failure retain the last good observation with its actual date. Unknown stays unknown. Classification failure must not erase an independently identified constituent ticker or its published weight.

Refresh prices around completed sessions, fund holdings on the publisher's reporting cycle, classifications less frequently and after identity changes. Cache by canonical listing/fund identity so two portfolios sharing an instrument do not trigger duplicate work. Check redistribution/licensing before opening this personal project to other users; public visibility alone is not permission to redistribute.
