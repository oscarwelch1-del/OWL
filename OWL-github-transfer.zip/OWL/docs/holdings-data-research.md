# OWL holdings data: verified routes and next delivery

Researched 15 September 2026. This document distinguishes source availability from implemented ingestion. OWL now retains an EODHD `Holdings` list when the provider returns one, stores it with the snapshot, and serves a requested top-X slice; issuer/PDF full-portfolio adapters below are still not implemented.

## Verified sources

| Source | What was verified | Integration decision |
| --- | --- | --- |
| [EODHD ETF glossary](https://eodhd.com/financial-academy/financial-faq/fundamentals-glossary-etf) | Separate Top_10_Holdings and Holdings fields; the latter is the full list **if available**. Constituent weights, identifiers and classification fields are documented. | Test actual account entitlement and each held fund before paying for broader access. Current OWL normalizer selects top ten. Read full holdings where supplied, preserving the source's scope and dates. |
| [Vanguard FTSE All-World accumulating](https://www.vanguard.co.uk/professional/product/etf/equity/9679/ftse-all-world-ucits-etf-usd-accumulating) | Official page publishes dated holdings with weights, sector, region, market value and shares, plus a download control. | Download route identified; the complete workbook/parser has not been validated. Resolve the exact share class and capture its holdings date, which can differ from aggregate allocation dates. |
| [iShares Core MSCI World](https://www.ishares.com/uk/individual/en/products/251882) | Official page offers Detailed Holdings and Analytics and publishes holdings count and fund identity. | Download route identified; full file parsing remains to be validated. Do not mistake this example for verified coverage of every iShares product. |
| [Monks full valuation, 31 July 2026](https://www.bailliegifford.com/en/uk/individual-investors/literature-library/funds/investment-trusts/portfolio-valuations/monks-valuation-31-july-2026/) | Opened the full three-page report. It contains names, listed-security ISINs, quantities, GBP market values and percentages of total assets, plus private investments and net liquid assets. | Strong initial PDF adapter candidate. Keep private/unidentified rows, cash and totals distinct; do not invent tickers. Full holdings are deliberately delayed; newer top-ten figures are a separate snapshot. |
| [Scottish Mortgage holdings](https://www.scottishmortgage.com/en/uk/individual-investors/holdings) and [31 July 2026 full valuation](https://www.scottishmortgage.com/en/uk/individual-investors/literature-library/funds/investment-trusts/portfolio-valuations/scottish-mortgage-valuation-31-july-2026/) | Opened the full four-page report linked from the official holdings page. It includes public/private positions, weights and many ISINs. The website explicitly states that the full portfolio is delayed. | Reuse the Baillie Gifford report adapter with separate fixtures. Several share classes can belong to one company; preserve security rows before company-level aggregation. |
| [OpenFIGI mapping API](https://www.openfigi.com/api/documentation) | Identifier mapping supports ISIN, exchange/MIC and currency constraints and returns FIGI-related identities. | Use to resolve securities/listings, not as a complete industry database. Its marketSector describes an asset class such as Equity; it is not a Technology/Healthcare sector classification. |

Availability of public pages is not a guarantee of automated download reliability or permission for redistribution. Validate those constraints before widening this private project's audience. HRI and other managers still need individual source validation; no universal trust coverage is claimed.

## Accuracy traps that affect the architecture

- EODHD's constituent Country is documented as the exchange's location. Do not present it as company domicile or revenue geography. Preserve the basis of every geography field.
- Fund-wide reported sector/geography distributions and classified constituent rows are different evidence. Show each with its own date and coverage; never add them together.
- A current top-ten snapshot and an older complete snapshot must remain separate. Combining them would manufacture a portfolio no publisher reported.
- Share classes, ADRs, exchanges and companies are separate identities. Match by verified identifiers; a name or ticker alone is insufficient. Unresolved candidates remain unresolved.
- Preserve source taxonomy and map explicitly into a chosen analysis taxonomy. Different publishers may classify the same company differently.
- Percentages can refer to total assets, NAV or an equity sleeve. Keep the denominator. Cash, derivatives, borrowing and fund-of-funds prevent a universal sum-to-100 rule.
- A trust's market value multiplied by reported portfolio weight is an allocation proxy; it is not automatically its geared underlying economic exposure. NAV discounts and gearing require separate treatment.
- Private positions may have no public ticker or daily price. Keep their published value/date and classification without inventing quotes.

## Storage contract

Separate company, security, listing and provider-symbol mapping records. Use internal IDs, validated ISIN/FIGI identifiers, exchange/MIC and quote currency/unit. Preserve evidence and validity dates for mappings.

Store every accepted fund report as an immutable snapshot: fund/share-class ID, as-of date, publication date if known, retrieval time, source URL, content hash, full/partial scope, reported count, weight denominator, taxonomy and validation result. Store all constituent rows under that snapshot with raw identifiers, normalized security/company references where resolved, weight, market value/currency where supplied, and explicit unresolved reasons. Preserve raw downloads for reproducibility.

Classification observations need source, effective date, taxonomy, sector/industry, geography value and geography basis. Daily prices need listing, session date, currency/unit, raw/adjusted convention, source and completeness. Initial acquisition price is user/statement evidence, not the first price OWL happened to observe.

Download once per fund/report update and share the cache across portfolios. Top 10/25/50/all is a view over stored rows. Do not fetch or enrich every constituent again when the user changes X. Preserve the last valid snapshot on network, entitlement or parsing failure.

## Next implementation and acceptance gates

1. **Full report ingestion:** implement and fixture-test Monks and Scottish Mortgage reports, plus one validated issuer CSV/XLS download for a held ETF. Store all reported rows. Reconcile market values/totals within documented rounding tolerance; reject malformed dates, impossible weights and duplicate source rows. Never drop private or unresolved rows silently.
2. **Remove the remaining top-ten bottleneck:** EODHD full lists and requested top-X slices are now retained behind the API. Public issuer/manager adapters still intentionally expose their verified top ten until their complete downloads/reports are parsed. Add pagination, report date, reported count and covered percentage to the wider analysis surface, and replace the public 500-row guard only when a complete source adapter has been validated.
3. **Identity and classification:** map ISINs first, then constrained ticker/exchange candidates. Cache enrichment per security/company. Keep matching independent of profile lookup so classification failure cannot erase a confirmed ticker or weight. Test multiple listings, Alphabet classes, ADRs and private names. Record unresolved coverage by weight.
4. **Exposure:** combine direct holdings and indirect allocations with dated weights. Offer company overlap, concentration, sector and geography views with unknown portions visible. Validate fund-of-funds recursion, avoid cycles and double counting. Company aggregation must preserve the original security rows.
5. **History and performance:** keep successive holdings snapshots. First show changes in reported exposures. Only add estimated constituent performance after historical weights, quotes, FX and corporate actions are sufficiently covered. Label assumptions about between-report trades; never apply today's weights backwards and claim exact historical attribution.

The portfolio total still uses prices for instruments the user actually owns. It does not require nightly pricing of every underlying company. Fetch constituent histories on demand for requested analysis and cache them by validated listing; this limits API cost substantially.

## This delivery's chart correction

Removing a holding is treated as correcting it out of the displayed history. Historical account states exclude that position and its recorded allocation, and affected daily snapshots are rebuilt from retained prices. Original account revisions and price history remain intact. Actual sales/switches must be entered separately. Tests cover add/remove symmetry, changed historical allocations, retained cash, account isolation and existing account-deletion semantics; finance/tracker route tests and the production build also passed.
