# Exposure foundation

The Analyse page has a geographic map (continent → country → contributing holding) and a sector doughnut (sector → industry → contributing holding). Both consume the same pure calculation in `lib/finance/exposure.ts`. All percentages use total analysed investments, including DC pensions and unassigned account balances. They do not represent total net worth.

## Data contract and costs

`GET /api/market/exposure` uses the existing authentication gate and ownership-scoped holdings query. It reads saved snapshots using the exact listing identity (symbol, ISIN and currency hash), deduplicating repeated listing reads within the request. It does not decrypt credentials, fetch a provider, alter portfolio history or write snapshots. Loading or switching visualisations costs zero EODHD calls. Reload saved data rereads the database; the existing holding-detail Refresh action fetches provider data.

The existing append-only D1 `fund_constituent_snapshots` remains authoritative. Every changed provider response keeps source, reported holdings date, retrieval time and full available constituents. Exposure always uses `allHoldings` when present; the top-X display limit does not truncate the analysis. Existing historical snapshots and closing-price source order remain unchanged.

## Calculation rules

Current GBP holding value × reported constituent weight / 100. Allocate fractional pennies by largest remainder; retain the undisclosed part as Unclassified. Never rescale a top-ten list to 100%. Missing sector, industry, country and identifier stay missing independently. Reject invalid/over-100% lists rather than charting them. The remaining account value stays in the denominator as cash/unassigned. Repeated ownership through different accounts is counted once per position, intentionally.

For investment trusts these are estimates of allocation of the user's market value, not exact underlying NAV exposure. Gearing, derivatives, short positions and fund-of-fund recursion are not modelled. Unknown direct-stock classifications remain unclassified until a verified company-profile adapter is added. Do not infer geography from ticker suffix or infer a private company's ticker from its name.

Geography means source-reported country, which can be company or exchange location; each contributing row displays its basis. It is never labelled revenue exposure. Map regions use Natural Earth, with one region per country (including transcontinental countries). Unknown locations remain unclassified. Industry is provider detail, not a claim that all providers share a standard subsector taxonomy.

## Premium activation checklist

1. Test entitlement against representative ETFs, trusts, foreign listings and missing instruments using the connected credential. Confirm actual `ETF_Data.Holdings` responses, identity, weights and date semantics. Access to Fundamentals is not a universal coverage guarantee.
2. Reuse `normalizeConstituents` and `rememberConstituents`; no visualisation rewrite or migration is needed for fuller lists. Refresh one instrument and verify classified coverage grows while portfolio total stays constant.
3. Add a separate verified company-profile snapshot adapter for direct stocks, preserving taxonomy, country basis and source dates. Extend the exposure contract for this input; never use corporate shareholders as fund holdings.
4. Before background collection, add a durable per-instrument refresh queue with entitlement-aware budgets, retries/backoff and last-attempt status. Deduplicate requests by provider listing identity, keep older valid snapshots on failure, and test changed/unchanged/error responses.
5. Keep historical exposure distinct from today's composition. A historical view must use holdings reports available at the time and quantity/price/FX observations for that date. Current weights cannot reconstruct historic sector performance.

## Map asset

`lib/finance/world-map.json` is a bundled, offline equirectangular conversion of Natural Earth's public-domain 110m countries. Source: https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_110m_admin_0_countries.geojson . Reproduce with `scripts/prepare-exposure-map.mjs`. No map API, tracking or runtime CDN requests. Country aliases and geometry derive from the same source.

## Regression checks

`node --test tests/exposure.test.mjs tests/constituents.test.mjs` checks conservation, partial lists, full-list selection, repeated accounts, unknown fields, invalid weights, penny rounding and immutable snapshots. Existing tracking tests cover price-provider fallback and historical corrections separately.
