# Current-basket benchmark comparison

This is a hypothetical replay, not the user's historical return. We cannot reconstruct unknown purchase dates or fund trading histories. Current saved constituent weights are applied at the beginning of a selected historical period, then hypothetical units are held fixed except for verified splits. This contains hindsight/survivorship bias, explicitly disclosed in the UI.

## Scope

- UK source-reported country exposure, not UK revenue. Country may refer to company or exchange location; use the same grouping as the exposure view.
- First benchmark: FTSE 100 price index, Yahoo `^FTSE`, explicit internal identity `FTSE100.INDX`. This is a large-company comparator, not a size/style-matched benchmark for every portfolio. Official definitions: https://www.lseg.com/en/ftse-russell/indices/uk . Add FTSE All-Share/smaller-cap choices only after verifying their data identifiers and availability.
- London identifiers only, verified GBP/GBp currency; overseas listings remain excluded until daily FX handling is implemented. Direct stocks without country classifications remain unclassified, as in the geographic view.
- At most 20 unique companies, selected by current attributed value; overflow is disclosed and remains in the coverage denominator. Identical verified listings held through several funds are aggregated without collapsing different share classes by name.
- 1M/3M/1Y, completed dates through yesterday UTC. Fetch one year once and reuse across period changes. No EODHD calls.

## Calculation

For included company i, initial weight = its current attributed GBP value / sum of included attributed values. Portfolio index on day t = 100 × sum(initial weight × raw close(t)/raw close(start) × split factors after start through t). No daily rebalancing. Benchmark index = 100 × benchmark close(t)/benchmark close(start).

Use identical first/last benchmark close dates. Exclude a constituent for the entire run if those endpoints are unavailable, split coverage is insufficient, or fewer than 90% of benchmark closing dates have prices. Omit remaining isolated missing dates from both lines. Withhold the chart if fewer than 80% of benchmark dates remain. Never forward-fill arbitrary missing market sessions, introduce an IPO mid-run, or treat an excluded company as cash. Report actual displayed dates.

Both lines are price returns: no dividend reinvestment, fees or tax. The percentage-point difference is not risk-adjusted alpha. Trust look-through weights are allocation estimates; trust discounts/gearing/fees are not reproduced by constituent returns.

Coverage denominator is ALL known UK exposure, including missing identifiers, unsupported listings and request-limit exclusions. The included subset is explicitly reweighted to 100%. Separately disclose overall unclassified geography, which may contain more UK exposure.

## Storage and safeguards

The authenticated POST endpoint rebuilds weights from the user's current committed accounts, saved price observations and identity-matched constituent snapshots. It does not accept client symbols or weights. Origin checks apply. It never updates tracker revisions, daily history or user accounts.

`comparison_prices` stores public Yahoo series only, separately from `tracking_series`. Successful results cache for six hours; failures back off for fifteen minutes. A thirty-second per-symbol database lease deduplicates concurrent fetches across isolates; a one-year series is reused for all periods. A failed fetch retains the earlier data, but period/split coverage gates still apply. No user names, weights or calculated baskets enter this shared cache.

Future actual comparisons should use dated ownership records and fund compositions. Fund publication snapshots can support an approximation between disclosure dates, not exact intra-period manager trades. Keep that method separate from this current-basket model.

## Snapshot-only next steps

Prioritise concentration and overlap from current saved holdings. Benchmark sector/country weights, company size, valuation, yield, charges and trust discounts need corresponding dated datasets but not ownership history. Weighted valuation metrics need correct aggregation conventions and coverage handling (do not average P/E ratios blindly). Volatility, drawdown and beta still require price history.
