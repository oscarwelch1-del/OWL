# OWL EODHD and holdings data plan

Updated 15 September 2026. This is the implementation plan for arbitrary user portfolios, not a data map for one person's holdings.

## What an EODHD upgrade does and does not solve

EODHD currently lists four relevant personal plans: free, EOD Historical Data ($19.99/month), EOD+Intraday All World Extended ($29.99/month), Fundamentals Data Feed ($59.99/month), and All-In-One ($99.99/month). The free plan is listed as 20 API calls per day. The Fundamentals Data Feed is the relevant upgrade for ETF/fund fundamentals and constituent data; paying for the $19.99 price package alone should not be assumed to unlock full holdings. [Current EODHD pricing](https://eodhd.com/pricing)

The documentation describes `ETF_Data.Top_10_Holdings` and a `Holdings` field containing the full list **if available**. It also says the single fundamentals endpoint serves stocks, ETFs, mutual funds and indices, and recommends v1.1. This means an upgrade may unlock the field for a particular instrument, but it cannot guarantee complete data for every ETF, investment trust, private position, report date or exchange. [Fundamentals API](https://eodhd.com/financial-apis/stock-etfs-fundamental-data-feeds) · [ETF field glossary](https://eodhd.com/financial-academy/financial-faq/fundamentals-glossary-etf)

Recommended purchase sequence: first use a one-month Fundamentals Data Feed trial against a test list of exact instruments (one broad ETF, one specialist ETF, SMT, MNKS and HRI). Upgrade to All-In-One only if the project also needs intraday, live, news, technical and other packages. Do not buy on the assumption that it guarantees full trust portfolios. Ask EODHD support to confirm `ETF_Data.Holdings` entitlement for the exact symbols before committing to an annual plan.

## Source and API execution

1. **Import identity.** A CSV row supplies name, ISIN, ticker, exchange, quantity, value and currency. Resolve it to an internal security and exact listing. ISIN/FIGI plus exchange/MIC is the identity; ticker and name are search inputs only.
2. **Security master.** Use EODHD search/listings and OpenFIGI mappings to validate the listing. Keep share classes, ADRs, exchanges and the underlying company separate. Ambiguous matches remain unresolved.
3. **Fund snapshot.** For each unique fund listing, request `v1.1/fundamentals/{CODE.EXCHANGE}` with the required `General` and `ETF_Data` sections. Request once per fund, deduplicate concurrent requests and cache the response by canonical listing and content hash.
4. **Normalize.** Prefer `ETF_Data.Holdings` when returned; otherwise retain `Top_10_Holdings` and mark the list partial. Never manufacture the remainder from NAV, ticker or prices. Preserve provider count, report/update date and the raw source response.
5. **Issuer fallback.** If EODHD lacks a complete list, resolve the issuer from the security master and use a verified official CSV/XLS/PDF adapter for Vanguard, iShares and investment-trust managers. Every adapter must validate the fund identity, report date, columns, weights and totals before saving.
6. **Refresh policy.** Refresh holdings on the issuer's publication cycle, with a manual Refresh action that bypasses OWL's saved snapshot and provider cache. Refreshing unchanged source data should produce the same content hash, not a duplicate snapshot.
7. **Price policy.** Yahoo remains primary for OWL's daily portfolio close tracker. EODHD remains fallback only for that task. Underlying constituent prices are fetched only for requested attribution, cached by listing/date, and never needed to display the fund's own current value.

## Storage model

Use immutable dated observations. A later source response appends a new observation; it never overwrites an earlier report.

| Table | Purpose | Essential fields |
| --- | --- | --- |
| `companies` | Economic issuer/company identity | internal ID, name, public/private status |
| `securities` | Share class or fund identity | internal ID, company/fund link, ISIN, FIGI, instrument type |
| `listings` | Tradable listing | security ID, exchange/MIC, ticker, quote currency/unit, validity dates |
| `provider_mappings` | Provider-specific symbols | listing ID, provider, symbol, validation state, evidence, checked date |
| `fund_snapshots` | One publisher/API report | fund/share-class ID, report date, publication date, retrieved time, source URL, content hash, scope, weight basis, reported count, validation state |
| `fund_constituents` | Every reported row | snapshot ID, raw name, security/company link, ISIN/FIGI, reported weight, market value/currency, raw row, unresolved reason |
| `classification_observations` | Dated sector/geography facts | company ID, taxonomy/version, sector, industry, geography value, geography basis, source, effective/retrieved dates |
| `daily_prices` | Historical listing prices | listing ID, session date, raw/adjusted type, close, currency/unit, source, fetched time, completeness |
| `fx_observations` | Currency conversion | base/quote, session date, rate, source, fetched time |
| `exposure_edges` | Derived look-through links | portfolio holding, fund snapshot, underlying security, weight, calculation version |

The existing snapshot JSON can be the first implementation, but it must retain `allHoldings`, displayed `holdings`, `reportedCount`, `holdingsAsOf`, `weightBasis`, source URL/hash and validation metadata. Normalize into rows when exposure analysis begins.

## Validation rules

- The returned fund code, ISIN, exchange and currency must match the selected listing.
- Each row needs a stable identifier where one is supplied. Duplicate ISIN/share-class rows are kept only when the source distinguishes them; otherwise the snapshot is rejected for review.
- Weights must be numeric, non-negative and no greater than 100%. Full-list totals must not exceed 100% except for an explicitly documented derivative or rounding rule.
- `topX` sorts by reported weight and sums the selected rows. It does not rescale them to 100%; the uncovered remainder stays visible.
- `Country` is stored with a basis such as exchange location, headquarters or revenue geography. It is never silently treated as the company's true economic exposure.
- Private, cash, derivative, fund-of-fund and unresolved rows remain in the snapshot. Missing data is not converted to zero.
- A current top-ten report and an older full report are separate snapshots. Never combine them into one invented portfolio.

## Analysis calculations

For a direct holding, company exposure is its verified portfolio value. For a fund, the first-pass look-through allocation is:

`user fund value × reported constituent weight`

This is labelled an allocation proxy. Store the denominator (NAV, total assets, equity sleeve or another basis), trust gearing/discount treatment and calculation version. Fund-of-funds use bounded recursive expansion with cycle detection and an explicit unknown remainder. A trust's private companies and unquoted positions can contribute to allocation without having a daily market price.

Sector and geography views aggregate dated constituent allocations while retaining direct holdings separately. Sector taxonomy and geography basis are shown with the result. Historical attribution uses the snapshot that was available on that date; today's weights are never applied backwards as if they were historical facts.

## Delivery gates

1. Test the exact EODHD plan against five representative instruments and record whether `Holdings` is returned, the reported count, dates and coverage.
2. Add fixtures for a full EODHD response, a top-ten-only response, malformed weights, duplicate share classes, private rows and provider errors.
3. Complete one issuer CSV/XLS adapter and one investment-trust PDF adapter. Reconcile published totals before accepting a snapshot.
4. Add an API response showing source, report date, reported count, displayed count, covered percentage and full/partial status.
5. Add top 5/10/25/50/all views over stored rows without additional provider calls.
6. Add security identity and classification observations before calculating sector/geography exposure.
7. Add historical snapshot comparison, then performance attribution only after price, FX and weight coverage is measured.

## Success definition

OWL succeeds when any supported portfolio can show the best verified holdings list available for its exact instrument, with report date, weight denominator, source and unknown coverage visible. It does not require every fund to expose every private or delayed position. That limitation is reported honestly instead of hidden behind an apparently complete chart.
