# Combined ownership, overlap and coverage

The analysis view reuses saved exposure rows. It makes no new provider calls and stores no additional user data. Current tracker valuation is supplied separately from the last chart point so daily-history lag does not change the denominator.

## Identity and totals

ISIN takes precedence. A symbol-only row may join an ISIN group only if the same verified listing is associated with exactly one ISIN in the available rows. Conflicting mappings leave symbol-only rows unresolved. Canonical listing aliases handle Yahoo/EODHD exchange notation and US share-class separators. Bare direct-entry tickers never imply a US listing. Company names never establish identity, including private holdings. Distinct share-class ISINs are not collapsed to a company parent without issuer-level data.

Direct shares keep their identity even where sector/country profiles are missing. All fund contributions retain their original weights and attributed values. Top 1/5/10/20 are percentages of total analysed investments, never renormalised to known holdings. Cash, missing holdings and unresolved identifiers remain in the denominator. Identified concentration is therefore a lower-bound view of known security exposure, not a complete company-level ranking.

Overlap is a security occurring in more than one fund position, or in a fund plus direct shares. Same fund held in two accounts counts as two fund positions and is labelled accordingly. Combined exposure to overlapping securities is not excess value or pairwise overlap, and is never added again to the portfolio total. The contribution breakdown conserves value.

## Data coverage checklist

Report completeness and freshness are separate. Full allocation means valid rows cover effectively 100% of supplied weight and do not contradict a reported holding count. Partial lists retain reported weights. Duplicate identified rows or invalid weights are withheld for review. The 90-day threshold is a review indicator, not a promise of freshness. Missing holdings dates stay unknown even if data was retrieved today. Sector/country coverage is measured in fund weight, not row count.

Actions open the existing holding view for manual refresh. No premium entitlement is assumed. Once fuller reports arrive, the same calculations consume their full saved list automatically.

## Fixes in this change

- Current holding valuations use the current portfolio total, not an older historical point.
- Direct share identities are retained for overlap without inventing their classifications.
- Invalid duplicate constituent rows are withheld from exposure calculations.
- An older-provider fallback respects the requested top-X display limit.
- Exposure copy distinguishes saved-data exploration from separately requested benchmark price fetches.

Limitations remain: named private holdings need verified identifiers, fund-of-fund recursion and company-parent consolidation are not implemented, and snapshot weights may be delayed. These limits are shown rather than filled with inferred data.
